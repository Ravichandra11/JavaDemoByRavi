



/* global casee */

$(".container").show(500);
var countries = [];
$(document).ready(function () {
    getCountries();
    getNews();
    getAllData();
    setTimeout(() => {
        $('.details_more').css('display', 'flex');
    }, 1000);
    $(".close").click(function () {
        $(".details").slideUp(200);
    });
    $(".details_more").click(function () {
        $(".details").slideDown(200);
    });
    // search by input 
    $("#search").keyup(function () {
        var x = $(this).val();
        if (x.length === 0) {
            getCountries();
        } else {
            $.ajax({
                type: "GET",
                url: "/corona/get/" + x,
                dataType: "json",
                contentType: 'application/json',
                success: function (response) {
                    $(".countries").empty();
                    $.map(response, function (v, k) {
                        $(".countries").append("<li value='" + v.country + "'>" + v.country + "</li>");
                    });
                }

            });
        }
    });
    $("#search").click(function (e) {
        $(this).val('');
        $(".countries").css('display') === 'none' ? $(".countries").slideDown(200) : $(".countries").slideUp(200);
    });
    $(document).on('click', '.countries li', function () {
        var x = $(this).text();
        $("#search").val(x);
        $('.countries').slideUp(200);
        getDataByCountry(x);
        getCountries();
    });
    $(document).on('click', '.news_item', function () {
        var x = $(this).children('.readMore').attr('href');
        window.location.href = x;
    });
});
function getAllData() {
    $.ajax({
        type: "GET",
        url: "https://corona.lmao.ninja/v2/all",
        dataType: "json",
        contentType: 'application/json',
        success: function (response) {
            var x = response;
            var x = response;
            var population = numberWithSpaces(x.population);
            $(".pop").text('Population :' + population);
            //percent today cases 
            var pnc = (x.todayCases * 100 / x.cases).toFixed(2);
            $("#pnc").text(pnc + " %");
            var pnd = (x.todayDeaths * 100 / x.deaths).toFixed(2);
            $("#pnd").text(pnd + " %");
            var pnr = (x.todayRecovered * 100 / x.recovered).toFixed(2);
            $("#pnr").text(pnr + " %");
            //percent totale cases 
            var ptc = (x.cases * 100 / x.population).toFixed(2);
            $("#ptc").text(ptc + " %");
            var ptd = (x.deaths * 100 / x.cases).toFixed(2);
            $("#ptd").text(ptd + " %");
            var ptr = (x.recovered * 100 / x.cases).toFixed(2);
            $("#ptr").text(ptr + " %");
            //apply data to elements
            $(".name_country").text("World");
            $("#Cases").text(numberWithSpaces(x.todayCases));
            $("#Deaths").text(numberWithSpaces(x.todayDeaths));
            $("#Recovered").text(numberWithSpaces(x.todayRecovered));
            $("#TotalCases").text(numberWithSpaces(x.cases));
            $("#TotalDeaths").text(numberWithSpaces(x.deaths));
            $("#TotalRecovered").text(numberWithSpaces(x.recovered));
            $("#activetotale").text(numberWithSpaces(x.active));
            $("#testtotal").text(numberWithSpaces(x.tests));
            $("#critical").text(numberWithSpaces(x.critical));
            if (x.todayCases <= 0 && x.todayCases < 10) {
                $("#situation_text").css('color', 'green');
                $("#situation_text").text("GOOD");
            } else if (x.todayCases > 10 && x.todayCases < 100) {
                $("#situation_text").css('color', 'orange');
                $("#situation_text").text("ACCEPTABLE");
            } else if (x.todayCases > 100) {
                $("#situation_text").css('color', 'RED');
                $("#situation_text").text("BAD");
            }

        }

    });
}
function getNews() {
    $.ajax({
        type: 'GET',
        url: "https://covid19-us-api.herokuapp.com/news",
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            var d = data.message;
            $(".body_news").empty();
            for (var i = 0; i < d.length; i++) {

                $(".body_news").append('<div class="news_item">\n\
                            <div class="title_news">' + d[i].title + '</div>\n\
                            <a href="' + d[i].url + '" class="readMore">read More</a>\n\
                            <div class="published">' + d[i].published + '</div>\n\
                            </div>');
            }


        }, error: function (jqXHR, textStatus, errorThrown) {

        }


    });









}
;
function getDataByCountry(x) {
    $.ajax({
        type: "GET",
        url: "https://corona.lmao.ninja/v2/countries/" + x,
        dataType: "json",
        contentType: 'application/json',
        success: function (response) {
            var x = response;
            var population = numberWithSpaces(x.population);
            $(".pop").text('Population :' + population);
            //percent today cases 
            var pnc = (x.todayCases * 100 / x.cases).toFixed(2);
            $("#pnc").text(pnc + " %");
            var pnd = (x.todayDeaths * 100 / x.deaths).toFixed(2);
            $("#pnd").text(pnd + " %");
            var pnr = (x.todayRecovered * 100 / x.recovered).toFixed(2);
            $("#pnr").text(pnr + " %");
            //percent totale cases 
            var ptc = (x.cases * 100 / x.population).toFixed(2);
            $("#ptc").text(ptc + " %");
            var ptd = (x.deaths * 100 / x.cases).toFixed(2);
            $("#ptd").text(ptd + " %");
            var ptr = (x.recovered * 100 / x.cases).toFixed(2);
            $("#ptr").text(ptr + " %");
            //apply data to elements
            $(".name_country").text(x.country);
            $("#Cases").text(numberWithSpaces(x.todayCases));
            $("#Deaths").text(numberWithSpaces(x.todayDeaths));
            $("#Recovered").text(numberWithSpaces(x.todayRecovered));
            $("#TotalCases").text(numberWithSpaces(x.cases));
            $("#TotalDeaths").text(numberWithSpaces(x.deaths));
            $("#TotalRecovered").text(numberWithSpaces(x.recovered));
            $("#image_country").attr('src', x.countryInfo.flag);
            $("#activetotale").text(numberWithSpaces(x.active));
            $("#testtotal").text(numberWithSpaces(x.tests));
            $("#critical").text(numberWithSpaces(x.critical));
            if (x.todayCases <= 0 && x.todayCases < 10) {
                $("#situation_text").css('color', 'green');
                $("#situation_text").text("GOOD");
            } else if (x.todayCases > 10 && x.todayCases < 100) {
                $("#situation_text").css('color', 'orange');
                $("#situation_text").text("ACCEPTABLE");
            } else if (x.todayCases > 100) {
                $("#situation_text").css('color', 'RED');
                $("#situation_text").text("BAD");
            }

        }

    });
}

function numberWithSpaces(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

function getCountries() {

    $.ajax({
        type: "get",
        url: "https://corona.lmao.ninja/v2/countries",
        data: "",
        dataType: "json",
        success: function (response) {
            $(".countries").empty();
            $.map(response, function (value, Key) {
                $(".countries").append("<li value='" + value.country + "'>" + value.country + "</li>");

            });
        }
    });
}
