/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global bloodtype */

///**
// * complete profile
// */
//$("#btn-confirm-profile-details")
//        .click(function () {
//            PatientDetails = {
//                height: $("#height").val(),
//                weight: $("#weight").val(),
//                bloodType: bloodtype,
//                securtiyNumber: $("#securtiyNumber").val(),
//                mobile: $("#mobile").val(),
//                work: $("#work").val()};
//            console.log(PatientDetails);
//            $.map(PatientDetails, function (value, key) {
//                if (value.length > 0) {
//                    $.ajax({
//                        type: 'POST',
//                        url: "user/complete/profile",
//                        dataType: 'json',
//                        contentType: 'application/json',
//                        data: JSON.stringify({patientDetails: PatientDetails}),
//                        success: function (data, textStatus, jqXHR) {
//                            if (data.message === "done") {
//                                $(".block").hide();
//                                $(".box").show();
//                            }
//                            myCostumeAlert(2500, data.message);
//                        },
//                        error: function (jqXHR, textStatus, errorThrown) {
//
//                        }, complete: function (jqXHR, textStatus) {
//
//                        }
//                    });
//                } else {
//
//                    $("#" + key + "").val("must not be empty");
//                }
//            });
//        });