/**
 Created on : Mar 25, 2020, 3:21:22 PM
 Author     : chahir chalouati
 */



/**
 * open modal
 * @type type
 */
$(document).ready(function () {
    $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });
//open modal change password
    $("#name-user").click(function () {
        $("#password-modal").addClass("modal-visible");
        getdepartment();
    });
    $(".close").click(function () {
        $("#password-modal").removeClass("modal-visible");
    });


//style for search input 
    $('body').on('click', '*:not( #search )', function () {
        $('#search ').text("");
        $('#search ').val("");
    });
// open model settings 
    $("#settings").click(function () {
        $("#settings-modal").addClass("modal-visible");
        getdepartment();
    });
    $(".close").click(function () {
        $("#settings-modal").removeClass("modal-visible");
    });
// open model contract 
    $("#btnmodal").click(function () {
        if ($("#email").val() !== '') {
            $("#contract-modal").addClass("modal-visible");
            $('#firstname-span').text($("#firstname").val());
            $('#lastname-span').text($("#lastname").val());
        } else {
            myCostumeAlert(2500, "select employee from table to continue");


        }


    });
    $(".close").click(function () {
        $("#contract-modal").removeClass("modal-visible");
    });


    $(document).on('click', '.show', function () {
        var row = $(this).closest('tr').find('#employee-email').html();
        $.ajax({
            type: 'post',
            cache: false,
            url: "admin/show/One/patient",
            contentType: "application/json",
            dataType: "json",
            data: $.trim(row),
            success: function (data) {
                console.log(data);
                var user = data[0];
                var addresses = data[1];
                var authoritie = data[2];
                var depratment = data[3];
                var contacts = data[4];
// display user
                $("#firstname").val(user.firstname);
                $("#lastname").val(user.lastname);
                $("#email").val(user.email);
                $("#birthDate").val(user.birthDate);
//display address
                $("#province").val(addresses.province);
                $("#street").val(addresses.street);
                $("#building").val(addresses.building);
                $("#house").val(addresses.house);
                $("#city").val(addresses.city);
//display authoritie
                $("#authorities ").val(authoritie.idAuthoritie);
//display department 
                $("#departments ").val(depratment.idDepartment);
//diplay contact 
                $("#mobile").val(contacts.mobile);
                $("#fax").val(contacts.fax);
                $("#phone").val(contacts.phone);
            }
        });
    });




    $("#save").click(function () {

// preparing objects
        var users = {firstname: $("#firstname").val(), lastname: $("#lastname").val(), email: $("#email").val(), birthDate: $("#birthDate").val(), password: $("#password").val()};
        var contacts = {mobile: $("#mobile").val(), fax: $("#fax").val(), phone: $("#phone").val()};
        var addresses = {province: $("#province").val(), street: $("#street").val(), building: $("#building").val(), city: $("#city").val(), house: $("#house").val()};
        var authoritie = {idAuthoritie: $("#authorities").val(), authoritie: $("#authorities option:selected").text()};
        var department = {idDepartment: $("#departments").val(), department: $("#departments option:selected").text()};


        $.ajax({// make a post request
            type: "POST",
            url: "admin/save",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({users: users, contacts: contacts, addresses: addresses, authorities: authoritie, department: department}),
            success: function (data, jqXHR) {
                myCostumeAlert(2500, data.message);
                setTimeout(() => {
                    window.location.href = '/admin';
                }, 2500);
            }
        });


    });
    /**
     * edit employee
     */
    $("#edit").click(function () {
// preparing objects
        var users = {firstname: $("#firstname").val(), lastname: $("#lastname").val(), email: $("#email").val(), birthDate: $("#birthDate").val(), password: $("#password").val()};
        var contacts = {mobile: $("#mobile").val(), fax: $("#fax").val(), phone: $("#phone").val()};
        var addresses = {province: $("#province").val(), street: $("#street").val(), building: $("#building").val(), city: $("#city").val(), house: $("#house").val()};
        var authoritie = {idAuthoritie: $("#authorities").val(), authoritie: $("#authorities option:selected").text()};
        var department = {idDepartment: $("#departments").val(), department: $("#departments  option:selected").text()};
        if (verify_Inputs({users: users, contacts: contacts, addresses: addresses})) {

// make a post request
            $.ajax({
                type: "POST",
                url: "admin/edit",
                contentType: "application/json",
                dataType: "json",
                data: JSON.stringify({users: users, contacts: contacts, addresses: addresses, authorities: authoritie, department: department}),
                success: function (data, jqXHR) {
                    myCostumeAlert(2500, data.message);
                    setTimeout(() => {
                        window.location.href = '/admin';
                    }, 2500);
                }
            });
        }


    });
    $(document).on('click', '.delete', function () {
        var row = $(this).closest('tr').find('#employee-email').html();
        $.ajax({
            type: "POST",
            url: "admin/delete",
            dataType: "json",
            contentType: "application/json",
            data: row,
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2500, data.message);
                setTimeout(() => {
                    window.location.href = '/admin';
                }, 2500);
            }
        });
    });
    $("#search").keyup(function () {
        var search = $.trim($(this).val());
        if (search.length > 0) {
            $.ajax({
                type: "POST",
                url: "admin/search",
                dataType: "json",
                contentType: "application/json",
                data: search,
                success: function (data, textStatus, jqXHR) {
                    if (data.length > 0) {
                        $('table').find('tr').remove();
                        $("table").append("<tr><th>Name</th><th>Email</th><th>Authoritie</th><th>Actions</th></tr>");
                        $.map(data, function (val, i) {
                            var users = val;
                            $("table").append(
                                    "<tr><td>" + users.firstname + " " + users.lastname +
                                    "</td><td id='employee-email'>" + users.email +
                                    "</td><td>" + users.authoritie +
                                    "</td><td><td id='btns'>\n\
<button type='button' class='delete'>\n\
<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABmJLR0QA/wD/AP+gvaeTAAAGpUlEQVR4nO2dS2xUVRjHf2duSysPeRTbIKVPhEB5JLKABEwgGNQEFmBgIxhj4koWslFxgaLRyEoTWRljTAhuQKPBxBhRCRK0phBCGaRimaG2xRZKpzw6j87McdGZWkhL5w73fvfe5vxW7fTM+b7pf875zvnfO2fAYDAYDAaDwWAwGAwGg8FgMBiKQHmdgB2ampqm3I3zntbsAuZN0LxbKQ5Ne4R94XA4JZGfE1heJ2CHaTMq39eaN4AZBTSfAaxLpigdiF3/yeXUHKPE6wTskBsZEFJrr7ZfOP2gtjUNTeuU5leleBHYK5GfE4S8TsAmjwNMJAZAx5XwqdHPCQpBE2TS40lRr61dtoRQ9i1QG5m4OEtzDTiudOiDaLT1knRwcUFqa5c+R0gdBaZKx7bJoNJsi0bDP0gGFRVk/sIV1SWZTCswa2vlPF6prqO6vFwyhQnpTCT4tDPKN73XAGJpy1re9ff5Tqn4osveipmPfQas2lgxlw8XNfFoif8WeY+WlLBhzlz+GrxDJD5YbmkWxGK9R6TiixX1moalGzV6e3koxOt1T0iFLZo36xcxNWSh0dvr6pqelYrr+JTV2LhsQTqrPwI2McYG7rXaRl6eX+N0WFf4vKuDj6+2j/Wn2yiOh7S1NxI53+ZkTEcFyYlxDpgz+nHtdKCHpKZ8Kt89uRqAzWeb6UgMjjyW/300D8j/ZtqyVjpZYxz9P9XWNx0Fnn9qVgX7Fi6makqZk937hp5Ukv3tbZzq70OhjkQjF3Y41bfTNWQTMKnFAKiaUsbbjYsB0OhnnOzb7NQfHu1kZ84KojgOsL+9jZ5U0tGu/URPKsk77SOb+ONO9u1oDamvX7E4S+Y09xX1SczNjMqu6bzy52WnOnR0hEQi59vSlrVSoY4At5zs22fcAr5yWgwQWI3W1Dd1KFjw47aXmDetkOtK/qP77m02ff0FQMfVSLjWzViuF3UFNwD6E3G3Q7lGfzIx/INSN9yOJbDKUn0AsQAX+YHcm0lp3ed2LPcFUfoGQCwZ4BGSGs5da1wfIe7brbrwKWsok+aT5p859k8UpWBLdT27V2+g1Bo7Tbfb5+lPTKIpS6nhKWuggCnrYPMvXO67wZcrVnF4+Srabl7n4O8nPGufZyBXQ7TOBn/KyuZeRKyAEXKsMzJiu+TtiWNdVzxrnyeWEyT/5nIT1wUJ5YZ5fwE1pDeZvMcDq5pSRm9y/JHldvs8+dyVQA0RGCEqV9S9X2XVlBd3GT+WqyHZUDb4gqhsZnjK8sEqK38NxC6xVG7KykyCKcuyQoHfGObrX0lJKPgjJJEo980+ZPPZ5qKel889mZwRfEG6u88MAvFEJkM8nXY73AO5/9JsIcTTQyQyGYB4Z+dvrr+rRC5Q6Zyf5fUoKaaoj/hYcN3RZMZBRBC/GIzFFHVJYxHELuEG12CUNBZBShCfGIzFFHVJYxGkBLFhMLpJMUVd0lgEqRpiw2D0G5LGIggJYsdg9BuSxiIICWLHYPQbksYiiI0Q/xiMdpE0FkGqhvjIYLSLpLEIQoIE2WCUNBZBSBA/GYx2kTQWQUgQPxmMdpA2FkHw7ne/GIx2kDYWQVAQBX0QrDoyShCRgg6inw/JLX0DtFsfMRaR2YOApCA+MRjtIG0sgqQgPjEY7SBtLIJkDQmgwShtLIKgIFIGY7H3Xo2FtLEIgoJIGYzF3ns1FtLGIoiOkOAZjNLGIkjWkAAajNLGIggKEkSDUdpYBEFBgmgwShuLICiIlMFY7O2i9+OFsQjCR2tIGIzF3FkyFl4YiyAsSN5gjP3/Yn3LqP2SWEEH8cNn8nuRAAiS3xQKGosgLcgEBmNlWdk9h9b0pJJUlY1/zJOb7b0wFkFakAkMxi3zG0ZOEsqfuLOlumHc7txs74WxCNI1ZAKDcfea9SyeXckLrWfY2XqGJXOqeHX1+nH7c7O9F8YiCB/Gn9XZPoUa12AstUrYs/Zp9hTYn5vtvTAWQf5EuX8Buu76/+SmrjvDOWp0j2RcUUFC2moFaOnpzm+6fEk8naalpwuArNLnJGOLCpI73L7l7lCKAy0nJUPb4kDLSQbTQwDNTh9QNhHi37Azq6IqjGbXxb5eK3yzl+rpM5lZVk5pyNvzOOPpNOG+Ht5tPsH30csAyRDsiMWud0nm4dXXVWxF6UMopnkRvwDuKK13RqMXv5UO7Ml3UA0M9F6aM3vuYY0qBeYC073KZRRDaKIoddhS7IxELv7hcT4Gg8FgMBgMBoPBYDAYDAaDwWAwGAwGg/v8B2pUsHwNBbQOAAAAAElFTkSuQmCC ' /></button>\n\
<button type='button' class='show'>\n\
<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAAABmJLR0QA/wD/AP+gvaeTAAAFvklEQVR4nO3cbUwTdxwH8O9VNNGWPkAhwyW6RpGHivDSuTl0CSzTTffCh7Ao6lyiEoa+WOLm3NhGGEs2iWIiiyIjahQXkzldxIctzIct6BYdlFoYsFInNVIsrbQjAuH2QjB1QgfX/939h79PQkJ619/9uC93/+s9FCCEEEIIIYQQQgghhBBCCCGEEELISASpb7RarVOCvSgSRawFkMCwp/FyCwIOa6fiI7vd3qdiH0xMkvpGbXR8sShiO4Bohv1IEQ3gxQd9mOz3eX5UuZeIRUl949CWgaziIpiT5rDraJw8TU34YWchBAG5AN5XrRFGNBG8dzoAVcMAgLjk5OFfp6vZByuStxAezbRYRZVbiHg8i2QL4UbIVqK26aKI7T1BfCK1gOSjrOH/xpwTx6WWmHCGxzMAbpfT/qyUGhNiC+EFi/GMAuEM00H99DvbELhzh2VJxekSEvD63t0Anvx7RpoW+hoLNIYwdmzFagCAy2mXtG5pl8UZCoQzFAhnKBDOUCCcoUA4Q4FwhgLhjCqn3zsdDrjOX4DH0YSAzw+dyYD4lBTMzM7i6cytKhQNZHBwEPWVlfA22LA1by0Wl7yLOLMJnq5u1Nb+jD37yhGbno55G9ZDo3k6N15FA6mvrIShx4cTNYeg1U579HrCM3F4M+cNLF+WjY1bdqDh6ypkbHxrXLWVPI/G+vxVKMUC6XQ40G2z4cSZx8MIpdVOQ8W+Yrz8ai48zc2IS0oac325VpDSFNsvuM5fQMGWtaOGMUyn02Lrlly4zp1XqDO+KBaIx9GExYsWjGnexYvmo9PhkLkjPikWSMDnhznWOKZ5zWYTgr77MnfEJ8UC0RkN6OrqHtO8Ho8XOoNe5o74pFgg8akpqP3plzHNW3uxDnGpqTJ3xCfFjrJmZmehrLwcy5dlhx3YA4EgysoPIyM/f1z1WR72hruM++/prCl6Cff3g5XQ+++hYl8xdDrtE9MDgSDezvsAPaY4pG9YL7U1Vf2vLuHO27AePp0RCzJXYldpBdzuu+jv74fbfRdflu7HgsyV8OtjkLYuV8m2uKLoJ/XbdXXo+PU3zE60oKm5FStWbUbXPR/MsUbMtSZjVqIFrVevIdZqxYzn5yvZGjcUC6Th0BH4Gm6guqoUVuvoN2jbGpuxuaAQ/rZWpK1Zo1R73FBkl9V4tBqisxVnTx4MGwYApM1NwrlTBzHQ2gp7dbUS7XFF9kDc12+g69pVHK0qHXEgH4lOp8Wxql3w1NXhzvUbMnfIF1l3WQMP+lB/4AD27y2CwTC+B62MRj12f7ETmwoKEb9nNyZNmRx2/kgOe9W+WzGUrIe9f5z+HmZPB74q+1TqYrAp/0N0J8zA7KVLJNdQEr+HvaKItjM12Ja3LqIyW/Ny0VZzFhDVfhZHGbIF4mluRoxRj+TkWRHVSU1NhF47FfdaWhh1xjf5AqlvwJLshUxqLX3lJXTW1zOpxTvZAgm0tyM9nc0JwvR5KQi2tzOpxTvZAvHdvo05sy1MaiUmWtD9VweTWryT7bD37/s9MJkMTGrFmIwI3g9/wWqinO2VLZAogwGftXghaHwR1xIHBxGlD3/BSq4VpPTNE7IF8loZw8e8NBqm9Xj2dN6NxjEKhDMUCGcoEM5QIJyhQDhDgXBGts8hgwMDsFUfh/PiZfR2P37H4tSYGFgyFyJt9Spoovj6yi61+5ZtbdiOf4ObJ0+NOK3X68XNb7+DKArIWJMjVwuSqN23bLss58XLQ0sQXnA57ULojyhgIQC0X7ok1+IlU7tv2QLp9XoBAK62xidu6L31p/1K6Dw8UbtvGtQ5E0kgbuDh19qRhx49ZCRA8sUbyXedzHjOWiIIeO+/5hvt7gsOvkE0rEj6FkWh5FZ74w4py5W8hURrUSiK+BxDW8pIBOBymBJXpC5bbpL7FtAhikJJtFb8mHlThBBCCCGEEEIIIYQQQgghhBBCyFPuH919IHPvZR68AAAAAElFTkSuQmCC '/></button></td></td></tr>");
                        });
                    } else {
                        if (search.length > 6) {
                            myCostumeAlert(2500, "can't find any employee with this name  employee ");
                        }
                    }

                },
                error: function (jqXHR, textStatus, errorThrown) {
                    myCostumeAlert(2500, "can't find employee ");


                }
            });
        } else {
            window.location.href = "/admin";
        }

    });
    $("#save-contract").click(function () {

        var contract = {
            validatedate: $("#enableContractDate").val(),
            expiredDate: $("#expiredContractDate").val(),
            contractTerms: $("#termsContract").val(),
            typeOfContract: $("#typeOfContract").val()
        };
        $.ajax({

            type: "POST",
            url: "admin/contract",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({hasContracts: contract}),
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2500, data.message);
                setTimeout(() => {
                    window.location.href = '/admin';
                }, 2500);

            },
            error: function (jqXHR, textStatus, errorThrown) {

            }

        });
    });
    $("#save-department").click(function () {
        var department = $("#new-department").val();
        $.ajax({

            type: "POST",
            url: "admin/save/department",
            dataType: "json",
            contentType: "application/json",
            data: department,
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2500, data.message);

                getdepartment();
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }

        });
    });

    /**
     * change passsword
     */
    $('#btn-change-password').click(function () {
        var currentPassword = $("#current-password").val();
        var newPassword = $("#new-password").val();

        if ($.trim(currentPassword).length > 0 && $.trim(newPassword).length > 0) {
            $.ajax({

                type: 'POST',
                url: "admin/change/password",
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({currentPassword: currentPassword, newPassword: newPassword}),
                success: function (data, textStatus, jqXHR) {
                    myCostumeAlert(2500, data.message);

                    setTimeout(() => {
                        $("#password-modal").removeClass("modal-visible");
                        $("#current-password").val('');
                        $("#new-password").val('');
                    }, 1000);

                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
        } else {
        }

    });


});
/**
 * get all department
 * @returns {Boolean}
 */
function getdepartment() {
    $.ajax({
        type: 'GET',
        cache: false,
        url: "admin/department",
        contentType: "application/json",
        dataType: "json",
        success: function (data, textStatus, jqXHR) {
            $.map(data, function (value, key) {
                $("#list-dept").append(" <li>" + value.department + "</li>");
            });
        },
        error: function (jqXHR, textStatus, errorThrown) {
            myCostumeAlert(2500, "sorry we can't show department ");


        }
    });
}
;
/**
 * verifie input 
 * @param {type} arr
 * @returns {undefined}
 */
function verify_Inputs(arr) {
    var verifiy;

    $.map(arr, function (value, key) {

        $.map(value, function (valuex, keyx) {
            if ($.trim(valuex) !== "") {
                verifiy = true;
                return true;
            } else {
                $("#" + keyx + "").attr("placeholder", "" + keyx + " must not be empty ");
                verifiy = false;
                return false;
            }

        });
    });
    return verifiy;
}
;


