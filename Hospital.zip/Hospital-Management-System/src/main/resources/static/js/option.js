/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function () {

    $.getScript("/js/myComponent.js", function (script, textStatus, jqXHR) {
    });

    var departments = [];
    loadDepartments();
    getAllContracts();
    /**
     * get all departments // 
     */
    function loadDepartments() {
        $.ajax({
            type: 'GET',
            url: "/admin/getAll/departments",
            dataType: 'json',
            contentType: 'application/json',
            //  data: $(this).val(),
            success: function (data) {
                //   department = data;
                // console.log(department);
                $("#departments").empty();
                $("#departments").append("<option class='opt' value=''>Select Department :</option>");
                $.map(data, function (value, key) {
                    $("#departments").append("<option class='opt' value='" + value.idDepartment + "'>" + value.department + "</option>");
                });
            }, error: function (jqXHR, textStatus, errorThrown) {
                alert("failed to load department server problem");

            }


        });
    }
    ;

    // get one department details
    $(document).on("change", "#departments", function () {
        var idDepartment = $(this).children("option:selected").val();
        //   alert(idDepartment);
        $.ajax({
            type: 'POST',
            url: "/admin/details/department",
            dataType: 'json',
            contentType: 'application/json',
            data: idDepartment,
            success: function (data) {
                // conserve department
                Departments = data;

                // inputs values 
                $('#department').val(Departments.department);
                $('#costappointment').val(Departments.costappointment);
                $('#costHospitlyze').val(Departments.costHospitlyze);
                $('#costAnalysis').val(Departments.costAnalysis);




            }, error: function (jqXHR, textStatus, errorThrown) {

            }
        });


    });


    // load table contracts 

    var Contracts = [];
    var contract = {};


    function getAllContracts() {
        $.ajax({
            type: 'GET',
            url: "/admin/get/all/contracts/",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                $("#contracts-table").remove("row");
                Contracts = data;
                loadDataTable(Contracts);
            },
            error: function (jqXHR, textStatus, errorThrown) {
                myCostumeAlert(3000, "sorry can't load data ");


            }
        });
    }
    ;



    function loadDataTable(data) {
        $("#contracts-table").append('<tr><th>ID</th><th>Employee</th><th>Validity</th><th>Expired</th><th>Date Validate</th><th>Date Expire</th></tr>');

        $.map(data, function (value, key) {
            var contract = value[0];
            var expired;
            var valid;
            if (contract.expired) {
                expired = 'expired';

            } else {
                expired = 'valid ';
            }
            var firstname = value[1];
            var lastname = value[2];

            $("#contracts-table")
                    .append('<tr class="row">\n\
                <td>' + contract.idContracts + '</td>\n\
                <td>' + firstname + ' ' + lastname + '</td>\n\
                <td>' + expired + '</td>\n\
                <td>' + contract.typeOfContract + '</td>\n\
                <td>' + contract.validatedate + '</td>\n\
                <td>' + contract.expiredDate + '</td>\n\
                </tr>');
        });
    }



    /**
     * search in contracts
     */
    $("#search-contract").keyup(function () {
        if ($(this).val().length > 0) {

            $.ajax({
                type: 'POST',
                url: "/admin/option/search/contract",
                dataType: 'json',
                contentType: 'application/json',
                data: $(this).val(),
                success: function (data, textStatus) {
//                    console.log(data);
//                    console.log(textStatus);
                    if (data.length > 0) {
                        $("#contracts-table").empty();
                        loadDataTable(data);
                    } else {
                        myCostumeAlert(2000, " no contract found ");
                    }

                }, error: function (jqXHR, textStatus, errorThrown) {
                    myCostumeAlert(2000, "sorry can't find data ");
                }
            });
        } else {
            $("#contracts-table").empty();
            loadDataTable(Contracts);
        }

    });




    /**
     * add department
     */

    var Departments = {};
    $("#btn-department").click(function () {

        // prepare department object 
        Departments.department = $('#department').val();
        Departments.costappointment = $('#costappointment').val();
        Departments.costHospitlyze = $('#costHospitlyze').val();
        Departments.costAnalysis = $('#costAnalysis').val();
        $.ajax({
            type: 'POST',
            url: "/admin/save/new/department",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({Departments: Departments}),
            success: function (data, textStatus, jqXHR) {

                // clear  inputs values 
                $('#department').val();
                $('#costappointment').val();
                $('#costHospitlyze').val();
                $('#costAnalysis').val();
                myCostumeAlert(2000, "done");

                loadDepartments();

            },
            error: function (jqXHR, textStatus, errorThrown) {
                setTimeout(() => {
                    window.location.href = "/admin/options";
                }, 1000);

            }
        });
    });

    /**
     * delete department
     *
     */

    $("#btn-department-delete").click(function () {

        $.ajax({
            type: 'POST',
            url: "/admin/delete/department",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({Departments: Departments}),
            success: function (data, textStatus, jqXHR) {

                // clear  inputs values 
                $('#department').val('');
                $('#costappointment').val('');
                $('#costHospitlyze').val('');
                $('#costAnalysis').val('');
                loadDepartments();
                myCostumeAlert(2000, "deleted with success");

            },
            error: function (jqXHR, textStatus, errorThrown) {
                setTimeout(() => {
                    window.location.href = "/admin/options";
                }, 1000);

            }
        });
    });


    // get All surgeries

    var Surgeries = [];
    var surgery = {};
    loadSurgery();

    /**
     * get one surgery 
     */
    $(document).on("change", "#Surgeries", function () {
        var index = $(this).children("option:selected").index();
        surgery = Surgeries[index];
        console.log(surgery);
        $("#cost").val(Surgeries[index].cost);
        $("#typeOfSurgery").val(Surgeries[index].typeOfSurgery);

    });

    /**
     * save / update  new surgery 
     * 
     */

    $("#btn-surgery").click(function () {
        surgery.typeOfSurgery = $('#typeOfSurgery').val();
        surgery.cost = $('#cost').val();
        $.ajax({type: 'POST',
            url: "/admin/new/surgery",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({surgery: surgery}),
            success: function (data, textStatus, jqXHR) {
                loadSurgery();
                $("#cost").val('');
                $("#typeOfSurgery").val('');
                myCostumeAlert(2000, "done");

            },
            error: function (jqXHR, textStatus, errorThrown) {
                myCostumeAlert(2000, "can't save this department ");
            }


        });

    });

    /**
     * 
     *delete surgery
     */
    $("#btn-delete-surgery").click(function () {
        $.ajax({
            type: 'POST',
            url: "/admin/delete/surgeries",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({surgery: surgery}),
            success: function (data, textStatus, jqXHR) {
                loadSurgery();
                $("#cost").val('');
                $("#typeOfSurgery").val('');
                myCostumeAlert(2000, "deleted with success");
            }, error: function (jqXHR, textStatus, errorThrown) {
                myCostumeAlert(2000, "can't delete this surgery");
            }
        });
    });


    function loadSurgery() {
        $("#Surgeries").empty();
        $.ajax({
            type: 'GET',
            url: "/admin/get/surgeries",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                Surgeries = data;
                $.map(Surgeries, function (value, key) {
                    $("#Surgeries").append('<option value="' + value.idSurgery + '">' + value.typeOfSurgery + '</option>');
                });
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
    }


    var myarr = [];
    var patientCount = 0;
    var appointment = 0;
    var hospitlyzed = 0;
    $.ajax(
            {
                type: 'GET',
                url: "/admin/get/hospital/details",
                dataType: 'json',
                contentType: 'application/json',
                success: function (data, textStatus, jqXHR) {
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels:
                                    ['Patient Number',
                                        'Patient appointment',
                                        'Patient hospitlyzed'
                                    ],
                            datasets: [{
                                    label: 'Patient Number',
                                    data: data,
                                    backgroundColor: [
                                        'rgba(255, 99, 132, 0.2)',
                                        'rgba(54, 162, 235, 0.2)',
                                        'rgba(255, 206, 86, 0.2)'

                                    ],
                                    borderColor: [
                                        'rgba(255, 99, 132, 1)',
                                        'rgba(54, 162, 235, 1)',
                                        'rgba(255, 206, 86, 1)'

                                    ],
                                    borderWidth: 0.5
                                }]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                        ticks: {
                                            beginAtZero: true
                                        }
                                    }]
                            }
                        }
                    });
                }, error: function (jqXHR, textStatus, errorThrown) {
                    alert(" can't find details sorry ");
                }
            }

    );

    var ctx = document.getElementById('myChart').getContext('2d');
















});
