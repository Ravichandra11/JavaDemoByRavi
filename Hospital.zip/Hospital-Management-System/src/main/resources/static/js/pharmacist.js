/*
 To change this license header, choose License Headers in Project Properties.
 To change this template file, choose Tools | Templates
 and open the template in the editor.
 */
/* 
 Created on : Mar 25, 2020, 3:21:22 PM
 Author     : chahir chalouati
 */


$(document).ready(function () {
    $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });
    //open modal change password
    $("#name-user").click(function () {
        $("#password-modal").addClass("modal-visible");
        getdepartment();
    });
    $(".close").click(function () {
        $("#password-modal").removeClass("modal-visible");
    });
    /**
     * change passsword
     */

    $('#btn-change-password').click(function () {
        var currentPassword = $("#current-password").val();
        var newPassword = $("#new-password").val();

        if ($.trim(currentPassword).length > 0 && $.trim(newPassword).length > 0) {
            $.ajax({

                type: 'POST',
                url: "pharmacist/change/password",
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({currentPassword: currentPassword, newPassword: newPassword}),
                success: function (data, textStatus, jqXHR) {
                    myCostumeAlert(3000, data.message);
                    setTimeout(() => {
                        $("#password-modal").removeClass("modal-visible");
                        $("#current-password").val('');
                        $("#new-password").val('');
                    }, 3000);

                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
        } else {
        }

    });
    //load all medicines 
    var medicines = [];
    var medicinesPatient = [];
    $.ajax({
        type: 'GET',
        url: "pharmacist/get/all/medicines",
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            $('#availble-medicines').empty();

            $.map(data, function (value, key) {
                $('#availble-medicines').append('<li value="' + value.idMedecine + '">' + value.nameMedecine + '</li>');
                medicines.push(value);
            });

        }, error: function (jqXHR, textStatus, errorThrown) {

        }, complete: function (jqXHR, textStatus) {

        }


    });
//load all has medicines 
    var patients = [];
    $.ajax({
        type: 'GET',
        url: "pharmacist/get/all/hasmedicines/patient",
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {

            $.map(data, function (value, key) {
                patients.push(value);
                $('#list-patient').append('<li value="' + value.email + '">' + value.firstname + '' + value.lastname + '</li>');
            });

        }



    });


    var patient = {};
    var total = 0;
    $(document).on('click', "#list-patient li", function () {
        var index = $(this).index();
        patient = patients[index];

        $('#firstname').val(patient.firstname);
        $('#lastname').val(patient.lastname);
        $('#security-number').val(patient.securtiyNumber);

        $.ajax({
            type: 'POST',
            url: "pharmacist/get/all/medicines/by/patient",
            contentType: 'application/json',
            dataType: 'json', data: patient.securtiyNumber.toString(),
            success: function (data, textStatus, jqXHR) {
                $('#list-described-medicines').empty();
                total = 0;
                $.map(data, function (value, key) {
                    //  medicinesPatient.push(value);
                    //console.log(value);
                    if (value.availble === false) {
                        $('#list-described-medicines').append('<li style="color:red;" value="' + value.idMedecine + '">' + value.nameMedecine + '</li>');

                    } else {
                        $('#list-described-medicines').append('<li style="color:green;" value="' + value.idMedecine + '">' + value.nameMedecine + '</li>');
                        total = total + value.price;
                    }


                });
                $("#total").val(Number(total).toFixed(2) + " $");
            }, error: function (jqXHR, textStatus, errorThrown) {

            }, complete: function (jqXHR, textStatus) {

            }


        });



    });

    /**
     * payed action
     */
    $("#btn-payed").click(function () {
        if (patient.firstname.length > 0) {
            $.ajax({
                type: 'POST',
                url: "pharmacist/payed",
                dataType: 'json',
                contentType: 'application/json',
                data: patient.securtiyNumber.toString(),
                success: function (data, textStatus, jqXHR) {
                    myCostumeAlert(2000, "payed with Success");
                    setTimeout(() => {
                        window.location.href = "/pharmacist";
                    }
                    , 2000);

                }


            });
        } else {

            myCostumeAlert(2000, "select patient from list first");
        }


    });



    $(".close").click(function () {
        $("#patient-Modal").removeClass("modal-visible");

    });
//    $(document).on('click', "#list-described-medicines li", function () {
//        $("#medicines-patient-Modal").addClass("modal-visible");
//
//    });

    $(".close").click(function () {
        $("#medicines-patient-Modal").removeClass("modal-visible");

    });

    $(document).on('click', "#availble-medicines li", function () {
        var index = $(this).index();
        var medicine = medicines[index];

        $('#nameMedecine').val(medicine.nameMedecine);
        $('#quantity').val(medicine.quantity);
        $('#price').val(medicine.price);

        $.ajax({
            type: 'POST',
            url: "pharmacist/take/id",
            dataType: 'json',
            contentType: 'application/json',
            data: medicine.idMedecine.toString(),
            success: function (data, textStatus, jqXHR) {

            }


        });


    });
    $(".close").click(function () {
        $("#medicines-Modal").removeClass("modal-visible");

    });
    /**
     * find medicines
     */
    $("#search-for-medicines").keyup(function () {
        if ($.trim($(this).val()).length > 0) {
            $.ajax({
                type: 'POST',
                url: "pharmacist/find/medicines",
                contentType: 'application/json',
                dataType: 'json',
                data: $.trim($(this).val()),
                success: function (data, textStatus, jqXHR) {
                    $('#list-described-medicines').empty();
                    medicines = [];

                    $('#availble-medicines').empty();
                    $.map(data, function (value, key) {
                        $('#availble-medicines').append('<li value="' + value.idMedecine + '">' + value.nameMedecine + '</li>');
                        medicines.push(value);
                    });

                }, error: function (jqXHR, textStatus, errorThrown) {

                }, complete: function (jqXHR, textStatus) {

                }


            });
        } else {
            medicines = [];
            $.ajax({
                type: 'GET',
                url: "pharmacist/get/all/medicines",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $('#availble-medicines').empty();
                    $.map(data, function (value, key) {
                        $('#availble-medicines').append('<li value="' + value.idMedecine + '">' + value.nameMedecine + '</li>');
                        medicines.push(value);
                    });
                }
            });
        }


    });

    /**
     * find patient
     */

    $("#search-for-patient").keyup(function () {
        var search = $("#search-for-patient").val();
        if (search.length > 0) {
            $.ajax({
                type: 'POST',
                url: "pharmacist/find/hasmedicines/patient",
                contentType: 'application/json',
                dataType: 'json',
                data: search,
                success: function (data, textStatus, jqXHR) {
                    $('#list-patient').empty();
                    patients = [];
                    $.map(data, function (value, key) {
                        patients.push(value);
                        $('#list-patient').append('<li value="' + value.email + '">' + value.firstname + '' + value.lastname + '</li>');
                    });
                }
            });
        } else {
            patients = [];
            $.ajax({
                type: 'GET',
                url: "pharmacist/get/all/hasmedicines/patient",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    patients = [];
                    $('#list-patient').empty();
                    $.map(data, function (value, key) {
                        patients.push(value);
                        $('#list-patient').append('<li value="' + value.email + '">' + value.firstname + '' + value.lastname + '</li>');
                    });
                }
            });
        }

    });


    /**
     * insert new medicines 
     */

    $("#save").click(function () {

        var nameMedicines = $('#nameMedecine').val();
        var quantity = $('#quantity').val();
        var price = $('#price').val();
        var Medicines = {nameMedicines: nameMedicines, quantity: quantity, price: price};

        $.ajax({
            type: 'POST',
            url: "pharmacist/save/medicines",
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(Medicines),
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(1000, data.message);
                setTimeout(() => {
                    window.location.href = "/pharmacist";
                }, 1000);

            }

        });


    });


    /**
     * edit medicines
     */
    $("#edit").click(function () {
        var nameMedicines = $('#nameMedecine').val();
        var quantity = $('#quantity').val();
        var price = $('#price').val();
        var Medicines = {nameMedicines: nameMedicines, quantity: quantity, price: price};

        $.ajax({
            type: 'POST',
            url: "pharmacist/edit/medicines",
            contentType: 'application/json',
            dataType: 'json',
            data: JSON.stringify(Medicines),
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(1000, data.message);
                setTimeout(() => {
                    window.location.href = "/pharmacist";
                }, 1000);
            }

        });
    });
    /**
     * delete medicines
     */
    $("#delete").click(function () {
        $.ajax({
            type: 'POST',
            url: "pharmacist/delete",
            contentType: 'application/json',
            dataType: 'json',
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(1000, data.message);
                setTimeout(() => {
                    window.location.href = "/pharmacist";
                }, 1000);
            }

        });
    });


//    var x = 0;
//    setInterval(() => {
//        test();
//
//    },0);
//
//    function test() {
//        setTimeout(() => {
//            console.log(x); 
//            x++;
//        }, 1000);
//     
//
//    }
//    ;


});
