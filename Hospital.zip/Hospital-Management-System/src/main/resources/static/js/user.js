/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* global email, Appointment, value, Stomp */

$(document).ready(function () {
    /**
     * import for js Mycomponent
     */
    $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });

    connect();//connect to websocket
    getDoctors();// get doctors
    var mail = '';
    $(document).on('click', ".doctor_item", function (e) {
        $(".list_doctor").css("display", "none");
        $(".message-box").css("display", "flex");
        $('.list_message').animate({
            scrollTop: $(".list_message").offset().top + $(".list_message").height() + $(".list_message").height() * 1000
        }, 'slow');

        $(".to_message").text($(this).text());
        mail = $(this).attr('data');
        getMessage(mail);
    });


    /**
     * get all messages rceived from doctor
     */
    $.ajax({
        url: "user/get/all/message/doctor",
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json',
        success: function (data, textStatus, jqXHR) {
            $(".list-doc-advice").empty();
            $.map(data, function (value, key) {

                $(".list-doc-advice")
                        .append('<li><div class="nameDoc">' + value.idDoctor.firstname + ' ' +
                                value.idDoctor.lastname + '</div> <div class="dateAd">' + value.dateRegsiterSituation + '</div> <div class="advice"> ' + value.situation + ' </div></li>');

            });

        },
        error: function (jqXHR, textStatus, errorThrown) {

        }
    });
    /**
     * save patient details 
     */
    var bloodtype = '';
    $("#bloodtype").change(function () {
        bloodtype = $(this).children("option:selected").val();
    });


    /*
     * get all doctor
     */
    function getDoctors() {


        $.ajax({
            type: 'GET',
            url: "user/get/all/doctor",
            contentType: 'application/json',
            dataType: 'json',
            success: function (data, textStatus, jqXHR) {
                $(".list_doctors").empty();
                $("#doctor-list-appointments").empty();
                $("#doctor-list-contact").append('<option>Select doctor to speack with :</option>');
                $.map(data, function (value, key) {
                    var doctor_item = '<li class="doctor_item" data="' + value.email + '"> <div> <span>' + value.firstname + ' ' + value.lastname + '</span><span>x</span></div></li>';
                    $(".list_doctors").append(doctor_item);
                    $("#doctor-list-contact").append('<option value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');
                    $("#doctor-list-appointments").append('<option value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');


                });
            }
        });
    }

    $(document).on('change', '#doctor-list-contact', function () {
        email = $(this).children("option:selected").val();
        getMessage(email);
    });

    /**
     * send message for your doctor
     */
    $("#btn-send-contact-doctor").on('click', function () {
        var message = $(".textarea-message").val();
        send({message: message, to: mail});

        var message_item = '<div class="message background_blue">\n\
                            <span class="identificator">you</span>\n\
                            <p>' + message + '</p> \n\
                             <span class="visto"></span>\n\
                             <span class="new_message"></span> \n\
                            </div>';
        $(".list_message").append(message_item);
        $('.list_message').animate({
            scrollTop: $(".list_message").offset().top + $(".list_message").height() + $(".list_message").height() * 1000
        }, 'slow');

        $(".textarea-message").val('');
    });



    function getMessage(email) {
        $.ajax({
            type: 'GET',
            url: "user/get/message/" + email,
            contentType: 'application/json',
            dataType: 'json',

            success: function (data, textStatus, jqXHR) {
                $(".list_message").empty();
                $.map(data, function (value, key) {

                    var content = value.contentMessage;
                    var seeIt = value.seeIt;
                    var x = '';
                    if (value.idSender.email !== email) {
                        x = 'you';
                        var message_item =
                                '<div class="message background_blue">\n\
                            <span class="identificator">' + x + '</span>\n\
                            <p>' + content + '</p> \n\
                             <span class="visto"></span>\n\
                             <span class="new_message">' + seeIt + '</span> \n\
                            </div>';

                        $(".list_message").append(message_item);
                    } else {
                        x = 'doctor';
                        var message_item =
                                '<div class="message background_white">\n\
                            <span class="identificator">' + x + '</span>\n\
                            <p>' + content + '</p> \n\
                             <span class="visto"></span>\n\
                             <span class="new_message">' + seeIt + '</span> \n\
                            </div>';

                        $(".list_message").append(message_item);
                    }


                });
            }, error: function (jqXHR, textStatus, errorThrown) {


            }, complete: function (jqXHR, textStatus) {

            }});
    }


    $(document).on('change', '#doctor-list-appointments', function () {
        email = $(this).children("option:selected").val();
    });
    /**
     * search for a doctor by firstname
     */
    $("#search-doctor-input").keyup(function () {
        if ($(this).val().length > 0) {
            $.ajax({
                type: 'GET',
                url: "user/get/all/doctor/" + $(this).val(),
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    if (data.length === 0) {
                        myCostumeAlert(2000, "No doctor was found with this name ");
                    } else {
                        $("#doctor-list-appointments").empty();
                        $.map(data, function (value, key) {
                            $("#doctor-list-appointments").append('<option class="opt" value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');
                        });
                    }
                }
            });
        } else {

            getDoctors();
        }
    });









    /**
     * create new appointment---> created by patient him self  
     */

    $("#btn-save-appointment").click(function () {
        var Appointment = {dateAppointment: $('#date-Appointment').val(), timeAppointment: $('#time-appointment').val(), doctorMail: email};
        if (Appointment.dateAppointment.length > 0 && Appointment.timeAppointment.length > 0 && Appointment.doctorMail.length > 0) {

            // make a post request

            $.ajax({
                type: "POST",
                url: "user/create/appointment",
                contentType: "application/json",
                dataType: "json",
                data: JSON.stringify(Appointment),
                success: function (data, jqXHR) {
                    myCostumeAlert(2000, data.message);
                    setTimeout(() => {
                        window.location.href = "/user";
                    }, 2000);
                }
            });
        } else {
            alert("choose doctor and then choose date and time for appointment");
        }


    });


});

/**
 * 
 * socket logic
 */
var stompClient;
/**
 * disconnecht from socket 
 * @returns {undefined}
 */
function disconnect() {
    if (stompClient) {
        stompClient.disconnect();
        stompClient = null;

    }
}
;
/**
 * start receiving data 
 * @returns {undefined}
 */
function start() {
    if (stompClient) {
        stompClient.send('/swns/start', {});
    }
}
;
//test message 
function send(message) {
    if (stompClient) {
        stompClient.send('/swns/send', {}, JSON.stringify(message));
    }
}
;


/**close connection
 * 
 * @returns {undefined}
 */
function close() {
    if (stompClient) {
        stompClient.send('/swns/stop', {});
    }
}
;

/**
 * connect to socket 
 * @returns {undefined}
 */
function connect() {
    if (!stompClient) {
        const socket = new SockJS("http://localhost:8080/notifications");
        stompClient = Stomp.over(socket);
        //stompClient.debug = null;
        stompClient.connect({}, function () {
            stompClient.subscribe('/user/notification/item', function (response) {
                var y = JSON.parse(response.body);
                // console.log(y);



            });
        });
        // start receiving messages 
        setTimeout(() => {
            start();

        }, 3000);

    }
}








