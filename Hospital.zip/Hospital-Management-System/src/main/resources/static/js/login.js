
/* 
 Created on : Mar 25, 2020, 3:21:22 PM
 Author     : chahir chalouati
 */

/**
 * prevent from from submition if  fields are empty 
 * @type type
 */
$(document).ready(function () {

 $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });
    $("#password-forgot").click(function () {
        $("#forgot-password-modal").addClass("alert-visible ");
        $("#forgot-password-modal").removeClass("hide");


    });

    /**
     * recover passowrd
     */
    $("#btn-forgot-passsword").click(function () {
        var email = $.trim($("#email-recover").val());
        if (email.length > 0) {

            $.ajax({
                type: 'POST',
                url: "login/recover/password",
                contentType: 'application/json',
                dataType: 'json',
                data: email,
                success: function (data, textStatus, jqXHR) {
                    $("#email-recover").val('');
                    if (data.message === "Invalid E-Mail") {
                        $("#email-recover").val('');

                    } else {
                        $("#forgot-password-modal").removeClass("alert-visible ");
                        $("#forgot-password-modal").addClass("hide");
                     
                    }
                    alert(data.message);

                },
                error: function (jqXHR, textStatus, errorThrown) {

                },
                complete: function (jqXHR, textStatus) {

                }


            });


        } else {
            alert("invalid email");
        }



    });
    $("#close").click(function (e) {
        $("#forgot-password-modal").removeClass("alert-visible ");
        $("#forgot-password-modal").addClass("hide");
    });

    $(".alert").addClass("hide");

    $('#form').submit(function () {
        if ($.trim($("#username").val()) === "" || $.trim($("#password").val()) === "") {

            $(".alert").removeClass("hide");
            $(".alert").addClass("alert-visible");
            $(".alert").css('height', "10%");
            $(".alert").css('text-transform', "uppercase");
            $(".alert p").text('you did not fill out one of the fields');
            setTimeout(() => {
                $(".alert").removeClass("alert-visible");
                $(".alert").addClass("hide");
                $(".alert p").text('');
            }, 3000);
            return false;
        }
    });

});