/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function () {
    $.getScript("/js/myComponent.js", function (script, textStatus, jqXHR) {
    });



    setTimeout(() => {
        $(".hide").addClass("confirm");

    }, 1500);

    $(document).on("click", "#confirm", function () {

        AddLoading();
        $.ajax({

            type: 'POST',
            url: "nurse/confirm/invoice",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                removeLoading();
                myCostumeAlert(3000, data.message);
                setTimeout(() => {
                    window.location.href = "/nurse";
                }, 3000);



            },
            error: function (jqXHR, textStatus, errorThrown) {

            }


        });
    });

    $("#cancel").click(function () {

        AddLoading();

        $.ajax({

            type: 'POST',
            url: "nurse/cancel/invoice",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                removeLoading();
                myCostumeAlert(3000, data.message);
                setTimeout(() => {
                    window.location.href = "/nurse";
                }, 3000);


            },
            error: function (jqXHR, textStatus, errorThrown) {

            }


        });

    });

});

