/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * var container data 
 * @type Array
 */
var radiologyDetails = [];
var analysisDetails = [];
var time = 60000;
var patient;
var load = false;
/**
 * functions load data automatically every 5 seconds 
 * @returns {undefined}
 */


/**
 *  get all radiology every 5 seconds
 * @returns {undefined}
 */
function getradiology() {
    $.ajax({
        type: 'GET',
        url: "nurse/get/all/hasRadiology",
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            $("#list-req-radiology").empty();
            radiologyDetails = data;
            //  console.log("radiology" + data);

            $.map(data, function (value, key) {
                var radiology = value;
                $("#list-req-radiology").append('<li>' + radiology.firstname + ' ' + radiology.lastname + '</li>');
            });
        }, complete: function (data) {
            setTimeout(getradiology, time);
        }

    });
}
;
/**
 * get all analysis every 5 seconds 
 * @type type
 */
function getAnalysis() {
    $.ajax({
        type: 'GET',
        url: "nurse/get/all/hasAnalysis",
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            $('#list-req-analysis').empty();
            analysisDetails = data;
            //  console.log("hasanalysis " + data);
            $.map(data, function (value, key) {
                var analysis = value;
                $('#list-req-analysis').append('<li>' + analysis.firstname + ' ' + analysis.lastname + '</li>');
            });
        }, complete: function (data) {
            setTimeout(getAnalysis, time);
        }

    });
}
;
/**
 * start 
 * @type type
 */
$(document).ready(function () {

    $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });

    /**
     * change passsword
     */

    $('#btn-change-password').click(function () {
        var currentPassword = $("#current-password").val();
        var newPassword = $("#new-password").val();
        if ($.trim(currentPassword).length > 0 && $.trim(newPassword).length > 0) {
            $.ajax({

                type: 'POST',
                url: "nurse/change/password",
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({currentPassword: currentPassword, newPassword: newPassword}),
                success: function (data, textStatus, jqXHR) {
                    // alert(data.message);

                    myCostumeAlert(3000, data.message);
                    setTimeout(() => {
                        $("#password-modal").removeClass("modal-visible");
                        $("#current-password").val('');
                        $("#new-password").val('');
                    }, 1000);
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
        } else {
        }

    });
    //open modal change password
    $("#name-user").click(function () {
        $("#password-modal").addClass("modal-visible");
        getdepartment();
    });
    $(".close").click(function () {
        $("#password-modal").removeClass("modal-visible");
    });
    setTimeout(getradiology, 10);
    setTimeout(getAnalysis, 10);
    /**
     * open modal appointmments
     */
    $("#btn-Appointments").click(function () {
        //get all patient
        $.ajax({
            type: 'GET',
            url: "nurse/get/all/patient",
            contentType: 'application/json',
            dataType: 'json',
            success: function (data, textStatus, jqXHR) {

                console.log(data);

                $("#patient-list-appointments").empty();
                $.map(data, function (value, key) {
                    $("#patient-list-appointments").
                            append('<option value="' + value.securtiyNumber + '">' + value.firstname + ' ' + value.lastname + '</option>');
                });
            }
        });
        //get all doctor
        $.ajax({
            type: 'GET',
            url: "nurse/get/all/doctor",
            contentType: 'application/json',
            dataType: 'json',
            success: function (data, textStatus, jqXHR) {
                $("#doctor-list-appointments").empty();
                $.map(data, function (value, key) {
                    $("#doctor-list-appointments").append('<option value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');
                });
            }
        });
        $("#appointments").addClass("modal-visible");
    });
    var recovers = [];
    var recovered = {};
    $("#btn-revover").click(function () {

        /**
         * find recover patient 
         */
        $.ajax({
            url: "nurse/recover/patient",
            type: 'GET',
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                if (data.length > 0) {
                    $("#recover-title").text('List of patient to recover today :');
                    $("#indication").text('click on item from list to see his bill');
                    $("#recover-title").css('color', 'black');
                    $("#list-patient-to-recover").empty();
                    $.map(data, function (value, key) {
                        //  console.log(value);
                        recovers.push(value);
                        $("#list-patient-to-recover").append("<li value='" + value.email + "'>" + value.firstname + " " + value.firstname + "</li>");
                    });
                } else {
                    $("#recover-title").text('no recover find ');
                    $("#recover-title").css('color', 'red');

                }

            }, error: function (jqXHR, textStatus, errorThrown) {

            }




        });
        $("#recover").addClass("modal-visible");
    });
    // redirect to recover page 
    $(document).on("click", "#list-patient-to-recover li", function () {

        var index = $(this).index();
        //  console.log(recovers[index].email);
        // data to server 

        AddLoading();
        $.ajax({
            type: 'POST',
            url: "nurse/prepare/recover/bill",
            dataType: 'json',
            contentType: 'application/json',
            data: recovers[index].email,
            success: function (data, textStatus, jqXHR) {
                removeLoading();
                window.location.href = "nurse/bill";



            },
            error: function (jqXHR, textStatus, errorThrown) {
            },
            complete: function (jqXHR, textStatus) {

            }
        });
    });
    $("#btn-register").click(function () {
        $("#register-patient").addClass("modal-visible");
    });
    $(".close").click(function () {
        $("#appointments").removeClass("modal-visible");
    });
    $(".close").click(function () {
        $("#register-patient").removeClass("modal-visible");
    });
    $(".close").click(function () {
        $("#recover").removeClass("modal-visible");
    });
    // open modal analysis by selected li
    $(document).on("click", "#list-req-analysis li", function () {
        patient = analysisDetails[$(this).index()];
        // send id 
        var id = patient.email;
        $.ajax({type: 'POST', url: "nurse/get/id", dataType: 'json', contentType: 'application/json', data: id});
        $('#firstname-display').val(patient.firstname);
        $('#lastname-display').val(patient.lastname);
        $('#security-number-display').val(patient.securtiyNumber);
        $('#bloodType-display').val(patient.bloodType);
        setTimeout(getAnalysis, 10);
        $("#analysis-patient").addClass("modal-visible");
        $(".namePatient").text(patient.firstname + ' ' + patient.lastname);
    });
    $(".close").click(function () {
        $("#analysis-patient").removeClass("modal-visible");
    });
    // open modal radiology by selected li
    $(document).on("click", "#list-req-radiology li", function () {

        patient = radiologyDetails[$(this).index()];
        // send id 
        var id = patient.email;
        $.ajax({type: 'POST', url: "nurse/get/id", dataType: 'json', contentType: 'application/json', data: id});
        $('#firstname-display').val(patient.firstname);
        $('#lastname-display').val(patient.lastname);
        $('#security-number-display').val(patient.securtiyNumber);
        $('#bloodType-display').val(patient.bloodType);
        $(".namePatient").text(patient.firstname + ' ' + patient.lastname);
        setTimeout(getradiology, 10);
        $("#radiology-patient").addClass("modal-visible");
    });
    $(".close").click(function () {
        $("#radiology-patient").removeClass("modal-visible");

        $('#img-xray').hide();
        $('#img-xray').attr('src', "");
    });
    /**
     * search in request analysis
     */

    $('#search-Analysis-input').keyup(function () {
        var search = $(this).val();
        if (search.length > 0) {
            $.ajax({
                type: 'POST',
                url: "nurse/find/req/analysis",
                contentType: 'application/json',
                dataType: 'json',
                data: search,
                success: function (data, textStatus, jqXHR) {
                    $('#list-req-analysis').empty();
                    analysisDetails = data;
                    $.map(data, function (value, key) {
                        var analysis = value;
                        $('#list-req-analysis').append('<li>' + analysis.firstname + ' ' + analysis.lastname + '</li>');
                    });
                }
            });
        } else {
            setTimeout(getAnalysis, 10);
        }
    });
    /**
     * search in request radiology 
     */
    $("#search-Radiology-input").keyup(function () {
        var search = $(this).val();
        if (search.length > 0) {
            $.ajax({
                type: 'POST',
                url: "nurse/find/req/radiology",
                contentType: 'application/json',
                dataType: 'json',
                data: search,
                success: function (data, textStatus, jqXHR) {
                    $('#list-req-radiology').empty();
                    radiologyDetails = data;
                    $.map(data, function (value, key) {
                        var radiology = value;
                        $('#list-req-radiology').append('<li>' + radiology.firstname + ' ' + radiology.lastname + '</li>');
                    });
                }
            });
        } else {
            setTimeout(getradiology, 10);
        }

    });
    /**
     * search for patient to make appointment
     * 
     */
    $("#search-patient-input").keyup(function () {
        var search = $(this).val();
        if (search.length > 0) {
            //search patient
            $.ajax({
                type: 'GET',
                url: "nurse/search/patient/appointment/" + search,
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#patient-list-appointments").empty();
                    $.map(data, function (value, key) {
                        $("#patient-list-appointments").append('<option value="' + value.securtiyNumber + '">' + value.firstname + ' ' + value.lastname + '</option>');
                    });
                }
            });
        } else {
            $.ajax({
                type: 'GET',
                url: "nurse/get/all/patient",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    // console.log(data);
                    $("#patient-list-appointments").empty();
                    $.map(data, function (value, key) {
                        $("#patient-list-appointments").append('<option value="' + value.securtiyNumber + '">' + value.firstname + ' ' + value.lastname + '</option>');
                    });
                }
            });
        }

    });
    /**
     * search for doctor to make appointment
     */
    $("#search-doctor-input").keyup(function () {
        var search = $(this).val();
        if (search.length > 0) {
            //serach doctor doctor
            $.ajax({
                type: 'GET',
                url: "nurse/search/doctor/appointments/" + search,
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#doctor-list-appointments").empty();
                    $.map(data, function (value, key) {
                        $("#doctor-list-appointments").append('<option value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');
                    });
                }
            });
        } else {

            //get all doctor
            $.ajax({
                type: 'GET',
                url: "nurse/get/all/doctor",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#doctor-list-appointments").empty();
                    $.map(data, function (value, key) {
                        $("#doctor-list-appointments").append('<option value="' + value.email + '">' + value.firstname + ' ' + value.lastname + '</option>');
                    });
                }
            });
        }
    });
    /**
     * register new patient
     */
    $("#btn-register-new-patient").click(function () {
        // preparing objects
        var users = {firstname: $("#firstname").val(), lastname: $("#lastname").val(), email: $("#email").val(), birthDate: $("#birthDate").val(), password: $("#password").val()};
        var addresses = {province: $("#province").val(), street: $("#street").val(), building: $("#building").val(), city: $("#city").val(), house: $("#house").val()};
        var patientDetails = {bloodType: $("#bloodtype option").val(), mobile: $("#mobile").val(), height: $("#height").val(), securtiyNumber: $("#security-number").val(), weight: $("#weight").val(), work: $("#work").val()};
        // make a post request
        AddLoading();
        $.ajax({

            type: "POST",
            url: "nusre/save/new/patient",
            contentType: "application/json",
            dataType: "json",
            data: JSON.stringify({users: users, addresses: addresses, patientDetails: patientDetails}),
            success: function (data, jqXHR) {
                removeLoading();
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    window.location.href = "/nurse";
                }, 2000);
            }
        });
    });
    /**
     * create Appointment
     */

    $("#btn-save-appointment").click(function () {
        var dateAppointment = $('#date-Appointment').val();
        var timeAppointment = $('#time-appointment').val();
        if (dateAppointment.length > 0 && timeAppointment.length > 0) {
            var Appointment = {dateAppointment: $('#date-Appointment').val(), timeAppointment: $('#time-appointment').val(), patientNumber: $('#patient-list-appointments option:selected').val(), doctorMail: $('#doctor-list-appointments option:selected').val()};
            // make a post request
            $.ajax({
                type: "POST",
                url: "nurse/save/new/appointment",
                contentType: "application/json",
                dataType: "json",
                data: JSON.stringify(Appointment),
                success: function (data, jqXHR) {
                    myCostumeAlert(2000, data.message);
                    setTimeout(() => {
                        window.location.href = "/nurse";
                    }, 2000);
                }
            });
        } else {
            alert("you must insert date appoitment and time appointment");
        }




    });


    //display radaiology
    $("#file").change(function () {
        $(this).prop('files')[0];
        if (this.files && this.files[0]) {
            var reader = new FileReader();
            var typeOfFile = this.files[0].type;
            var x = typeOfFile.split('/');
            if (x[0] === 'image') {
                reader.onload = function (e) {
                    $('#img-xray').show();
                    $('#img-xray').attr('src', e.target.result);

                };
            } else {
            }
            reader.readAsDataURL(this.files[0]);
        }
    });

    /**
     * save new radiologiy nurse
     */
    $("form[name='myform']").submit(function (e) {
        var formData = new FormData($(this)[0]);
        $.ajax({
            url: "nurse/add/new/radiology",
            type: "POST",
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: function (data) {
                $('#img-xray').hide();
                $('#img-xray').attr('src', '');
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    window.location.href = "/nurse";
                }, 2000);


            }
        });
        e.preventDefault();
    });



    /**
     * save Analysis
     */
    $("#btn-save-analysis").click(function () {

        var analysis = {
            alanineAminotransferase: $("#alanineAminotransferase").val(),
            albumin: $("#albumin").val(),
            calcitonin: $("#calcitonin").val(),
            calcium: $("#calcium").val(),
            chromogranin: $("#chromogranin").val(),
            creatinine: $("#creatinine").val(),
            fastingGlucose: $("#fastingGlucose").val(),
            hemoglobin: $("#hemoglobin").val(),
            phosphate: $("#phosphate").val(),
            plasmaActh: $("#plasmaActh").val(),
            plasmaCortisol: $("#plasmaCortisol").val(),
            potassium: $("#potassium").val(),
            prostateAntigen: $("#prostateAntigen").val(),
            salivaryCortisol: $("#salivaryCortisol").val(),
            totalBilirubin: $("#totalBilirubin").val(),
            whiteBloodCell: $("#whiteBloodCell").val(),
            testosterone: $("#testosterone").val()

        };
        $.ajax({
            type: 'POST',
            url: "nurse/save/new/analysis",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({Analysis: analysis}),
            success: function (data) {
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    window.location.href = "/nurse";
                }, 2000);
            }
        });
    });
});
