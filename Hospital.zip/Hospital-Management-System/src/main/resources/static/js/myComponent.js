/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */





function AddLoading() {

    $("#loading").addClass("lds-dual-ring");
    $(".body-loading").css("visibility", "visible");

}
;
function removeLoading() {

    $(".body-loading").css("visibility", "hidden");
    $("#loading").removeClass("lds-dual-ring");

}
;

function myCostumeAlert(time, text) {
    $(".alert-box").addClass("alert-box-visible");
    $("#alert-text").text(text);
    setTimeout(() => {

        $(".alert-box").removeClass("alert-box-visible");
        $(".alert-box").addClass("alert-box");

    }, time);
}
;

