/*
 To change this license header, choose License Headers in Project Properties.
 To change this template file, choose Tools | Templates
 and open the template in the editor.
 */
/* 
 Created on : Mar 25, 2020, 3:21:22 PM
 Author     : chahir chalouati
 */

/* global mailMessages, getConversation */
var mailMessages = '';
var sendersMessages = [];
$().ready(function () {
    $('#image-preview').hide();
    $('#btn-display').hide();
    $('#box-table').hide();
    $.getScript("js/myComponent.js", function (script, textStatus, jqXHR) {
    });



// open messages form 

/// open messages box
    $("#open-messages").click(function (e) {
        $(".messages").addClass("visible");
// request messages
        $.ajax({

            type: 'GET',
            url: "/doctor/get/all/messages",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                $(".list-box").empty();
                sendersMessages = data;
                $.map(data, function (value, key) {
                    $(".list-box").append('<li class="message" value="' + value.email + '">' +
                            value.firstname +
                            ' '
                            + value.lastname +
                            '<div>Status</div></li>');
                });
            }, error: function (jqXHR, textStatus, errorThrown) {
                alert(textStatus);
            }


        });
    });


    $(document).on('click', '.message', function () {
        mailMessages = $(this).attr('value');
        getAllMessages(mailMessages);

    });




    /**
     * send message to receiver
     */

    $(document).on('click', '#btn-send-message', function () {
        var msg = $("#myText-message").val();
        $.ajax({
            type: 'POST',
            url: "/doctor/send/message",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({message: msg}),
            success: function (data, textStatus, jqXHR) {
                getAllMessages(mailMessages);

            }, error: function (jqXHR, textStatus, errorThrown) {

            }


        });


    });


    $("#close-messages").click(function (e) {
        $(".messages").removeClass("visible");
    });
    $(".message").click(function (e) {
        alert("hello");
    });
//open modal change password
    $("#name-user").click(function () {
        $("#password-modal").addClass("modal-visible");
        getdepartment();
    });
    $(".close").click(function () {
        $("#password-modal").removeClass("modal-visible");
    });
    /**
     * change passsword
     */

    $('#btn-change-password').click(function () {
        var currentPassword = $("#current-password").val();
        var newPassword = $("#new-password").val();
        if ($.trim(currentPassword).length > 0 && $.trim(newPassword).length > 0) {
            $.ajax({

                type: 'POST',
                url: "doctor/change/password",
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({currentPassword: currentPassword, newPassword: newPassword}),
                success: function (data, textStatus, jqXHR) {

                    setTimeout(() => {
                        $("#password-modal").removeClass("modal-visible");
                        $("#current-password").val('');
                        $("#new-password").val('');
                    }, 2000);
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
        } else {
        }

    });
//    var operationDate = $('#date-operation').val();
//    var curDate = new Date();
//    console.log(curDate);


    $(".close").click(function () {
        $("#radiology").removeClass('modal-visible');
    });
    $(".close").click(function () {
        $("#analysis").removeClass('modal-visible');
        $('#box-table').html('');
    });
    $("#btn-back-display").click(function () {
        $("#slider").removeClass('modal-visible');
        $("#radiology").addClass('modal-visible');
    });
    $("#btn-operation").click(function () {
        if ($("#security-number").val().length > 0) {
            $("#operation-modal").addClass('modal-visible');
        } else {
            myCostumeAlert(2000, "select patient from table ");
        }

    });
    /**
     * save Operation for patient 
     */
    $("#btn-save-operation").click(function () {
        try {

            $.ajax({
                type: 'POST',
                url: "doctor/save/operation",
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({idSurgery: $('#typeofsurgeryRepository').val(), dateOperation: $('#date-operation').val(), timeoperation: $('#time-operation').val(), reasonForOperation: $("#reason-for-operation").val(), securityNumber: $("#security-number").val()}),
                success: function (data, textStatus, jqXHR) {
                    myCostumeAlert(3000, data.message);
                    setTimeout(() => {
                        window.location.href = "/doctor";
                    }, 3000);
                }, error: function (jqXHR, textStatus, errorThrown) {

                }, complete: function (jqXHR, textStatus) {

                }

            });
        } catch (e) {

        }
    });
    $(".close").click(function () {
        $("#operation-modal").removeClass('modal-visible');
    });
    $("#btn-hospitlyze").click(function () {
        if ($("#security-number").val().length > 0) {
            $("#hospitlize-modal").addClass('modal-visible');
        } else {
            myCostumeAlert(2000, "select patient from table ");
        }


    });

    /*
     * close medicines modal
     * @type Array
     */
    $(document).on("click", "#close-medicines", function () {
        $("#medicines-modal").addClass('modal-visible');
        $("#medicines-modal-textarea-how-use").removeClass('modal-visible');
    });
    $(".close").click(function () {
        $("#hospitlize-modal").removeClass('modal-visible');
    });

    /**
     * load all medicines
     * @type Array
     */
    var listMedicines = [];
    $("#btn-Medicines").click(function () {
        if ($("#security-number").val().length > 0) {
            $(".availble-medicines-message").hide();
            $.ajax({
                url: "doctor/get/all/medecines",
                type: 'GET',
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#medicines-list").empty();
                    $.map(data, function (value, key) {
                        listMedicines.push(value);
                        var medecines = value;
                        $("#medicines-list").append('<option value="' + medecines.idMedecine + '">' + value.nameMedecine + '</option>');
                    });
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
            $("#medicines-modal").addClass('modal-visible');
        } else {
            myCostumeAlert(2000, "select patient from table");
        }
    });
    /**
     * find medicines
     */
    $("#search-medicines").keyup(function () {
        if ($.trim($(this).val()).length > 0) {
            $.ajax({
                url: "doctor/find/medicines",
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: $.trim($(this).val()),
                success: function (data, textStatus, jqXHR) {
                    $("#medicines-list").empty();
                    listMedicines = [];
                    $.map(data, function (value, key) {
                        listMedicines.push(value);
                        var medecines = value;
                        $("#medicines-list").append('<option value="' + medecines.idMedecine + '">' + value.nameMedecine + '</option>');
                    });
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }
            });
        } else {
            medicines = [];
            $.ajax({
                type: 'GET',
                url: "doctor/get/all/medecines",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#medicines-list").empty();
                    listMedicines = [];
                    $.map(data, function (value, key) {
                        listMedicines.push(value);
                        var medecines = value;
                        $("#medicines-list").append('<option value="' + medecines.idMedecine + '">' + value.nameMedecine + '</option>');
                    });
                }
            });
        }


    });
    /**
     * display medicines and describe how use it
     * @type String|Number
     */
    var myIndex = '';
    $(document).on("change", "#medicines-list", function () {
        myIndex = $("#medicines-list option:selected").index();
        if (listMedicines[myIndex].availble === true) {

            $('.availble-medicines-message').css('color', 'green');
            $('.availble-medicines-message').text("Availble");
            $(".availble-medicines-message").show();
            $("#textarea-Added-medicines").css("text-align", "center");
            $("#textarea-Added-medicines").append($("#medicines-list option:selected").text() + "\n");
            $("#medicines-modal-textarea-how-use").addClass('modal-visible');
            $("#medicines-modal").removeClass('modal-visible');
        } else {
            $('.availble-medicines-message').css('color', 'red');
            $('.availble-medicines-message').text("Not availble");
            $(".availble-medicines-message").show();
        }


    });


    /**
     * add medicines and how tu use it
     * @type String|jQuery
     */
    var howUse = '';
    $("#textarea-confirm-how-use").click(function () {
        howUse = $("#describe-medicines-textarea").val();
        $.ajax({
            type: 'POST',
            url: "doctor/add/medicines/patient",
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify({idMedicines: listMedicines[myIndex].idMedecine.toString(), howUseIt: howUse}),
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2000, data.message);
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
        $("#medicines-modal").addClass('modal-visible');
        $("#medicines-modal-textarea-how-use").removeClass('modal-visible');
        $("#describe-medicines-textarea").val('');
    });
    $(".close").click(function () {
        $("#medicines-modal").removeClass('modal-visible');
    });
    /**
     * save all medicines added before 
     */
    $("#btn-save-medicines").click(function () {
        $.ajax({
            type: 'POST',
            url: "doctor/save/all/medicines/patient",
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {

                myCostumeAlert(2000, data.message);
                $("#medicines-modal").removeClass('modal-visible');
                $("#textarea-Added-medicines").empty();
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
    });
    /**
     * search for patient in appointment
     */
    $("#search").keyup(function () {
        var search = $.trim($("#search").val());
        if (search.length > 0) {
            $.ajax({
                type: 'POST',
                url: "doctor/search/patient",
                data: search,
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    $("#hasAppointment-list").empty();
                    $.map(data, function (value, key) {
                        console.log(value.dateAppointment);
                        $("#hasAppointment-list").append("<li>" + value.firstname + " " + value.lastname + ":: " + value.timeAppointment + "</li>");
                    });
                }, error: function (jqXHR, textStatus, errorThrown) {

                }
            });
        } else {
            window.location.href = "/doctor";
        }
    });
    /**
     * show patient details 
     */
    $(document).on("click", ".show", function () {

        var security = $(this).closest('tr').find('#security-number').html();
        $.ajax({
            type: 'POST',
            url: "doctor/getOne",
            contentType: 'application/json',
            dataType: 'json',
            data: security,
            success: function (data, textStatus, jqXHR) {
                $("#firstname").val(data.firstname);
                $("#lastname").val(data.lastname);
                $("#security-number").val(data.securtiyNumber);
                $("#age").val(data.age);
                $("#work").val(data.work);
            }, error: function (jqXHR, textStatus, errorThrown) {
            }
        });
    });
    /**
     * save situation
     */
    $("#btn-save-situation").click(function () {
        var situation = $("#textarea-situation").val();
        if ($("#security-number").val().length > 0) {
            if ($.trim(situation).length > 0) {

                $.ajax({
                    type: 'POST',
                    url: "doctor/save/situation",
                    dataType: 'json',
                    contentType: 'application/json',
                    data: situation,
                    success: function (data, textStatus, jqXHR) {
                        myCostumeAlert(2000, data.message);
                        $("#textarea-situation").val('');
                        clearFields();
                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                    }
                });
            } else {
                myCostumeAlert(3000, " can't save empty situation ");
            }

        } else {
            myCostumeAlert(3000, "select patient from table ");
        }


    });
    /**
     * load all availble analysis
     * analysis 
     */
    var arr = [];
    $("#btn-analysis").click(function () {

        if ($("#security-number").val().length > 0) {
            var securityNumber = $("#security-number").val();
            $("#analysis").addClass('modal-visible');
            $.ajax({
                type: 'POST',
                url: "doctor/get/analysis/patient",
                dataType: 'json',
                contentType: 'application/json',
                data: securityNumber,
                success: function (data, textStatus, jqXHR) {
                    $("#Analysis-patient").empty();
                    $("#Analysis-patient").append('<option>Select Analysis </option>');
                    $.map(data, function (value, key) {
                        $("#Analysis-patient").append('<option value="' + value.idAnalyze + '">' + value.dateAnalaysis + '</option>');
                        arr.push(value);
                    });
                },
                error: function (jqXHR, textStatus, errorThrown) {

                }

            });
        } else {
            myCostumeAlert(2000, "select patient from table ");
        }


    });
    /**
     * display analysis details
     * @type type
     */
    var analysis = {};
    $(document).on("change", "#Analysis-patient", function () {
        var index = $("#Analysis-patient option:selected").index();
        analysis = arr[(index - 1)];
        $('#analysis-body-modal').css('width', '80%');
        $('#box-table').show(200);
        $('#box-table').empty();
        $('#box-table').html(
                '<table><tr> <th>TEST</th>   <th>RESULT</th>    <th>Units</th>   <th>RANGE</th></tr>' +
                '<tr> <td>Alanine Amino transferase</td> <td>' + analysis.alanineAminotransferase + '</td> <td>gm/lg</td> <td>30.3-47.0</td> </tr>' +
                '<tr> <td>albumin</td> <td>' + analysis.albumin + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>calcitonin</td> <td>' + analysis.calcitonin + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>calcium</td> <td>' + analysis.calcium + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>chromogranin</td> <td>' + analysis.chromogranin + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.creatinine + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>fastingGlucose</td> <td>' + analysis.fastingGlucose + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>phosphate</td> <td>' + analysis.phosphate + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>plasmaActh</td> <td>' + analysis.plasmaActh + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>plasmaCortisol</td> <td>' + analysis.plasmaCortisol + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.potassium + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.prostateAntigen + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.salivaryCortisol + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.totalBilirubin + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.whiteBloodCell + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                '<tr> <td>creatinine</td> <td>' + analysis.testosterone + '</td> <td>mg/DL</td> <td>30.3-47.0</td></tr>' +
                ' </table>'
                );

    });
    /**
     * set analysis checked
     */
    $("#confirm-check-analysis").click(function () {
        var idAnalysis = analysis.idAnalyze;
        $.ajax({
            type: 'POST',
            url: "doctor/confirm/check/analysis",
            contentType: 'application/json',
            dataType: 'json',
            data: idAnalysis.toString(),
            success: function (data, textStatus, jqXHR) {
                $('#box-table').hide(200);
                $('#box-table').html('');
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    document.location.href = "/doctor";
                }, 2000);
            }
        });
    });
    /**
     * set analysis checked
     */
    $("#btn-confirm-analysis").click(function () {
        $.ajax({
            type: 'POST',
            url: "doctor/confirm/analysis",
            contentType: 'application/json',
            dataType: 'json',
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    document.location.href = "/doctor";
                }, 2000);
            }
        });
    });
    /**
     * hospitlize patient 
     */
    $("#btn-save-hospitlize").click(function () {
        var securityNumber = $("#security-number").val();
        var dateRecover = $("#date-recover").val();
        var datehospitlize = $("#date-hospitlize").val();
        var reason = $("#textarea-hospitlize").val();
        var hospitlizes = {reasonForHospitlizes: reason, dateHospitlizes: datehospitlize, dateRecover: dateRecover};
        if ($.trim(datehospitlize).length > 0 && $.trim(reason).length > 0) {

            if ($.trim(securityNumber).length > 0) {
                $.ajax({
                    type: 'POST',
                    url: "doctor/hospitalize/patient",
                    contentType: 'application/json',
                    dataType: 'json',
                    data: JSON.stringify({Hospitlizes: hospitlizes}),
                    success: function (data, textStatus, jqXHR) {
                        myCostumeAlert(2000, data.message);
                        setTimeout(() => {
                            document.location.href = "/doctor";
                        }, 3000);
                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                    }
                });
            } else {

                myCostumeAlert(2000, "select patient from table ");
            }
        } else {
            myCostumeAlert(3000, "invalid input please select date and insert reason for hospitlize");
        }
    });
    /**
     * modal radiology 
     * @type Array
     */
    var images = [];
    var objectImages = {};
    $("#btn-radiology").click(function () {
// empty object
        images = [];
        objectImages = {};
        $('#image-preview').removeAttr('src');
        $("#list-radiology").empty();
// end empty object
        var securityNumber = $("#security-number").val();
        if (securityNumber.length > 0) {
            $("#radiology").addClass('modal-visible');
            $("#radiology-type").empty();
            var radiologyType = ["Hospice and Palliative Medicine",
                "Neuroradiology", "Nuclear Radiology",
                "Pediatric Radiology", "Vascular and Interventional Radiology"];
            $.each(radiologyType, function (i) {
                $("#radiology-type").append('<option value="' + radiologyType[i] + '"> ' + radiologyType[i] + ' </option>');
            });
            //get radiolgy for selected patient 
            $.ajax({type: 'POST',
                url: "doctor/get/radiology/patient",
                contentType: 'application/json',
                dataType: 'json',
                data: securityNumber
                , success: function (data, textStatus, jqXHR) {
                    if (data.length > 0) {
                        $.map(data, function (value, key) {
                            images.push(value);
                            $("#list-radiology").append('<option value="' + value.idImage + '"> ' + value.nameImage + ' </option>');
                        });
                        objectImages = images[0];
                        $('#image-preview').show();
                        $('#btn-display').show();
                        $('#image-preview').attr('src', 'data:image/png;base64,' + objectImages.imageBase64);
                    } else {
                        myCostumeAlert(3000, "no radiology was found for this patient");
                    }
                }});
        } else {

            myCostumeAlert(3000, "select patient from table ");
        }
    });
// change images
    $(document).on('change', '#list-radiology', function () {
        var index = $('#list-radiology option:selected').index();
        objectImages = images[index];
        $('#image-preview').attr('src', 'data:image/png;base64,' + objectImages.imageBase64);
    });
    /**
     * request radiology
     */
    $("#btn-req-radiology").click(function () {
        var typeRadiology = $("#radiology-type").val();
        $.ajax({
            type: 'POST',
            url: "doctor/request/radiology/patient",
            contentType: 'application/json',
            dataType: 'json',
            data: typeRadiology.toString(),
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2000, data.message);
                setTimeout(() => {
                    document.location.href = "/doctor";
                }, 3000);
            },
            error: function (jqXHR, textStatus, errorThrown) {

            }
        });
    });
    /**
     * set image checked
     */

    $('#btn-checked').click(function () {
        var index = $('#list-radiology option:selected').index();
        var idradiology = images[index].idImage;
        var securityNumber = $("#security-number").val();
        $.ajax({type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            url: "doctor/checked/radiology",
            data: idradiology,
            success: function (data, textStatus, jqXHR) {
                myCostumeAlert(2000, data.message);
//get radiolgy for selected patient 
                $.ajax({type: 'POST',
                    url: "doctor/get/radiology/patient",
                    contentType: 'application/json',
                    dataType: 'json',
                    data: securityNumber
                    , success: function (data, textStatus, jqXHR) {
                        $("#list-radiology").empty();
                        images = [];
                        if (data.length > 0) {
                            $.map(data, function (value, key) {
                                images.push(value);
                                $("#list-radiology").append('<option value="' + value.idImage + '"> ' + value.nameImage + ' </option>');
                            });
                            objectImages = images[0];
                            $('#image-preview').attr('src', 'data:image/png;base64,' + objectImages.imageBase64);
                        } else {
                            myCostumeAlert(3000, "no radiology was found for this patient");
                            setTimeout(() => {
                                window.location.href = "/doctor";
                            }, 3000);
                        }
                    }});
            }});
    });
//display slider with first image
    $("#btn-display").click(function () {

        if (images.length > 0) {
            var myImage = images[0];
            $('.title-slide').text(" Image for Patient  : " + images[0].nameImage + "   Image number : " + images[0].idImage);
            $("#radiology").removeClass('modal-visible');
            $("#slider").addClass('modal-visible');
            $("#slider-images").attr('src', 'data:image/png;base64,' + myImage.imageBase64);
        } else {

            myCostumeAlert(3000, "sorry there are no images to display ");
        }

    });
    $('#btn-next').click(function () {
        $('.title-slide').text("Image for Patient   :" + images[ ChangeSlide(1, images)].nameImage + "  Image number : " + images[ ChangeSlide(1, images)].idImage);
        $("#slider-images").attr('src', 'data:image/png;base64,' + images[ ChangeSlide(1, images)].imageBase64);
    });
// previous image
    $('#btn-previous').click(function () {
        $('.title-slide').text("Image for Patient   :" + images[ ChangeSlide(1, images)].nameImage + "   Image number : " + images[ ChangeSlide(1, images)].idImage);
        $("#slider-images").attr('src', 'data:image/png;base64,' + images[ChangeSlide(-1, images)].imageBase64);
    });
//slider compute
    var current = 0;
    function ChangeSlide(index, images) {
        current = current + index;
        if (current < 0) {
            current = images.length - 1;
        }
        if (current > images.length - 1) {
            current = 0;
        }

        return current;
    }

    function getAllMessages(mailMessages) {
        $.ajax({
            type: 'GET',
            url: "/doctor/get/all/messages/" + mailMessages,
            dataType: 'json',
            contentType: 'application/json',
            success: function (data, textStatus, jqXHR) {
                console.log(data);
                $(".list-box").empty();
                var i = 0;
                $.map(data, function (value, key) {

                    if (value.seeIt === false) {
                        i++;
                        console.log(i);
                    }
                    var indentify = "";
                    if (value.idSender.email === mailMessages) {
                        indentify = "Patient : ";
                        $(".list-box").append(' <div class="message" style="font-size:12px; color:white; height:auto; background: #32407b; text-transform:none;">'
                                + indentify + value.contentMessage +
                                '</div> ');
                        $('.list-box').scrollTop($('.list-box')[0].scrollHeight);
                    } else {
                        indentify = "You : ";
                        $(".list-box").append(' <div class="message" style="font-size:12px; color:white; height:auto;  background: #515585;  text-transform:none;" >'
                                + indentify + value.contentMessage +
                                '</div> ');
                        $('.list-box').scrollTop($('.list-box')[0].scrollHeight);
                    }

                });
                if (i > 0) {
                    $("#notify").css('visibility', 'visible');
                    $("#notify").text(i);
                    setTimeout(() => {
                        $("#notify").css('visibility', 'hidden');
                    }, 10000);

                }
                var msg_box = '<div class="message-box-doctor"><textarea name="" id="myText-message" placeholder="Insert your message.."></textarea><button id="btn-send-message">Send</button></div>';
                $(".list-box").append(msg_box);
                $('.list-box').scrollTop($('.list-box')[0].scrollHeight);
            }});

    }

    function clearFields() {

        $("#firstname").val('');
        $("#lastname").val('');
        $("#security-number").val('');
        $("#age").val('');
        $("#work").val('');
    }
    ;
});