/*
 To change this license header, choose License Headers in Project Properties.
 To change this template file, choose Tools | Templates
 and open the template in the editor.
 */
/* 
 Created on : Mar 25, 2020, 3:21:22 PM
 Author     : chahir chalouati
 */

$(document).ready(function () {
    $(".alert").addClass("hide");


    $("#btn-sign-in").click(function () {

        // preparing objects
        var users = {firstname: $("#firstname").val(), lastname: $("#lastname").val(), email: $("#email").val(), birthDate: $("#birthDate").val(), password: $("#password").val()};
        var addresses = {province: $("#province").val(), street: $("#street").val(), building: $("#building").val(), city: $("#city").val(), house: $("#house").val()};


        if (verify_Inputs(addresses) === true && verify_Inputs(users) === true) {
            if (users.password.length < 8) {
                alert(" password must contain at least 8 letters  ");
            } else {

                if ($("#password").val() === $("#re-password").val()) {
                    // make a post request
                    $.ajax({
                        type: "POST",
                        url: "register/save",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify({users: users, addresses: addresses}),
                        success: function (data, jqXHR) {

                            if (data.message === 'you have an account') {
                                $(".alert").removeClass("hide");
                                $(".alert").addClass("alert-visible");
                                $(".alert p").text('you have an account you will be riderected to login page');
                                setTimeout(() => {
                                    window.location.href = '/';
                                }, 2000);
                            } else if (data.message === 'registred with success') {
                                $(".alert").removeClass("hide");
                                $(".alert").addClass("alert-visible");
                                $(".alert p").text('you registred with success');
                                setTimeout(() => {
                                    window.location.href = '/';
                                }, 4000);
                            }
                        }
                    });
                } else {
                    $("#password").val('Pasword must be filed out');
                    $("#password").css('color', 'red');
                    $("#password").attr("type", "text");
                    $("#re-password").val('Password must be confirmed');
                    $("#re-password").css('color', 'red');
                    $("#re-password").attr("type", "text");
                    setTimeout(() => {
                        $("#password").attr("type", "password");
                        $("#re-password").attr("type", "password");
                        $("#password").css('color', 'black');
                        $("#re-password").css('color', 'black');
                        $("#password").val('');
                        $("#re-password").val('');
                    }, 4000);
                }




            }
        } else {
            verify_Inputs(users);
            verify_Inputs(addresses);
            $("#re-password").attr("placeholder", " must not be empty ");
        }
    });





    /**
     * verifie input 
     * @param {type} arr
     * @returns {undefined}
     */
    function verify_Inputs(arr) {
        var verifiy;
        $.map(arr, function (value, key) {
            if ($.trim(value) !== "") {
                verifiy = true;
                return true;
            } else {
                $("#" + key + "").attr("placeholder", " " + key + " must not be empty");
                verifiy = false;
                return false;
            }

        });
        return verifiy;
    }
    ;












});
