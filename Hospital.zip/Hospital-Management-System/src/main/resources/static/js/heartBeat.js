/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



/* global d3, Stomp, BEAT_VALUES, data, now, SECONDS_SAMPLE, idDoctor, idPatient */


$(document).ready(function () {
    //websocket connect
    connect();

    // get patient data 
    getHospitlyzedPatient();
});

var myArr = [];
function getHospitlyzedPatient() {
    $.ajax(
            {type: 'GET',
                url: "/nurse/patient/hospitlyzed",
                contentType: 'application/json',
                dataType: 'json',
                success: function (data, textStatus, jqXHR) {
                    if (data.length > 0) {
                        $(".list").empty();
                        $.map(data, function (value, key) {
                            var namePatient = value.idPatient.firstname + ' ' + value.idPatient.lastname;
                            var item_list = '<li class="list-item" data=' + value.idHospitlize + ' mail=' + value.idPatient.email + '><span class="name">' + namePatient + '</span> <span class="state"> </span></li>';
                            $(".list").append(item_list);
                        });
                    }

                }, error: function (jqXHR, textStatus, errorThrown) {

                }, complete: function (jqXHR, textStatus) {

                }
            });
}


$(document).on('click', '.list-item', function () {
    var x = $(this).attr('data');

    displayDetails(x);
});
$("#find_patient").keyup(function () {
    var x = $(this).val();
    findPatient(x);
});

// get one hospitlyzed data
function displayDetails(x) {
    $.ajax({
        url: "/nurse/patient/hospitlyzed/" + x,
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {
            var phone = data.contactDoctor.phone;
            var mobile = data.contactDoctor.mobile;
            var dateHospitlizes = data.dateHospitlizes;
            var dateRecover = data.dateRecover;
            var dayResidence = data.dayResidence;
            var nameDoctor = data.idDoctor.firstname + ' ' + data.idDoctor.lastname;
            var namePatient = data.idPatient.firstname + ' ' + data.idPatient.lastname;
            $(".name_patient").text(namePatient);
            $(".name_doctor").text(nameDoctor);
            $(".dateHosp").text(dateHospitlizes);
            $(".roomnumber").text(3);
            $(".mobile").text(mobile);
            $(".phone").text(phone);
        }, error: function (jqXHR, textStatus, errorThrown) {

        }
    });

}
;

// get find Patient
function findPatient(x) {
    $.ajax({
        url: "/nurse/patient/hospitlyzed/mail/" + x,
        contentType: 'application/json',
        dataType: 'json',
        success: function (data, textStatus, jqXHR) {

            if (data.length > 0) {
                $(".list").empty();
                $.map(data, function (value, key) {
                    var namePatient = value.idPatient.firstname + ' ' + value.idPatient.lastname;
                    var item_list = '<li class="list-item" data=' + value.idHospitlize + ' mail=' + value.idPatient.email + '><span class="name">' + namePatient + '</span> <span class="state"> </span></li>';
                    $(".list").append(item_list);
                });
            } else {


            }

        }, error: function (jqXHR, textStatus, errorThrown) {

        }
    });

}
;


$(".close").click(function () {
    window.location.href = "/nurse";
});

/**
 * 
 * socket logic
 */
var stompClient;
/**
 * disconnecht from socket 
 * @returns {undefined}
 */
function disconnect() {
    if (stompClient) {
        stompClient.disconnect();
        stompClient = null;

    }
}
;
/**
 * start receiving data 
 * @returns {undefined}
 */
function start() {
    if (stompClient) {
        stompClient.send('/swns/start', {});
    }
}
;
//test message 
function send() {
    if (stompClient) {
        stompClient.send('/swns/send', {}, JSON.stringify({'message': "hello from Client "}));
    }
}
;


/**close connection
 * 
 * @returns {undefined}
 */
function close() {
    if (stompClient) {
        stompClient.send('/swns/stop', {});
    }
}
;

/**
 * connect to socket 
 * @returns {undefined}
 */
function connect() {
    if (!stompClient) {
        const socket = new SockJS("http://localhost:8080/notifications");
        stompClient = Stomp.over(socket);
        //stompClient.debug = null;
        stompClient.connect({}, function () {
            stompClient.subscribe('/user/notification/item', function (response) {
                var y = JSON.parse(response.body);
                console.log(y);

                $("#heartbeat").text(y.heartBeat);
                $(".ratio").text(y.temperature);
                $("#res").text(y.res_ratio);

            });
        });


        // start receiving data 
        setTimeout(() => {
            start();
            console.log('socket start');

        }, 1000);

    }
}







