/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class ResponseImage {

    private String ImageBase64;
    private String nameImage;
    private String idImage;
    private String cheked;

    public ResponseImage() {
    }

    public String getImageBase64() {
        return ImageBase64;
    }

    public void setImageBase64(String ImageBase64) {
        this.ImageBase64 = ImageBase64;
    }

    public String getNameImage() {
        return nameImage;
    }

    public void setNameImage(String nameImage) {
        this.nameImage = nameImage;
    }


    public String getIdImage() {
        return idImage;
    }

    public void setIdImage(String idImage) {
        this.idImage = idImage;
    }

    public String getCheked() {
        return cheked;
    }

    public void setCheked(String cheked) {
        this.cheked = cheked;
    }

}
