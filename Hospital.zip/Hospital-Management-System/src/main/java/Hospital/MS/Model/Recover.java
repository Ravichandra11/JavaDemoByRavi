///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package Hospital.MS.Model;
//
//import Hospital.MS.Repository.AddressesRepository;
//import Hospital.MS.Repository.AuthoritiesRepository;
//import Hospital.MS.Repository.DepartmentsRepository;
//import Hospital.MS.Repository.HasContactRepository;
//import Hospital.MS.Repository.HasDepartmentRepository;
//import Hospital.MS.Repository.UserRepository;
//import java.util.Date;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import javax.annotation.PostConstruct;
//
//import javax.sql.DataSource;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.scheduling.annotation.Async;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Component;
//
///**
// *
// * @author Chahir Chalouati
// */
//@Component
//
//public class Recover {
//
//    @Autowired
//    private UserRepository userRepository;
//    @Autowired
//    private Authorities authorities;
//    @Autowired
//    AuthoritiesRepository authoritiesRepository;
//    @Autowired
//    AddressesRepository addressesRepository;
//    @Autowired
//    HasDepartmentRepository hasDepartmentRepository;
//    @Autowired
//    DepartmentsRepository departmentsRepository;
//    @Autowired
//    HasContactRepository hasContactRepository;
//
//    @PostConstruct
//    @Scheduled(fixedDelay = 1000)
//
//    private void postConstruct() {
//
//        if (userRepository.findAll().size() <= 0) {
//
//            authorities.setDeleted(Boolean.FALSE);
//            authorities.setAuthoritie("ADMIN");
//            authoritiesRepository.save(authorities);
//            Users users = new Users();
//            users.setIdAuthoritie(authorities);
//            users.setFirstname("ADMIN");
//            users.setLastname("ADMIN");
//            users.setDeleted(Boolean.FALSE);
//            users.setBirthDate(new Date());
//            users.setEmail("admin@mail.com");
//            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
//            users.setPassword(bCryptPasswordEncoder.encode("admin"));
//            userRepository.save(users);
//
//            Addresses addresses = new Addresses();
//
//            addresses.setBuilding("adminBuilding");
//            addresses.setCity("admin city");
//            addresses.setDeleted(Boolean.FALSE);
//            addresses.setProvince("admin Province");
//            addresses.setHouse("admin House");
//            addresses.setStreet("admin street");
//            addresses.setIdUser(users);
//            addressesRepository.save(addresses);
//
////            Hasdepartment hasdepartment = new Hasdepartment();
////            hasdepartment.setDeleted(Boolean.FALSE);
////            hasdepartment.setIdUser(users);
////            hasdepartment.setIdDepartment(departmentsRepository.getOne(Long.valueOf("1")));
////            hasDepartmentRepository.save(hasdepartment);
//            HasContacts hasContacts = new HasContacts();
//            hasContacts.setDeleted(Boolean.FALSE);
//            hasContacts.setFax("+39-696-696-696");
//            hasContacts.setMobile("+39-696-696-696");
//            hasContacts.setPhone("+39-696-696-696");
//            hasContacts.setIdUser(users);
//            hasContactRepository.save(hasContacts);
//
//        }
//
//    }
//}
