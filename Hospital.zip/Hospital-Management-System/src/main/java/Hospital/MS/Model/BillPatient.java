/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class BillPatient {

    private DecimalFormat formatter = new DecimalFormat("#0.00");
    private String idHospital = "JDFJK5S54F4SD899FJKBA";
    private Date dateRecover, dateHospitlyze;
    private String firstname, lastname, email, securityNumber, address, modile, curaDate = " ";
    private List<Medicines> listMedicines;
    private List<HasRadiology> listHasradiology;
    private List<Hasanalysis> listHasAnalysis;
    private List<Analysis> listAnalysis;
    private List<HasOperation> listoperation;
    private int totalDayResidence = 0;
    private String age = "0";
    private String billnumber = "0";
    private double totalPriceMedicines,
            totalPriceRadiologies,
            totalPriceAnalysis,
            totalPriceOperations,
            total,
            totalCostDayResidence,
            totalCostAppointment;

    public BillPatient() {

        listMedicines = new LinkedList<>();
        listHasradiology = new LinkedList<>();
        listHasAnalysis = new LinkedList<>();
        listAnalysis = new LinkedList<>();
        listoperation = new LinkedList<>();
        dateHospitlyze = new Date();
        dateRecover = new Date();
    }

 
    public String getIdHospital() {
        return idHospital;
    }

    public void setIdHospital(String idHospital) {
        this.idHospital = idHospital;
    }

    public Date getDateRecover() {
        return dateRecover;
    }

    public void setDateRecover(Date dateRecover) {
        this.dateRecover = dateRecover;
    }

    public Date getDateHospitlyze() {
        return dateHospitlyze;
    }

    public void setDateHospitlyze(Date dateHospitlyze) {
        this.dateHospitlyze = dateHospitlyze;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSecurityNumber() {
        return securityNumber;
    }

    public void setSecurityNumber(String securityNumber) {
        this.securityNumber = securityNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getModile() {
        return modile;
    }

    public void setModile(String modile) {
        this.modile = modile;
    }

    public String getCuraDate() {
        return curaDate;
    }

    public void setCuraDate(String curaDate) {
        this.curaDate = curaDate;
    }

    public List<Medicines> getListMedicines() {
        return listMedicines;
    }

    public void setListMedicines(List<Medicines> listMedicines) {
        this.listMedicines = listMedicines;
    }

    public List<HasRadiology> getListHasradiology() {
        return listHasradiology;
    }

    public void setListHasradiology(List<HasRadiology> listHasradiology) {
        this.listHasradiology = listHasradiology;
    }

    public List<Analysis> getListAnalysis() {
        listAnalysis = new LinkedList<>();
        listHasAnalysis.forEach((listHasAnalysi) -> {
            listAnalysis.add(listHasAnalysi.getIdAnalyze());
        });

        return listAnalysis;
    }

    public void setListAnalysis(List<Analysis> listAnalysis) {
        this.listAnalysis = listAnalysis;
    }

    public List<HasOperation> getListoperation() {
        return listoperation;
    }

    public void setListoperation(List<HasOperation> listoperation) {
        this.listoperation = listoperation;
    }

    public int getTotalDayResidence() {
        return totalDayResidence;
    }

    public void setTotalDayResidence(int totalDayResidence) {
        this.totalDayResidence = totalDayResidence;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBillnumber() {
        return billnumber;
    }

    public void setBillnumber(String billnumber) {
        this.billnumber = billnumber;
    }

    public double getTotalPriceMedicines() {
        listMedicines.forEach((listMedicine) -> {
            totalPriceMedicines += listMedicine.getPrice();
        });
        return Double.valueOf(formatter.format(totalPriceMedicines));
    }

    public void setTotalPriceMedicines(double totalPriceMedicines) {
        this.totalPriceMedicines = totalPriceMedicines;
    }

    public double getTotalPriceRadiologies() {
        getListHasradiology().forEach((hasRadiology) -> {
            totalPriceRadiologies += hasRadiology.getIdRadiologies().getCostRadiology();
        });

        return Double.valueOf(formatter.format(totalPriceRadiologies));
    }

    public void setTotalPriceRadiologies(double totalPriceRadiologies) {
        this.totalPriceRadiologies = totalPriceRadiologies;
    }

    public double getTotalPriceAnalysis() {
        listHasAnalysis.forEach((listAnalysi) -> {
            totalPriceAnalysis += listAnalysi.getIdDoctor().getHasdepartment().getIdDepartment().getCostAnalysis();
        });

        return Double.valueOf(formatter.format(totalPriceAnalysis));
    }

    public void setTotalPriceAnalysis(double totalPriceAnalysis) {
        this.totalPriceAnalysis = totalPriceAnalysis;
    }

    public double getTotalPriceOperations() {
        listoperation.forEach((listHasOperation) -> {
            totalPriceOperations += listHasOperation.getIdSurgery().getCost();
        });
        return Double.valueOf(formatter.format(totalPriceOperations));
    }

    public void setTotalPriceOperations(double totalPriceOperations) {
        this.totalPriceOperations = totalPriceOperations;
    }

    public double getTotal() {
        total = totalPriceOperations
                + totalPriceAnalysis
                + totalPriceRadiologies
                + totalPriceMedicines
                + totalCostDayResidence
                + totalCostAppointment;

        return Double.valueOf(formatter.format(total));
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getTotalCostDayResidence() {
        return Double.valueOf(formatter.format(totalCostDayResidence));
    }

    public void setTotalCostDayResidence(double totalCostDayResidence) {
        this.totalCostDayResidence = totalCostDayResidence;
    }

    public double getTotalCostAppointment() {
        return totalCostAppointment;
    }

    public void setTotalCostAppointment(double totalCostAppointment) {
        this.totalCostAppointment = totalCostAppointment;
    }

    public List<Hasanalysis> getListHasAnalysis() {
        return listHasAnalysis;
    }

    public void setListHasAnalysis(List<Hasanalysis> listHasAnalysis) {
        this.listHasAnalysis = listHasAnalysis;
    }

    @Override
    public String toString() {
        return "BillPatient{" + "formatter=" + formatter + ", idHospital=" + idHospital + ", dateRecover=" + dateRecover + ", dateHospitlyze=" + dateHospitlyze + ", firstname=" + firstname + ", lastname=" + lastname + ", email=" + email + ", securityNumber=" + securityNumber + ", address=" + address + ", modile=" + modile + ", curaDate=" + curaDate + ", listMedicines=" + listMedicines + ", listHasradiology=" + listHasradiology + ", listHasAnalysis=" + listHasAnalysis + ", listAnalysis=" + listAnalysis + ", listoperation=" + listoperation + ", totalDayResidence=" + totalDayResidence + ", age=" + age + ", billnumber=" + billnumber + ", totalPriceMedicines=" + totalPriceMedicines + ", totalPriceRadiologies=" + totalPriceRadiologies + ", totalPriceAnalysis=" + totalPriceAnalysis + ", totalPriceOperations=" + totalPriceOperations + ", total=" + total + ", totalCostDayResidence=" + totalCostDayResidence + ", totalCostAppointment=" + totalCostAppointment + '}';
    }

}
