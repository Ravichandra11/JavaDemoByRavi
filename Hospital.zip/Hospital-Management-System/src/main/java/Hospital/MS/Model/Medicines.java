/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author chahir chalouati
 */
@Entity
@Table(name = "medicines", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Medicines.findAllDISTINCT", query = "SELECT DISTINCT m FROM Medicines m WHERE m.deleted=FALSE ORDER BY m.nameMedecine ASC"),
    @NamedQuery(name = "Medicines.findAlldeleted", query = "SELECT m FROM Medicines m WHERE m.deleted=FALSE ORDER BY m.nameMedecine ASC"),
    @NamedQuery(name = "Medicines.findByIdMedecine", query = "SELECT m FROM Medicines m WHERE m.idMedecine = :idMedecine"),
    @NamedQuery(name = "Medicines.findByAvailble", query = "SELECT m FROM Medicines m WHERE m.availble = :availble"),
    @NamedQuery(name = "Medicines.findByNameMedecineLike", query = "SELECT m FROM Medicines m WHERE m.deleted=FALSE AND m.nameMedecine LIKE :nameMedecine  "),
    @NamedQuery(name = "Medicines.findByPrice", query = "SELECT m FROM Medicines m WHERE m.price = :price"),
    @NamedQuery(name = "Medicines.findByQuantity", query = "SELECT m FROM Medicines m WHERE m.quantity = :quantity")})
public class Medicines implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 255)
    @Column(name = "name_medecine", nullable = false, length = 255)
    private String nameMedecine;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_medecine", nullable = false)
    private Long idMedecine;
    @Column(name = "availble")
    private Boolean availble;
    @Basic(optional = false)
    @Column(name = "price", nullable = false)
    private double price;
    @Basic(optional = false)
    @Column(name = "quantity", nullable = false)
    private int quantity;
    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idMedecine")
    private List<HasMedicines> hasMedicinesList;

    @Column(name = "deleted")
    private Boolean deleted;

    public Medicines() {
    }

    public Medicines(Long idMedecine) {
        this.idMedecine = idMedecine;
    }

    public Medicines(Long idMedecine, String nameMedecine, double price, int quantity) {
        this.idMedecine = idMedecine;
        this.nameMedecine = nameMedecine;
        this.price = price;
        this.quantity = quantity;
    }

    public Long getIdMedecine() {
        return idMedecine;
    }

    public void setIdMedecine(Long idMedecine) {
        this.idMedecine = idMedecine;
    }

    public Boolean getAvailble() {
        return availble;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public void setAvailble(Boolean availble) {
        this.availble = availble;
    }

    public String getNameMedecine() {
        return nameMedecine;
    }

    public void setNameMedecine(String nameMedecine) {
        this.nameMedecine = nameMedecine;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @XmlTransient
    @JsonIgnore
    public List<HasMedicines> getHasMedicinesList() {
        return hasMedicinesList;
    }

    public void setHasMedicinesList(List<HasMedicines> hasMedicinesList) {
        this.hasMedicinesList = hasMedicinesList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idMedecine != null ? idMedecine.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Medicines)) {
            return false;
        }
        Medicines other = (Medicines) object;
        if ((this.idMedecine == null && other.idMedecine != null) || (this.idMedecine != null && !this.idMedecine.equals(other.idMedecine))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Medicines{" + "nameMedecine=" + nameMedecine + ", price=" + price + ", quantity=" + quantity + '}';
    }

  

  
}
