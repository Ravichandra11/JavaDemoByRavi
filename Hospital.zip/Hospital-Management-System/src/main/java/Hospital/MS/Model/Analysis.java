/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "analysis", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Analysis.findAll", query = "SELECT a FROM Analysis a"),
    @NamedQuery(name = "Analysis.findByIdAnalyze", query = "SELECT a FROM Analysis a WHERE a.idAnalyze = :idAnalyze"),
    @NamedQuery(name = "Analysis.findByAlanineAminotransferase", query = "SELECT a FROM Analysis a WHERE a.alanineAminotransferase = :alanineAminotransferase"),
    @NamedQuery(name = "Analysis.findByAlbumin", query = "SELECT a FROM Analysis a WHERE a.albumin = :albumin"),
    @NamedQuery(name = "Analysis.findByCalcitonin", query = "SELECT a FROM Analysis a WHERE a.calcitonin = :calcitonin"),
    @NamedQuery(name = "Analysis.findByCalcium", query = "SELECT a FROM Analysis a WHERE a.calcium = :calcium"),
    @NamedQuery(name = "Analysis.findByChromogranin", query = "SELECT a FROM Analysis a WHERE a.chromogranin = :chromogranin"),
    @NamedQuery(name = "Analysis.findByCreatinine", query = "SELECT a FROM Analysis a WHERE a.creatinine = :creatinine"),
    @NamedQuery(name = "Analysis.findByDateAnalaysis", query = "SELECT a FROM Analysis a WHERE a.dateAnalaysis = :dateAnalaysis"),
    @NamedQuery(name = "Analysis.findByFastingGlucose", query = "SELECT a FROM Analysis a WHERE a.fastingGlucose = :fastingGlucose"),
    @NamedQuery(name = "Analysis.findByHemoglobin", query = "SELECT a FROM Analysis a WHERE a.hemoglobin = :hemoglobin"),
    @NamedQuery(name = "Analysis.findByPhosphate", query = "SELECT a FROM Analysis a WHERE a.phosphate = :phosphate"),
    @NamedQuery(name = "Analysis.findByPlasmaActh", query = "SELECT a FROM Analysis a WHERE a.plasmaActh = :plasmaActh"),
    @NamedQuery(name = "Analysis.findByPlasmaCortisol", query = "SELECT a FROM Analysis a WHERE a.plasmaCortisol = :plasmaCortisol"),
    @NamedQuery(name = "Analysis.findByPotassium", query = "SELECT a FROM Analysis a WHERE a.potassium = :potassium"),
    @NamedQuery(name = "Analysis.findByProstateAntigen", query = "SELECT a FROM Analysis a WHERE a.prostateAntigen = :prostateAntigen"),
    @NamedQuery(name = "Analysis.findBySalivaryCortisol", query = "SELECT a FROM Analysis a WHERE a.salivaryCortisol = :salivaryCortisol"),
    @NamedQuery(name = "Analysis.findByTestosterone", query = "SELECT a FROM Analysis a WHERE a.testosterone = :testosterone"),
    @NamedQuery(name = "Analysis.findByTotalBilirubin", query = "SELECT a FROM Analysis a WHERE a.totalBilirubin = :totalBilirubin"),
    @NamedQuery(name = "Analysis.findByWhiteBloodCell", query = "SELECT a FROM Analysis a WHERE a.whiteBloodCell = :whiteBloodCell")})
public class Analysis implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "date_analaysis", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAnalaysis;
    @JsonIgnore
    @OneToMany(mappedBy = "idAnalyze")
    private List<Hasanalysis> hasanalysisList;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_analyze", nullable = false)

    private Long idAnalyze;
    @Column(name = "alanine_aminotransferase", precision = 22, scale = 0)
    private Double alanineAminotransferase;
    @Column(name = "albumin", precision = 22, scale = 0)
    private Double albumin;
    @Column(name = "calcitonin", precision = 22, scale = 0)
    private Double calcitonin;
    @Column(name = "calcium", precision = 22, scale = 0)
    private Double calcium;
    @Column(name = "chromogranin", precision = 22, scale = 0)
    private Double chromogranin;
    @Column(name = "creatinine", precision = 22, scale = 0)
    private Double creatinine;
    @Column(name = "fasting_glucose", precision = 22, scale = 0)
    private Double fastingGlucose;
    @Column(name = "hemoglobin", precision = 22, scale = 0)
    private Double hemoglobin;
    @Column(name = "phosphate", precision = 22, scale = 0)
    private Double phosphate;
    @Column(name = "plasma_acth", precision = 22, scale = 0)
    private Double plasmaActh;
    @Column(name = "plasma_cortisol", precision = 22, scale = 0)
    private Double plasmaCortisol;
    @Column(name = "potassium", precision = 22, scale = 0)
    private Double potassium;
    @Column(name = "prostate_antigen", precision = 22, scale = 0)
    private Double prostateAntigen;
    @Column(name = "salivary_cortisol", precision = 22, scale = 0)
    private Double salivaryCortisol;
    @Column(name = "testosterone", precision = 22, scale = 0)
    private Double testosterone;
    @Column(name = "total_bilirubin", precision = 22, scale = 0)
    private Double totalBilirubin;
    @Column(name = "white_blood_cell", precision = 22, scale = 0)
    private Double whiteBloodCell;
    @JsonIgnore
    @Column(name = "deleted")
    private Boolean deleted;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Analysis() {
    }

    public Date getDateAnalaysis() {
        return dateAnalaysis;
    }

    public void setDateAnalaysis(Date dateAnalaysis) {
        this.dateAnalaysis = dateAnalaysis;
    }

    public List<Hasanalysis> getHasanalysisList() {
        return hasanalysisList;
    }

    public void setHasanalysisList(List<Hasanalysis> hasanalysisList) {
        this.hasanalysisList = hasanalysisList;
    }

    public Long getIdAnalyze() {
        return idAnalyze;
    }

    public void setIdAnalyze(Long idAnalyze) {
        this.idAnalyze = idAnalyze;
    }

    public Double getAlanineAminotransferase() {
        return alanineAminotransferase;
    }

    public void setAlanineAminotransferase(Double alanineAminotransferase) {
        this.alanineAminotransferase = alanineAminotransferase;
    }

    public Double getAlbumin() {
        return albumin;
    }

    public void setAlbumin(Double albumin) {
        this.albumin = albumin;
    }

    public Double getCalcitonin() {
        return calcitonin;
    }

    public void setCalcitonin(Double calcitonin) {
        this.calcitonin = calcitonin;
    }

    public Double getCalcium() {
        return calcium;
    }

    public void setCalcium(Double calcium) {
        this.calcium = calcium;
    }

    public Double getChromogranin() {
        return chromogranin;
    }

    public void setChromogranin(Double chromogranin) {
        this.chromogranin = chromogranin;
    }

    public Double getCreatinine() {
        return creatinine;
    }

    public void setCreatinine(Double creatinine) {
        this.creatinine = creatinine;
    }

    public Double getFastingGlucose() {
        return fastingGlucose;
    }

    public void setFastingGlucose(Double fastingGlucose) {
        this.fastingGlucose = fastingGlucose;
    }

    public Double getHemoglobin() {
        return hemoglobin;
    }

    public void setHemoglobin(Double hemoglobin) {
        this.hemoglobin = hemoglobin;
    }

    public Double getPhosphate() {
        return phosphate;
    }

    public void setPhosphate(Double phosphate) {
        this.phosphate = phosphate;
    }

    public Double getPlasmaActh() {
        return plasmaActh;
    }

    public void setPlasmaActh(Double plasmaActh) {
        this.plasmaActh = plasmaActh;
    }

    public Double getPlasmaCortisol() {
        return plasmaCortisol;
    }

    public void setPlasmaCortisol(Double plasmaCortisol) {
        this.plasmaCortisol = plasmaCortisol;
    }

    public Double getPotassium() {
        return potassium;
    }

    public void setPotassium(Double potassium) {
        this.potassium = potassium;
    }

    public Double getProstateAntigen() {
        return prostateAntigen;
    }

    public void setProstateAntigen(Double prostateAntigen) {
        this.prostateAntigen = prostateAntigen;
    }

    public Double getSalivaryCortisol() {
        return salivaryCortisol;
    }

    public void setSalivaryCortisol(Double salivaryCortisol) {
        this.salivaryCortisol = salivaryCortisol;
    }

    public Double getTestosterone() {
        return testosterone;
    }

    public void setTestosterone(Double testosterone) {
        this.testosterone = testosterone;
    }

    public Double getTotalBilirubin() {
        return totalBilirubin;
    }

    public void setTotalBilirubin(Double totalBilirubin) {
        this.totalBilirubin = totalBilirubin;
    }

    public Double getWhiteBloodCell() {
        return whiteBloodCell;
    }

    public void setWhiteBloodCell(Double whiteBloodCell) {
        this.whiteBloodCell = whiteBloodCell;
    }

    @Override
    public String toString() {
        return "Analysis{" + "dateAnalaysis=" + dateAnalaysis + ", hasanalysisList=" + hasanalysisList + ", idAnalyze=" + idAnalyze + ", alanineAminotransferase=" + alanineAminotransferase + ", albumin=" + albumin + ", calcitonin=" + calcitonin + ", calcium=" + calcium + ", chromogranin=" + chromogranin + ", creatinine=" + creatinine + ", fastingGlucose=" + fastingGlucose + ", hemoglobin=" + hemoglobin + ", phosphate=" + phosphate + ", plasmaActh=" + plasmaActh + ", plasmaCortisol=" + plasmaCortisol + ", potassium=" + potassium + ", prostateAntigen=" + prostateAntigen + ", salivaryCortisol=" + salivaryCortisol + ", testosterone=" + testosterone + ", totalBilirubin=" + totalBilirubin + ", whiteBloodCell=" + whiteBloodCell + ", deleted=" + deleted + '}';
    }


  

}
