/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_radiology", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasRadiology.findAll",
            query = "SELECT h FROM HasRadiology h WHERE h.deleted=FALSE AND h.idRadiologies=NULL"),
       @NamedQuery(name = "HasRadiology.findAllPaymentByUser",
            query = "SELECT h FROM HasRadiology h WHERE h.deleted=FALSE AND h.checked=TRUE AND h.idUser.idUser= :id"),
    @NamedQuery(name = "HasRadiology.findHasradiologyForDoctor", 
            query = "SELECT h FROM HasRadiology h WHERE h.deleted=FALSE AND h.checked=FALSE AND h.idUser.patientdetails.securtiyNumber= :securtiyNumber AND h.idRadiologies IS NOT NULL"),
    @NamedQuery(name = "HasRadiology.findNullRadiology", 
            query = "SELECT h FROM HasRadiology h WHERE h.deleted=FALSE AND h.idRadiologies IS NULL"),
    @NamedQuery(name = "HasRadiology.findNullRadiologyByName",
            query = "SELECT h FROM HasRadiology h WHERE h.deleted=FALSE AND h.idRadiologies IS NULL AND h.idUser.firstname LIKE :name"),
    @NamedQuery(name = "HasRadiology.findByIdHasRadiology",
            query = "SELECT h FROM HasRadiology h WHERE h.idHasRadiology = :idHasRadiology"),
    @NamedQuery(name = "HasRadiology.findByChecked",
            query = "SELECT h FROM HasRadiology h WHERE h.checked = :checked"),
    @NamedQuery(name = "HasRadiology.findByTypeOfRadiology",
            query = "SELECT h FROM HasRadiology h WHERE h.typeOfRadiology = :typeOfRadiology")})
public class HasRadiology implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "type_of_radiology", nullable = false, length = 45)
    private String typeOfRadiology;

    private static final long serialVersionUID = 1L;
    @JsonIgnore
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_has_radiology", nullable = false)
    private Long idHasRadiology;
    @Column(name = "checked")
    @JsonIgnore
    private Boolean checked;
    @JsonIgnore
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false, unique = false)
    @ManyToOne
    private Users idUser;
    @JsonIgnore
    @JoinColumn(name = "id_radiologies", referencedColumnName = "id_radiologies")
    @ManyToOne
    private Radiologies idRadiologies;
    @JsonIgnore
    @Column(name = "deleted")
    private Boolean deleted;
   

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasRadiology() {
    }

    public HasRadiology(Long idHasRadiology) {
        this.idHasRadiology = idHasRadiology;
    }

    public HasRadiology(Long idHasRadiology, String typeOfRadiology) {
        this.idHasRadiology = idHasRadiology;
        this.typeOfRadiology = typeOfRadiology;
    }

    public Long getIdHasRadiology() {
        return idHasRadiology;
    }

    public void setIdHasRadiology(Long idHasRadiology) {
        this.idHasRadiology = idHasRadiology;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

    public String getTypeOfRadiology() {
        return typeOfRadiology;
    }

    public void setTypeOfRadiology(String typeOfRadiology) {
        this.typeOfRadiology = typeOfRadiology;
    }

    public Users getIdUser() {

        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    public Radiologies getIdRadiologies() {
        return idRadiologies;
    }

    public void setIdRadiologies(Radiologies idRadiologies) {
        this.idRadiologies = idRadiologies;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHasRadiology != null ? idHasRadiology.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasRadiology)) {
            return false;
        }
        HasRadiology other = (HasRadiology) object;
        if ((this.idHasRadiology == null && other.idHasRadiology != null) || (this.idHasRadiology != null && !this.idHasRadiology.equals(other.idHasRadiology))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.HasRadiology[ idHasRadiology=" + idHasRadiology + " ]";
    }

}
