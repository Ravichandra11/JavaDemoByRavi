/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class MyCostumeUSER {

    private String firstname;
    private String lastname;
    private String email;
    private String authoritie;
    private Double height;
    private Double weight;
    private String securtiyNumber;
    private String work;
    private String bloodType;
    private String age;
    private String typeOfRadiology;
    private long analysis;


    public MyCostumeUSER() {
 
    }

    public MyCostumeUSER(String firstname, String lastname, String email, String authoritie) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.email = email;
        this.authoritie = authoritie;
     
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public long getAnalysis() {
        return analysis;
    }

    public void setAnalysis(long analysis) {
        this.analysis = analysis;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAuthoritie() {
        return authoritie;
    }

    public void setAuthoritie(String authoritie) {
        this.authoritie = authoritie;
    }

    public Double getHeight() {
        return height;
    }

    public void setHeight(Double height) {
        this.height = height;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getSecurtiyNumber() {
        return securtiyNumber;
    }

    public void setSecurtiyNumber(String securtiyNumber) {
        this.securtiyNumber = securtiyNumber;
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getTypeOfRadiology() {
        return typeOfRadiology;
    }

    public void setTypeOfRadiology(String typeOfRadiology) {
        this.typeOfRadiology = typeOfRadiology;
    }



}
