/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "hasdepartment", catalog = "my_hospital", schema = "", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"id_user"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hasdepartment.findAll", query = "SELECT h FROM Hasdepartment h WHERE h.idUser= :idUser"),
    @NamedQuery(name = "Hasdepartment.findByIdUser", query = "SELECT h FROM Hasdepartment h WHERE h.idUser= :idUser"),
    @NamedQuery(name = "Hasdepartment.findByIdHasdepartment", query = "SELECT h FROM Hasdepartment h WHERE h.idHasdepartment = :idHasdepartment")})
public class Hasdepartment implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_hasdepartment", nullable = false)
    @JsonIgnore
    private Long idHasdepartment;
    @JoinColumn(name = "id_department", referencedColumnName = "id_department", nullable = false)
    @ManyToOne(optional = false)

    private Departments idDepartment;
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @OneToOne(optional = false)
    @JsonIgnore
    private Users idUser;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Hasdepartment() {
    }

    public Hasdepartment(Long idHasdepartment) {
        this.idHasdepartment = idHasdepartment;
    }

    public Long getIdHasdepartment() {
        return idHasdepartment;
    }

    public void setIdHasdepartment(Long idHasdepartment) {
        this.idHasdepartment = idHasdepartment;
    }

    public Departments getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(Departments idDepartment) {
        this.idDepartment = idDepartment;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHasdepartment != null ? idHasdepartment.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hasdepartment)) {
            return false;
        }
        Hasdepartment other = (Hasdepartment) object;
        if ((this.idHasdepartment == null && other.idHasdepartment != null) || (this.idHasdepartment != null && !this.idHasdepartment.equals(other.idHasdepartment))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.Hasdepartment[ idHasdepartment=" + idHasdepartment + " ]";
    }

}
