/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.hibernate.annotations.Formula;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "hospitlizes", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hospitlizes.findAll", query = "SELECT h FROM Hospitlizes h"),
    @NamedQuery(name = "Hospitlizes.findAllbyEmail", query = "SELECT h FROM Hospitlizes h WHERE h.idPatient.firstname Like :mail"),
    @NamedQuery(name = "Hospitlizes.findAllHospitlized", query = "SELECT h FROM Hospitlizes h WHERE h.deleted=FALSE AND h.dateRecover >= CURDATE()"),
    @NamedQuery(name = "Hospitlizes.findRecentDateRecover",
            query = "SELECT h FROM Hospitlizes h WHERE h.idPatient.idUser= :id AND h.deleted = FALSE AND DATE_FORMAT(h.dateRecover,'%Y%m%d')=(SELECT MAX(DATE_FORMAT(h.dateRecover,'%Y%m%d')) FROM Hospitlizes h WHERE h.idPatient.idUser= :id)  "),
    @NamedQuery(name = "Hospitlizes.findByIdHospitlize", query = "SELECT h FROM Hospitlizes h WHERE h.idHospitlize = :idHospitlize"),
    @NamedQuery(name = "Hospitlizes.findByRecoverToDay", query = "SELECT h FROM Hospitlizes h WHERE h.dateRecover = CURDATE() AND h.deleted = FALSE"),
    @NamedQuery(name = "Hospitlizes.findByRecoverToDayBYPATIENT", query = "SELECT h FROM Hospitlizes h WHERE h.dateRecover =CURDATE() AND h.deleted=FALSE AND h.idPatient.email= :email"),
    @NamedQuery(name = "Hospitlizes.findByDateHospitlizes", query = "SELECT h FROM Hospitlizes h WHERE h.dateHospitlizes = :dateHospitlizes")})
public class Hospitlizes implements Serializable {

    @Lob
    @Size(max = 2147483647)
    @Column(name = "reason_for_hospitlizes", length = 2147483647)
    private String reasonForHospitlizes;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_hospitlize", nullable = false)
    private Long idHospitlize;

    @Column(name = "date_hospitlizes")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateHospitlizes;
    @Column(name = "date_recover")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateRecover;
    @JoinColumn(name = "id_doctor", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)

    private Users idDoctor;
    @JoinColumn(name = "id_patient", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)

    private Users idPatient;
    @Formula("DATEDIFF(date_recover,date_hospitlizes)")
    private int dayResidence;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;
    @Transient
    private HasContacts contactDoctor;

    public Hospitlizes() {
    }

    public HasContacts getContactDoctor() {
        return idDoctor.getHasContacts();
    }

    public Hospitlizes(Long idHospitlize) {
        this.idHospitlize = idHospitlize;
    }

    public Long getIdHospitlize() {
        return idHospitlize;
    }

    public void setIdHospitlize(Long idHospitlize) {
        this.idHospitlize = idHospitlize;
    }

    public Date getDateHospitlizes() {
        return dateHospitlizes;
    }

    public void setDateHospitlizes(Date dateHospitlizes) {
        this.dateHospitlizes = dateHospitlizes;
    }

    public String getReasonForHospitlizes() {
        return reasonForHospitlizes;
    }

    public void setReasonForHospitlizes(String reasonForHospitlizes) {
        this.reasonForHospitlizes = reasonForHospitlizes;
    }

    public Users getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(Users idDoctor) {
        this.idDoctor = idDoctor;
    }

    public Users getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(Users idPatient) {
        this.idPatient = idPatient;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHospitlize != null ? idHospitlize.hashCode() : 0);
        return hash;
    }

    public Date getDateRecover() {
        return dateRecover;
    }

    public void setDateRecover(Date dateRecover) {
        this.dateRecover = dateRecover;
    }

    public int getDayResidence() {
        return dayResidence;
    }

    public void setDayResidence(int dayResidence) {
        this.dayResidence = dayResidence;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Hospitlizes)) {
            return false;
        }
        Hospitlizes other = (Hospitlizes) object;
        if ((this.idHospitlize == null && other.idHospitlize != null) || (this.idHospitlize != null && !this.idHospitlize.equals(other.idHospitlize))) {
            return false;
        }
        return true;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return "Hospitlizes{" + "dateHospitlizes=" + dateHospitlizes + ", reasonForHospitlizes=" + reasonForHospitlizes + '}';
    }

}
