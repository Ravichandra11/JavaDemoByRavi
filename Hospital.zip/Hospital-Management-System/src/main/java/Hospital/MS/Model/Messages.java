/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.security.Principal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author Chahir Chalouati
 */
@Component
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Table(name = "messages", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Messages.findAll",
            query = "SELECT m FROM Messages m"),
    @NamedQuery(name = "Messages.findMessageByIdSender",
            query = "SELECT m FROM Messages m WHERE m.idSender.idUser= :id"),
    @NamedQuery(name = "Messages.findMessageByIdReceiver",
            query = "SELECT m FROM Messages m WHERE m.idReceiver.idUser= :id"),
    @NamedQuery(name = "Messages.findMessageByEmail",
            query = "SELECT m FROM Messages m WHERE m.idSender.email= :email AND m.idReceiver.idUser= :id  OR  m.idReceiver.email= :email AND m.idSender.idUser= :id  ORDER BY m.dateSend ASC "),
    @NamedQuery(name = "Messages.findMessageByCurdate",
            query = "SELECT m FROM Messages m WHERE DATE(m.dateSend) = CURRENT_DATE"),
    @NamedQuery(name = "Messages.findDistinctSenderByIdReceiver",
            query = "SELECT DISTINCT m.idSender FROM Messages m WHERE m.idReceiver.idUser= :id  ORDER BY m.dateSend DESC "),
    @NamedQuery(name = "Messages.findByIdMessage", query = "SELECT m FROM Messages m WHERE m.idMessage = :idMessage"),
    @NamedQuery(name = "Messages.findBySeeIt", query = "SELECT m FROM Messages m WHERE m.seeIt = :seeIt"),
    @NamedQuery(name = "Messages.findByDateReceive", query = "SELECT m FROM Messages m WHERE m.dateReceive = :dateReceive"),
    @NamedQuery(name = "Messages.findByDateSend", query = "SELECT m FROM Messages m WHERE m.dateSend = :dateSend")})
public class Messages implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_message", nullable = false)
    private Long idMessage;
    @Basic(optional = false)
    @Lob
    @Size(min = 1, max = 65535)
    @Column(name = "content_message", nullable = false, length = 65535)
    private String contentMessage;
    @Column(name = "see_it")
    private Boolean seeIt;
    @Basic(optional = false)
    @Column(name = "date_receive")
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
    private Date dateReceive;
    @Basic(optional = false)
    @Column(name = "date_send", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "dd-MM-yyyy hh:mm:ss")
    private Date dateSend;
    @JoinColumn(name = "id_sender", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)

    private Users idSender;
    @JoinColumn(name = "id_receiver", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    private Users idReceiver;

}
