/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class CompareDate {

    public CompareDate() {
    }

    public int compare(Date MyDate, Date curDate) {
        int x = 0;
        long valueMyDate = Long.valueOf(new SimpleDateFormat("yyyyMMdd").format(MyDate));
        long valuecurDate = Long.valueOf(new SimpleDateFormat("yyyyMMdd").format(curDate));
        if (valueMyDate >= valuecurDate) {
            x = 1;

        } else if (valueMyDate < valuecurDate) {
            x = -1;

        } else if (valueMyDate == valuecurDate) {
            x = 0;
        }

        return x;
    }

}
