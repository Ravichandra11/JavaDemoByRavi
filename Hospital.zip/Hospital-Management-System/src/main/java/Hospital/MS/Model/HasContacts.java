/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_contacts", catalog = "my_hospital", schema = "", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"id_user"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasContacts.findAll", query = "SELECT h FROM HasContacts h"),
    @NamedQuery(name = "HasContacts.findByIdContacts", query = "SELECT h FROM HasContacts h WHERE h.idContacts = :idContacts"),
    @NamedQuery(name = "HasContacts.findByFax", query = "SELECT h FROM HasContacts h WHERE h.fax = :fax"),
    @NamedQuery(name = "HasContacts.findByMobile", query = "SELECT h FROM HasContacts h WHERE h.mobile = :mobile"),
    @NamedQuery(name = "HasContacts.findByPhone", query = "SELECT h FROM HasContacts h WHERE h.phone = :phone")})
public class HasContacts implements Serializable {

 

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_contacts", nullable = false)
    @JsonIgnore
    private Long idContacts;
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @OneToOne(optional = false)
    @JsonIgnore
    private Users idUser;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;
    @Size(max = 45)
    @Column(name = "fax", length = 45)
    private String fax;
    @Size(max = 45)
    @Column(name = "mobile", length = 45)
    private String mobile;
    @Size(max = 45)
    @Column(name = "phone", length = 45)
    private String phone;
    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasContacts() {
    }

    public HasContacts(Long idContacts) {
        this.idContacts = idContacts;
    }

    public Long getIdContacts() {
        return idContacts;
    }

    public void setIdContacts(Long idContacts) {
        this.idContacts = idContacts;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idContacts != null ? idContacts.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasContacts)) {
            return false;
        }
        HasContacts other = (HasContacts) object;
        if ((this.idContacts == null && other.idContacts != null) || (this.idContacts != null && !this.idContacts.equals(other.idContacts))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.HasContacts[ idContacts=" + idContacts + " ]";
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
