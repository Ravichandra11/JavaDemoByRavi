/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "patientdetails", catalog = "my_hospital", schema = "", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"id_user"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Patientdetails.findAll", query = "SELECT p FROM Patientdetails p"),
    @NamedQuery(name = "Patientdetails.findByIdPatientdetails", query = "SELECT p FROM Patientdetails p WHERE p.idPatientdetails = :idPatientdetails"),
    @NamedQuery(name = "Patientdetails.findByBloodType", query = "SELECT p FROM Patientdetails p WHERE p.bloodType = :bloodType"),
    @NamedQuery(name = "Patientdetails.findByHeight", query = "SELECT p FROM Patientdetails p WHERE p.height = :height"),
    @NamedQuery(name = "Patientdetails.findBySecurtiyNumber", query = "SELECT p FROM Patientdetails p WHERE p.securtiyNumber = :securtiyNumber"),
    @NamedQuery(name = "Patientdetails.findByWeight", query = "SELECT p FROM Patientdetails p WHERE p.weight = :weight"),
    @NamedQuery(name = "Patientdetails.findByWork", query = "SELECT p FROM Patientdetails p WHERE p.work = :work")})
public class Patientdetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @JsonIgnore
    @Column(name = "id_patientdetails", nullable = false)
    private Long idPatientdetails;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "height", precision = 22, scale = 0)
    private Double height;
    @Column(name = "weight", precision = 22, scale = 0)
    private Double weight;
    @JsonIgnore
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @OneToOne(optional = false)
    private Users idUser;
    @Size(max = 20)
    @Column(name = "blood_type", length = 20)
    private String bloodType;
    @Size(max = 45)
    @Column(name = "securtiy_number", length = 45)
    private String securtiyNumber;
    @Size(max = 45)
    @Column(name = "mobile", length = 45)
    private String mobile;
    @Size(max = 45)
    @Column(name = "work", length = 45)
    private String work;

    public Patientdetails() {
    }

    public Long getIdPatientdetails() {
        return idPatientdetails;
    }

    public void setIdPatientdetails(Long idPatientdetails) {
        this.idPatientdetails = idPatientdetails;
    }

    public String getBloodType() {
        return bloodType;
    }

    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }

    public Double getHeight() {
        return height;
    }

    public void setHeight(Double height) {
        this.height = height;
    }

    public String getSecurtiyNumber() {
        return securtiyNumber;
    }

    public void setSecurtiyNumber(String securtiyNumber) {
        this.securtiyNumber = securtiyNumber;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    @Override
    public String toString() {
        return "Patientdetails{" + "bloodType=" + bloodType + ", height=" + height + ", securtiyNumber=" + securtiyNumber + ", weight=" + weight + ", work=" + work + ", idUser=" + idUser + '}';
    }

    public String getWork() {
        return work;
    }

    public void setWork(String work) {
        this.work = work;
    }

}
