/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Formula;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "users", catalog = "my_hospital", schema = "", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"email"})})
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Users.findAll", query = "SELECT u FROM Users u WHERE u.deleted=FALSE"),
    @NamedQuery(name = "Users.findAllCountPatient", query = "SELECT COUNT(u) FROM Users u WHERE u.deleted=FALSE AND u.idAuthoritie.authoritie='USER'"),
    @NamedQuery(name = "Users.findUserBySecurityNumber", query = "SELECT u FROM Users u WHERE u.deleted=FALSE AND u.patientdetails.securtiyNumber= :securtiyNumber"),
    @NamedQuery(name = "Users.findUserByLikeFirstname", query = "SELECT u FROM Users u WHERE u.deleted=FALSE AND u.firstname LIKE :firstname AND u.idAuthoritie.authoritie NOT LIKE :authoritie"),
    @NamedQuery(name = "Users.findAllEmployee", query = "SELECT u FROM Users u WHERE u.deleted=FALSE AND u.idAuthoritie.authoritie NOT LIKE :authoritie"),
    @NamedQuery(name = "Users.findByIdUser", query = "SELECT u FROM Users u WHERE u.idUser = :idUser"),
    @NamedQuery(name = "Users.findByBirthDate", query = "SELECT u FROM Users u WHERE u.birthDate = :birthDate"),
    @NamedQuery(name = "Users.findByDeleted", query = "SELECT u FROM Users u WHERE u.deleted = :deleted"),
    @NamedQuery(name = "Users.findByEmail", query = "SELECT u FROM Users u WHERE u.email = :email"),
    @NamedQuery(name = "Users.findByFirstname", query = "SELECT u FROM Users u WHERE u.firstname = :firstname"),
    @NamedQuery(name = "Users.findByFirstnameLike", query = "SELECT u FROM Users u "
            + "WHERE u.deleted=FALSE AND u.idAuthoritie.authoritie= :authoritie AND u.firstname LIKE :firstname"),
    @NamedQuery(name = "Users.findByAuthoritie", query = "SELECT u FROM Users u WHERE u.idAuthoritie.authoritie = :authoritie AND u.deleted=FALSE"),
    @NamedQuery(name = "Users.findByAuthoritieByName", query = "SELECT u FROM Users u WHERE u.idAuthoritie.authoritie = :authoritie AND u.deleted=FALSE AND u.firstname LIKE :name"),
    @NamedQuery(name = "Users.findByPassword", query = "SELECT u FROM Users u WHERE u.password = :password")

})
public class Users implements Serializable {

    // @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message="Invalid email")//if the field contains email address consider using this annotation to enforce field validation
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "email", nullable = false, length = 100)
    private String email;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "firstname", nullable = false, length = 45)
    private String firstname;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "lastname", nullable = false, length = 45)
    private String lastname;
    @Basic(optional = false)
    @JsonIgnore
    @Column(name = "password", nullable = false, length = 255)
    private String password;
    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idSender")
    private List<Messages> messagesList;
    @JsonIgnore
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idReceiver")
    private List<Messages> messagesList1;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_user", nullable = false)
    @JsonIgnore
    private Long idUser;
    @Column(name = "birth_date")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date birthDate;
    @Column(name = "deleted")
    private Boolean deleted;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private List<HasOperation> hasOperationList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDoctor")
    @JsonIgnore
    private List<HasOperation> hasOperationList1;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private Patientdetails patientdetails;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private Addresses addresses;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private List<HasContracts> hasContractsList;
    @JoinColumn(name = "id_authoritie", referencedColumnName = "id_authoritie", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Authorities idAuthoritie;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDoctor")
    @JsonIgnore
    private List<HasSituations> hasSituationsList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idPatient")
    @JsonIgnore
    private List<HasSituations> hasSituationsList1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idPatient")
    @JsonIgnore
    private List<HasAppointment> hasAppointmentList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDoctor")
    @JsonIgnore
    private List<HasAppointment> hasAppointmentList1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private List<HasMedicines> hasMedicinesList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private List<HasRadiology> hasRadiologyList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private Hasdepartment hasdepartment;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDoctor")
    @JsonIgnore
    private List<Hospitlizes> hospitlizesList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idPatient")
    @JsonIgnore
    private List<Hospitlizes> hospitlizesList1;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private List<Payment> paymentList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "idUser")
    @JsonIgnore
    private HasContacts hasContacts;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDoctor")
    @JsonIgnore
    private List<Hasanalysis> hasanalysisList;
    @OneToMany(mappedBy = "idUser")
    @JsonIgnore
    private List<Hasanalysis> hasanalysisList1;
    @Formula("YEAR(CURDATE()) - YEAR(birth_date)")
    private String age;

    public Users() {
    }

    public Users(Long idUser) {
        this.idUser = idUser;
    }

    public Users(Long idUser, String email, String firstname, String lastname, String password) {
        this.idUser = idUser;
        this.email = email;
        this.firstname = firstname;
        this.lastname = lastname;
        this.password = password;
    }

    public Long getIdUser() {
        return idUser;
    }

    public void setIdUser(Long idUser) {
        this.idUser = idUser;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public List<HasOperation> getHasOperationList() {
        return hasOperationList;
    }

    public void setHasOperationList(List<HasOperation> hasOperationList) {
        this.hasOperationList = hasOperationList;
    }

    public List<HasOperation> getHasOperationList1() {
        return hasOperationList1;
    }

    public void setHasOperationList1(List<HasOperation> hasOperationList1) {
        this.hasOperationList1 = hasOperationList1;
    }

    public Patientdetails getPatientdetails() {
        return patientdetails;
    }

    public void setPatientdetails(Patientdetails patientdetails) {
        this.patientdetails = patientdetails;
    }

    public Addresses getAddresses() {
        return addresses;
    }

    public void setAddresses(Addresses addresses) {
        this.addresses = addresses;
    }

    public List<HasContracts> getHasContractsList() {
        return hasContractsList;
    }

//    public HasContracts getHasContracts() {
//        return hasContracts;
//    }
//
//    public void setHasContracts(HasContracts hasContracts) {
//        this.hasContracts = hasContracts;
//    }
    public void setHasContractsList(List<HasContracts> hasContractsList) {
        this.hasContractsList = hasContractsList;
    }

    public Authorities getIdAuthoritie() {
        return idAuthoritie;
    }

    public void setIdAuthoritie(Authorities idAuthoritie) {
        this.idAuthoritie = idAuthoritie;
    }

    public List<HasSituations> getHasSituationsList() {
        return hasSituationsList;
    }

    public void setHasSituationsList(List<HasSituations> hasSituationsList) {
        this.hasSituationsList = hasSituationsList;
    }

    public List<HasSituations> getHasSituationsList1() {
        return hasSituationsList1;
    }

    public void setHasSituationsList1(List<HasSituations> hasSituationsList1) {
        this.hasSituationsList1 = hasSituationsList1;
    }

    public List<HasAppointment> getHasAppointmentList() {
        return hasAppointmentList;
    }

    public void setHasAppointmentList(List<HasAppointment> hasAppointmentList) {
        this.hasAppointmentList = hasAppointmentList;
    }

    public List<HasAppointment> getHasAppointmentList1() {
        return hasAppointmentList1;
    }

    public void setHasAppointmentList1(List<HasAppointment> hasAppointmentList1) {
        this.hasAppointmentList1 = hasAppointmentList1;
    }

    public List<HasMedicines> getHasMedicinesList() {
        return hasMedicinesList;
    }

    public void setHasMedicinesList(List<HasMedicines> hasMedicinesList) {
        this.hasMedicinesList = hasMedicinesList;
    }

    public List<HasRadiology> getHasRadiologyList() {
        return hasRadiologyList;
    }

    public void setHasRadiologyList(List<HasRadiology> hasRadiologyList) {
        this.hasRadiologyList = hasRadiologyList;
    }

    public Hasdepartment getHasdepartment() {
        return hasdepartment;
    }

    public void setHasdepartment(Hasdepartment hasdepartment) {
        this.hasdepartment = hasdepartment;
    }

    public List<Hospitlizes> getHospitlizesList() {
        return hospitlizesList;
    }

    public void setHospitlizesList(List<Hospitlizes> hospitlizesList) {
        this.hospitlizesList = hospitlizesList;
    }

    public List<Hospitlizes> getHospitlizesList1() {
        return hospitlizesList1;
    }

    public void setHospitlizesList1(List<Hospitlizes> hospitlizesList1) {
        this.hospitlizesList1 = hospitlizesList1;
    }

    public List<Payment> getPaymentList() {
        return paymentList;
    }

    public void setPaymentList(List<Payment> paymentList) {
        this.paymentList = paymentList;
    }

    public HasContacts getHasContacts() {
        return hasContacts;
    }

    public void setHasContacts(HasContacts hasContacts) {
        this.hasContacts = hasContacts;
    }

    public List<Hasanalysis> getHasanalysisList() {
        return hasanalysisList;
    }

    public void setHasanalysisList(List<Hasanalysis> hasanalysisList) {
        this.hasanalysisList = hasanalysisList;
    }

    public List<Hasanalysis> getHasanalysisList1() {
        return hasanalysisList1;
    }

    public void setHasanalysisList1(List<Hasanalysis> hasanalysisList1) {
        this.hasanalysisList1 = hasanalysisList1;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Users{" + "birthDate=" + birthDate + ", email=" + email + ", firstname=" + firstname + ", lastname=" + lastname + ", password=" + password + '}';
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @XmlTransient
    public List<Messages> getMessagesList() {
        return messagesList;
    }

    public void setMessagesList(List<Messages> messagesList) {
        this.messagesList = messagesList;
    }

    @XmlTransient
    public List<Messages> getMessagesList1() {
        return messagesList1;
    }

    public void setMessagesList1(List<Messages> messagesList1) {
        this.messagesList1 = messagesList1;
    }

}
