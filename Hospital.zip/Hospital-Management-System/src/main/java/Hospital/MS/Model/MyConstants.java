/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

/**
 *
 * @author chahir chalouati
 */
public class MyConstants {

    private static final String MY_EMAIL = "myhospitalms@gmail.com";


    private static final String MY_PASSWORD = "myhospitalms23051988";
    
    public static String getMY_EMAIL() {
        return MY_EMAIL;
    }

    public static String getMY_PASSWORD() {
        return MY_PASSWORD;
    }
}
