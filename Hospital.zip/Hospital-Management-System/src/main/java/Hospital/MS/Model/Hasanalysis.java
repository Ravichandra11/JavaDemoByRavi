/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "hasanalysis", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Hasanalysis.findAll", query = "SELECT h FROM Hasanalysis h "),
    @NamedQuery(name = "Hasanalysis.findAllWhereIdAnalysisNUll", query = "SELECT h FROM Hasanalysis h WHERE h.idAnalyze IS NULL AND h.deleted=FALSE"),
    @NamedQuery(name = "Hasanalysis.findAllWhereIdAnalysisNUllAndLikeFirstname", query = "SELECT h FROM Hasanalysis h WHERE h.idAnalyze IS NULL AND h.deleted=FALSE AND h.idUser.firstname LIKE :name"),
    @NamedQuery(name = "Hasanalysis.UpdateAnalysis", query = "SELECT h FROM Hasanalysis h WHERE h.idAnalyze.idAnalyze= :id"),
    @NamedQuery(name = "Hasanalysis.findAllAnalysisByPatient", 
            query = "SELECT h FROM Hasanalysis h WHERE h.checked=FALSE AND h.deleted=FALSE AND h.idUser.patientdetails.securtiyNumber= :securtiyNumber AND h.idDoctor.idUser= :idDoctor AND h.idAnalyze IS NOT NULL"),
    @NamedQuery(name = "Hasanalysis.findByIdhasAnalysis", query = "SELECT h FROM Hasanalysis h WHERE h.idhasAnalysis = :idhasAnalysis"),
    @NamedQuery(name = "Hasanalysis.findByDateRequest", query = "SELECT h FROM Hasanalysis h WHERE h.dateRequest = :dateRequest"),
    @NamedQuery(name = "Hasanalysis.findByDateresponse", query = "SELECT h FROM Hasanalysis h WHERE h.dateresponse = :dateresponse"),
    @NamedQuery(name = "Hasanalysis.findByAnalysisPaymentPatient", query = "SELECT h FROM Hasanalysis h WHERE h.checked=TRUE AND h.deleted=FALSE AND h.idUser.idUser= :id"),
    @NamedQuery(name = "Hasanalysis.findByDeleted", query = "SELECT h FROM Hasanalysis h WHERE h.deleted = :deleted")})
public class Hasanalysis implements Serializable {

    private static final long serialVersionUID = 1L;
    @JsonIgnore
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_hasAnalysis", nullable = false)
    private Long idhasAnalysis;
    @Column(name = "dateRequest")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateRequest;
    @Column(name = "dateresponse")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateresponse;
    @JsonIgnore
    @Column(name = "deleted")
    private Boolean deleted;
    @JoinColumn(name = "id_analyze", referencedColumnName = "id_analyze")
    @ManyToOne
    private Analysis idAnalyze;
    @JsonIgnore
    @JoinColumn(name = "id_user", referencedColumnName = "id_user")
    @ManyToOne
    private Users idUser;
    @JsonIgnore
    @JoinColumn(name = "id_doctor", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    private Users idDoctor;
    @JsonIgnore
    @Column(name = "checked")
    private Boolean checked;

    public Hasanalysis() {
    }

    public Long getIdhasAnalysis() {
        return idhasAnalysis;
    }

    public void setIdhasAnalysis(Long idhasAnalysis) {
        this.idhasAnalysis = idhasAnalysis;
    }

    public Date getDateRequest() {
        return dateRequest;
    }

    public void setDateRequest(Date dateRequest) {
        this.dateRequest = dateRequest;
    }

    public Date getDateresponse() {
        return dateresponse;
    }

    public void setDateresponse(Date dateresponse) {
        this.dateresponse = dateresponse;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Analysis getIdAnalyze() {
        return idAnalyze;
    }

    public void setIdAnalyze(Analysis idAnalyze) {
        this.idAnalyze = idAnalyze;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    public Users getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(Users idDoctor) {
        this.idDoctor = idDoctor;
    }

    public Boolean getChecked() {
        return checked;
    }

    public void setChecked(Boolean checked) {
        this.checked = checked;
    }

}
