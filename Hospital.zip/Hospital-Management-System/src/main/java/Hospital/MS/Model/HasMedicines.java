/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import Hospital.MS.Repository.HasMedicinesRepository;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_medicines", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasMedicines.findAll", query = "SELECT h FROM HasMedicines h"),
    @NamedQuery(name = "HasMedicines.findAllDistinct", query = "SELECT DISTINCT h.idUser FROM HasMedicines h WHERE h.deleted=FALSE AND h.idMedecine IS NOT NULL AND h.payed=FALSE GROUP BY h.idUser.firstname"),
    @NamedQuery(name = "HasMedicines.findAllDistinctLIKE", query = "SELECT DISTINCT h.idUser FROM HasMedicines h WHERE h.deleted=FALSE AND h.idMedecine IS NOT NULL AND h.idUser.firstname LIKE :firstname GROUP BY h.idUser.firstname"),
    @NamedQuery(name = "HasMedicines.findAllMedicinesByIdUser", query = "SELECT DISTINCT h.idMedecine FROM HasMedicines h WHERE h.deleted=FALSE AND h.payed=FALSE AND h.idMedecine IS NOT NULL AND h.idUser.patientdetails.securtiyNumber= :id GROUP BY h.idMedecine.nameMedecine"),
    @NamedQuery(name = "HasMedicines.findAllHasMedicinesUser", query = "SELECT h.idMedecine FROM HasMedicines h WHERE h.idUser.idUser= :id"),
    @NamedQuery(name = "HasMedicines.findByIdHasMedicine", query = "SELECT h FROM HasMedicines h WHERE h.idHasMedicine = :idHasMedicine"),
     @NamedQuery(name = "HasMedicines.findBySecurtiyNumber", query = "SELECT h FROM HasMedicines h WHERE h.idUser.patientdetails.securtiyNumber= :securtiyNumber AND h.deleted=FALSE AND h.payed=FALSE"),
    @NamedQuery(name = "HasMedicines.findByDateAdded", query = "SELECT h FROM HasMedicines h WHERE h.dateAdded = :dateAdded")})
public class HasMedicines implements Serializable {

    @Lob
    @Size(max = 2147483647)
    @Column(name = "how_use_it", length = 2147483647)
    private String howUseIt;

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_has_medicine", nullable = false)
    @JsonIgnore
    private Long idHasMedicine;
    @Column(name = "date_added")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateAdded;
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idUser;
    @JoinColumn(name = "id_medecine", referencedColumnName = "id_medecine", nullable = false)
    @ManyToOne(optional = false)
    private Medicines idMedecine;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;
    @Column(name = "payed")
    @JsonIgnore
    private Boolean payed;
    @Transient
    private MyCostumeUSER myCostumeUSER;
    @Transient
    List<Medicines> listMedicines;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasMedicines() {
        this.myCostumeUSER = new MyCostumeUSER();
        listMedicines = new LinkedList<>();
    }

    public HasMedicines(Long idHasMedicine) {
        this.idHasMedicine = idHasMedicine;
    }

    public Long getIdHasMedicine() {
        return idHasMedicine;
    }

    public Boolean getPayed() {
        return payed;
    }

    public void setPayed(Boolean payed) {
        this.payed = payed;
    }

    public void setIdHasMedicine(Long idHasMedicine) {
        this.idHasMedicine = idHasMedicine;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public String getHowUseIt() {
        return howUseIt;
    }

    public void setHowUseIt(String howUseIt) {
        this.howUseIt = howUseIt;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    public Medicines getIdMedecine() {
        return idMedecine;
    }

    public void setIdMedecine(Medicines idMedecine) {
        this.idMedecine = idMedecine;
    }

    public MyCostumeUSER getMyCostumeUSER() {

        myCostumeUSER.setFirstname(getIdUser().getFirstname());
        myCostumeUSER.setLastname(getIdUser().getLastname());
        myCostumeUSER.setEmail(String.valueOf(getIdHasMedicine()));
        myCostumeUSER.setSecurtiyNumber(getIdUser().getPatientdetails().getSecurtiyNumber());

        return myCostumeUSER;
    }

    public List<Medicines> getListMedicines() {
        return listMedicines;
    }

    public void setListMedicines(List<Medicines> listMedicines) {
        this.listMedicines = listMedicines;
    }

    public void setMyCostumeUSER(MyCostumeUSER myCostumeUSER) {
        this.myCostumeUSER = myCostumeUSER;
    }

    @Override
    public String toString() {
        return "HasMedicines{" + "idHasMedicine=" + idHasMedicine + ", dateAdded=" + dateAdded + ", howUseIt=" + howUseIt + ", idUser=" + idUser + ", idMedecine=" + idMedecine + ", deleted=" + deleted + '}';
    }


  

}
