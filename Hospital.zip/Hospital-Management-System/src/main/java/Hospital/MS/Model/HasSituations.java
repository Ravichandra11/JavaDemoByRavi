/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_situations", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasSituations.findAll", query = "SELECT h FROM HasSituations h"),
    @NamedQuery(name = "HasSituations.findAllByIdUSer", query = "SELECT h FROM HasSituations h WHERE h.idPatient.idUser= :id  ORDER BY h.dateRegsiterSituation ASC"),
    @NamedQuery(name = "HasSituations.findByIdHasSituation", query = "SELECT h FROM HasSituations h WHERE h.idHasSituation = :idHasSituation"),
    @NamedQuery(name = "HasSituations.findByDateRegsiterSituation", query = "SELECT h FROM HasSituations h WHERE h.dateRegsiterSituation = :dateRegsiterSituation")})
public class HasSituations implements Serializable {

    @Lob
    @Size(max = 2147483647)
    @Column(name = "situation", length = 2147483647)
    private String situation;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_has_situation", nullable = false)
    private Long idHasSituation;
    @Column(name = "date_regsiter_situation")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dateRegsiterSituation;
    @JoinColumn(name = "id_doctor", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    private Users idDoctor;
    @JoinColumn(name = "id_patient", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    private Users idPatient;
    @Column(name = "deleted")
    private Boolean deleted;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasSituations() {
    }

    public HasSituations(Long idHasSituation) {
        this.idHasSituation = idHasSituation;
    }

    public Long getIdHasSituation() {
        return idHasSituation;
    }

    public void setIdHasSituation(Long idHasSituation) {
        this.idHasSituation = idHasSituation;
    }

    public Date getDateRegsiterSituation() {
        return dateRegsiterSituation;
    }

    public void setDateRegsiterSituation(Date dateRegsiterSituation) {
        this.dateRegsiterSituation = dateRegsiterSituation;
    }

    public Users getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(Users idDoctor) {
        this.idDoctor = idDoctor;
    }

    public Users getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(Users idPatient) {
        this.idPatient = idPatient;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHasSituation != null ? idHasSituation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasSituations)) {
            return false;
        }
        HasSituations other = (HasSituations) object;
        if ((this.idHasSituation == null && other.idHasSituation != null) || (this.idHasSituation != null && !this.idHasSituation.equals(other.idHasSituation))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.HasSituations[ idHasSituation=" + idHasSituation + " ]";
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }

}
