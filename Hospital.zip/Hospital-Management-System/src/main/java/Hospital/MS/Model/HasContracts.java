/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_contracts", catalog = "my_hospital")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasContracts.findbyNameEmployeeLike",
            query = "SELECT h FROM HasContracts h WHERE h.idUser.firstname LIKE :name"),
    @NamedQuery(name = "HasContracts.findAll",
            query = "SELECT h FROM HasContracts h"),
    @NamedQuery(name = "HasContracts.findAllDisinctContracts",
            query = "SELECT h FROM HasContracts h WHERE h IN (SELECT DISTINCT h.idUser  FROM HasContracts h )"),
    @NamedQuery(name = "HasContracts.findByIdContracts",
            query = "SELECT h FROM HasContracts h WHERE h.idContracts = :idContracts"),
    @NamedQuery(name = "HasContracts.findByExpired",
            query = "SELECT h FROM HasContracts h WHERE h.expired = :expired"),
    @NamedQuery(name = "HasContracts.findByExpiredDate",
            query = "SELECT h FROM HasContracts h WHERE h.expiredDate = :expiredDate"),
    @NamedQuery(name = "HasContracts.findByTypeOfContract",
            query = "SELECT h FROM HasContracts h WHERE h.typeOfContract = :typeOfContract"),
    @NamedQuery(name = "HasContracts.findByValidatedate",
            query = "SELECT h FROM HasContracts h WHERE h.validatedate = :validatedate")})
public class HasContracts implements Serializable {

    @Lob
    @Size(max = 2147483647)
    @Column(name = "contract_terms", length = 2147483647)
    private String contractTerms;
    @Size(max = 45)
    @Column(name = "type_of_contract", length = 45)
    private String typeOfContract;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_contracts", nullable = false)
    private Long idContracts;
    @Column(name = "expired")
    private Boolean expired;
    @Column(name = "expired_date")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expiredDate;
    @Column(name = "validatedate")
    @Temporal(TemporalType.DATE)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date validatedate;
    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idUser;
    @Column(name = "deleted")
    private Boolean deleted;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasContracts() {
    }

    public HasContracts(Long idContracts) {
        this.idContracts = idContracts;
    }

    public Long getIdContracts() {
        return idContracts;
    }

    public void setIdContracts(Long idContracts) {
        this.idContracts = idContracts;
    }

    public String getContractTerms() {
        return contractTerms;
    }

    public void setContractTerms(String contractTerms) {
        this.contractTerms = contractTerms;
    }

    public Boolean getExpired() {
        return expired;
    }

    public void setExpired(Boolean expired) {
        this.expired = expired;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public String getTypeOfContract() {
        return typeOfContract;
    }

    public void setTypeOfContract(String typeOfContract) {
        this.typeOfContract = typeOfContract;
    }

    public Date getValidatedate() {
        return validatedate;
    }

    public void setValidatedate(Date validatedate) {
        this.validatedate = validatedate;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idContracts != null ? idContracts.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasContracts)) {
            return false;
        }
        HasContracts other = (HasContracts) object;
        if ((this.idContracts == null && other.idContracts != null) || (this.idContracts != null && !this.idContracts.equals(other.idContracts))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "HasContracts{" + "contractTerms=" + contractTerms + ", expired=" + expired + ", expiredDate=" + expiredDate + ", typeOfContract=" + typeOfContract + ", validatedate=" + validatedate + '}';
    }

}
