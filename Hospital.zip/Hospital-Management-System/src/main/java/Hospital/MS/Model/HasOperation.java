/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;

import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_operation", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasOperation.findAll",
            query = "SELECT h FROM HasOperation h"),
    @NamedQuery(name = "HasOperation.findByIdUser",
            query = "SELECT h FROM HasOperation h WHERE h.idUser.idUser= :id AND h.deleted=FALSE AND h.payed=FALSE"),
    @NamedQuery(name = "HasOperation.findByIdHasOperation", 
            query = "SELECT h FROM HasOperation h WHERE h.idHasOperation = :idHasOperation"),
    @NamedQuery(name = "HasOperation.findByDateOperaton", 
            query = "SELECT h FROM HasOperation h WHERE h.dateOperaton = :dateOperaton"),
    @NamedQuery(name = "HasOperation.findByTimeOperation",
            query = "SELECT h FROM HasOperation h WHERE h.timeOperation = :timeOperation")})
public class HasOperation implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "date_operaton", nullable = false)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    private Date dateOperaton;
    @Lob()
    @Size(max = 2147483647)
    @Column(name = "reason_for_operation", length = 2147483647)
    private String reasonForOperation;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "time_operation", nullable = false, length = 20)
    private String timeOperation;
    @JoinColumn(name = "id_surgery", referencedColumnName = "id_surgery", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Typeofsurgery idSurgery;
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_has_operation", nullable = false)
    @JsonIgnore
    private Long idHasOperation;

    @JoinColumn(name = "id_user", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idUser;

    @JoinColumn(name = "id_doctor", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idDoctor;
    @Column(name = "deleted")
    private Boolean deleted;
    @Column(name = "payed")
    @JsonIgnore
    private Boolean payed;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasOperation() {
    }

    public HasOperation(Long idHasOperation) {
        this.idHasOperation = idHasOperation;
    }

    public HasOperation(Long idHasOperation, Date dateOperaton, String timeOperation) {
        this.idHasOperation = idHasOperation;
        this.dateOperaton = dateOperaton;
        this.timeOperation = timeOperation;
    }

    public Long getIdHasOperation() {
        return idHasOperation;
    }

    public void setIdHasOperation(Long idHasOperation) {
        this.idHasOperation = idHasOperation;
    }

    public Date getDateOperaton() {
        return dateOperaton;
    }

    public void setDateOperaton(Date dateOperaton) {
        this.dateOperaton = dateOperaton;
    }

    public String getTimeOperation() {
        return timeOperation;
    }

    public void setTimeOperation(String timeOperation) {
        this.timeOperation = timeOperation;
    }

    public Users getIdUser() {
        return idUser;
    }

    public void setIdUser(Users idUser) {
        this.idUser = idUser;
    }

    public Users getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(Users idDoctor) {
        this.idDoctor = idDoctor;
    }

    public String getReasonForOperation() {
        return reasonForOperation;
    }

    public void setReasonForOperation(String reasonForOperation) {
        this.reasonForOperation = reasonForOperation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idHasOperation != null ? idHasOperation.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasOperation)) {
            return false;
        }
        HasOperation other = (HasOperation) object;
        if ((this.idHasOperation == null && other.idHasOperation != null) || (this.idHasOperation != null && !this.idHasOperation.equals(other.idHasOperation))) {
            return false;
        }
        return true;
    }

    public Boolean getPayed() {
        return payed;
    }

    public void setPayed(Boolean payed) {
        this.payed = payed;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.HasOperation[ idHasOperation=" + idHasOperation + " ]";
    }

    public Typeofsurgery getIdSurgery() {
        return idSurgery;
    }

    public void setIdSurgery(Typeofsurgery idSurgery) {
        this.idSurgery = idSurgery;
    }

}
