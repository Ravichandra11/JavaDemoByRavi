/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "has_appointment", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "HasAppointment.findAll", query = "SELECT h FROM HasAppointment h WHERE h.deleted=FALSE"),
    @NamedQuery(name = "HasAppointment.findByIdUser", query = "SELECT h FROM HasAppointment h WHERE h.deleted=FALSE AND h.idPatient.idUser=:id"),
    @NamedQuery(name = "HasAppointment.findbyLikefirstname", query = "SELECT h FROM HasAppointment h WHERE h.idDoctor.idUser= :id AND h.idPatient.firstname LIKE :name"),
    @NamedQuery(name = "HasAppointment.findByDoctorAndCurDate", query = "SELECT h FROM HasAppointment h WHERE h.idDoctor.idUser= :id AND h.dateAppointment= :date AND h.deleted=FALSE"),
    @NamedQuery(name = "HasAppointment.findByIdAppointment", query = "SELECT h FROM HasAppointment h WHERE h.idAppointment = :idAppointment"),
    @NamedQuery(name = "HasAppointment.findByDateAppointment", query = "SELECT h FROM HasAppointment h WHERE h.dateAppointment = :dateAppointment"),
    @NamedQuery(name = "HasAppointment.findByTimeAppointment", query = "SELECT h FROM HasAppointment h WHERE h.timeAppointment = :timeAppointment")})
public class HasAppointment implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "date_appointment", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dateAppointment;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 20)
    @Column(name = "time_appointment", nullable = false, length = 20)
    private String timeAppointment;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_appointment", nullable = false)
    @JsonIgnore
    private Long idAppointment;
    @JoinColumn(name = "id_patient", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idPatient;
    @JoinColumn(name = "id_doctor", referencedColumnName = "id_user", nullable = false)
    @ManyToOne(optional = false)
    @JsonIgnore
    private Users idDoctor;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;
    @Column(name = "costappointmnet")
    private double costappointmnet;

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public HasAppointment() {
    }

    public HasAppointment(Long idAppointment) {
        this.idAppointment = idAppointment;
    }

    public HasAppointment(Long idAppointment, Date dateAppointment, String timeAppointment) {
        this.idAppointment = idAppointment;
        this.dateAppointment = dateAppointment;
        this.timeAppointment = timeAppointment;
    }

    public Long getIdAppointment() {
        return idAppointment;
    }

    public void setIdAppointment(Long idAppointment) {
        this.idAppointment = idAppointment;
    }

    public Date getDateAppointment() {
        return dateAppointment;
    }

    public void setDateAppointment(Date dateAppointment) {
        this.dateAppointment = dateAppointment;
    }

    public String getTimeAppointment() {
        return timeAppointment;
    }

    public void setTimeAppointment(String timeAppointment) {
        this.timeAppointment = timeAppointment;
    }

    public Users getIdPatient() {
        return idPatient;
    }

    public void setIdPatient(Users idPatient) {
        this.idPatient = idPatient;
    }

    public Users getIdDoctor() {
        return idDoctor;
    }

    public void setIdDoctor(Users idDoctor) {
        this.idDoctor = idDoctor;
    }

    public double getCostappointmnet() {
        return costappointmnet;
    }

    public void setCostappointmnet(double costappointmnet) {
        this.costappointmnet = costappointmnet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idAppointment != null ? idAppointment.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof HasAppointment)) {
            return false;
        }
        HasAppointment other = (HasAppointment) object;
        if ((this.idAppointment == null && other.idAppointment != null) || (this.idAppointment != null && !this.idAppointment.equals(other.idAppointment))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.HasAppointment[ idAppointment=" + idAppointment + " ]";
    }

}
