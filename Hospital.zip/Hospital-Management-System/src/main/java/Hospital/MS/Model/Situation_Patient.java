/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class Situation_Patient {

    private String time;
    private String namePatient;
    private String nameDoctor;
    private String Hospitlyzed_At;
    private String roomNumber;
    private String department;
    private int heartBeat;
    private double temperature;
    private double res_ratio;
    private String state;
    private String mobile;
    private String phone;

    public Situation_Patient() {
    }

    public Situation_Patient(String time, String namePatient, String nameDoctor, String Hospitlyzed_At, String roomNumber, String department, int heartBeat, double temperature, double res_ratio, String state, String mobile, String phone) {
        this.time = time;
        this.namePatient = namePatient;
        this.nameDoctor = nameDoctor;
        this.Hospitlyzed_At = Hospitlyzed_At;
        this.roomNumber = roomNumber;
        this.department = department;
        this.heartBeat = heartBeat;
        this.temperature = temperature;
        this.res_ratio = res_ratio;
        this.state = state;
        this.mobile = mobile;
        this.phone = phone;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getNamePatient() {
        return namePatient;
    }

    public void setNamePatient(String namePatient) {
        this.namePatient = namePatient;
    }

    public String getNameDoctor() {
        return nameDoctor;
    }

    public void setNameDoctor(String nameDoctor) {
        this.nameDoctor = nameDoctor;
    }

    public String getHospitlyzed_At() {
        return Hospitlyzed_At;
    }

    public void setHospitlyzed_At(String Hospitlyzed_At) {
        this.Hospitlyzed_At = Hospitlyzed_At;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getHeartBeat() {
        return heartBeat;
    }

    public void setHeartBeat(int heartBeat) {
        this.heartBeat = heartBeat;
    }

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }

    public double getRes_ratio() {
        return res_ratio;
    }

    public void setRes_ratio(double res_ratio) {
        this.res_ratio = res_ratio;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getState() {
        if (temperature > 36 && temperature < 38.5 && heartBeat > 75 && heartBeat < 200) {
            state = "Stable";
        } else {
            state = " not stable ";

        }

        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Situation_Patient{" + "time=" + time + ", namePatient=" + namePatient + ", nameDoctor=" + nameDoctor + ", Hospitlyzed_At=" + Hospitlyzed_At + ", roomNumber=" + roomNumber + ", department=" + department + ", heartBeat=" + heartBeat + ", temperature=" + temperature + ", state=" + state + ", mobile=" + mobile + ", phone=" + phone + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + Objects.hashCode(this.time);
        hash = 31 * hash + Objects.hashCode(this.namePatient);
        hash = 31 * hash + Objects.hashCode(this.nameDoctor);
        hash = 31 * hash + Objects.hashCode(this.Hospitlyzed_At);
        hash = 31 * hash + Objects.hashCode(this.roomNumber);
        hash = 31 * hash + Objects.hashCode(this.department);
        hash = 31 * hash + this.heartBeat;
        hash = 31 * hash + (int) (Double.doubleToLongBits(this.temperature) ^ (Double.doubleToLongBits(this.temperature) >>> 32));
        hash = 31 * hash + (int) (Double.doubleToLongBits(this.res_ratio) ^ (Double.doubleToLongBits(this.res_ratio) >>> 32));
        hash = 31 * hash + Objects.hashCode(this.state);
        hash = 31 * hash + Objects.hashCode(this.mobile);
        hash = 31 * hash + Objects.hashCode(this.phone);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Situation_Patient other = (Situation_Patient) obj;
        if (this.heartBeat != other.heartBeat) {
            return false;
        }
        if (Double.doubleToLongBits(this.temperature) != Double.doubleToLongBits(other.temperature)) {
            return false;
        }
        if (Double.doubleToLongBits(this.res_ratio) != Double.doubleToLongBits(other.res_ratio)) {
            return false;
        }
        if (!Objects.equals(this.time, other.time)) {
            return false;
        }
        if (!Objects.equals(this.namePatient, other.namePatient)) {
            return false;
        }
        if (!Objects.equals(this.nameDoctor, other.nameDoctor)) {
            return false;
        }
        if (!Objects.equals(this.Hospitlyzed_At, other.Hospitlyzed_At)) {
            return false;
        }
        if (!Objects.equals(this.roomNumber, other.roomNumber)) {
            return false;
        }
        if (!Objects.equals(this.department, other.department)) {
            return false;
        }
        if (!Objects.equals(this.state, other.state)) {
            return false;
        }
        if (!Objects.equals(this.mobile, other.mobile)) {
            return false;
        }
        if (!Objects.equals(this.phone, other.phone)) {
            return false;
        }
        return true;
    }

}
