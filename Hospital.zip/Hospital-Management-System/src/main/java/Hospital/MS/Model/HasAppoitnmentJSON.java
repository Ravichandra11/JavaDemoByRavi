/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
public class HasAppoitnmentJSON {

    private Date dateAppointment;
    private String firstname, lastname;
    private String timeAppointment;

    public HasAppoitnmentJSON() {
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public HasAppoitnmentJSON(Date dateAppointment, String firstname, String lastname, String timeAppointment) {
        this.dateAppointment = dateAppointment;
        this.firstname = firstname;
        this.lastname = lastname;
        this.timeAppointment = timeAppointment;
    }

    public HasAppoitnmentJSON(Date dateAppointment, String timeAppointment) {
        this.dateAppointment = dateAppointment;
        this.timeAppointment = timeAppointment;
    }

    public Date getDateAppointment() {
        return dateAppointment;
    }

    public void setDateAppointment(Date dateAppointment) {
        this.dateAppointment = dateAppointment;
    }

    public String getTimeAppointment() {
        return timeAppointment;
    }

    public void setTimeAppointment(String timeAppointment) {
        this.timeAppointment = timeAppointment;
    }

}
