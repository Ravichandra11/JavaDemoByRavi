/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "departments", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Departments.findAlld", query = "SELECT d FROM Departments d WHERE d.deleted=FALSE ORDER BY d.department ASC"),
    @NamedQuery(name = "Departments.findByIdDepartment", query = "SELECT d FROM Departments d WHERE d.idDepartment = :idDepartment"),
    @NamedQuery(name = "Departments.findByDepartment", query = "SELECT d FROM Departments d WHERE d.department = :department")})
public class Departments implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 100)
    @Column(name = "department", nullable = false, length = 100)
    private String department;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_department", nullable = false)

    private long idDepartment;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idDepartment")
    @JsonIgnore
    private List<Hasdepartment> hasdepartmentList;
    @Column(name = "deleted")
    @JsonIgnore
    private Boolean deleted;

    @Column(name = "costHospitlyze")
    private double costHospitlyze;
    @Column(name = "costappointment")
    private double costappointment;
    @Column(name = "costAnalysis")
    private double costAnalysis;

    public double getCostappointment() {
        return costappointment;
    }

    public void setCostappointment(double costappointment) {
        this.costappointment = costappointment;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public Departments() {
    }

    public Departments(Integer idDepartment) {
        this.idDepartment = idDepartment;
    }

    public Departments(Integer idDepartment, String department) {
        this.idDepartment = idDepartment;
        this.department = department;
    }

    public long getIdDepartment() {
        return idDepartment;
    }

    public void setIdDepartment(long idDepartment) {
        this.idDepartment = idDepartment;
    }

    @XmlTransient
    @JsonIgnore
    public List<Hasdepartment> getHasdepartmentList() {
        return hasdepartmentList;
    }

    public void setHasdepartmentList(List<Hasdepartment> hasdepartmentList) {
        this.hasdepartmentList = hasdepartmentList;
    }

    public double getCostHospitlyze() {
        return costHospitlyze;
    }

    public void setCostHospitlyze(double costHospitlyze) {
        this.costHospitlyze = costHospitlyze;
    }

    public double getCostAnalysis() {
        return costAnalysis;
    }

    public void setCostAnalysis(double costAnalysis) {
        this.costAnalysis = costAnalysis;
    }

    @Override
    public String toString() {
        return "Hospital.MS.Model.Departments[ idDepartment=" + idDepartment + " ]";
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

}
