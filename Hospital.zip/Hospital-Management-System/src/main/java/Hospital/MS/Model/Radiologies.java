/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import org.springframework.stereotype.Component;

/**
 *
 * @author chahir chalouati
 */
@Component
@Entity
@Table(name = "radiologies", catalog = "my_hospital", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Radiologies.findAll", query = "SELECT r FROM Radiologies r"),

    @NamedQuery(name = "Radiologies.findByIdRadiologies", query = "SELECT r FROM Radiologies r WHERE r.idRadiologies = :idRadiologies")})
public class Radiologies implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Lob
    @Column(name = "radiology", nullable = false)
    private byte[] radiology;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id_radiologies", nullable = false)
    private Long idRadiologies;
    @JsonIgnore
    @OneToMany(mappedBy = "idRadiologies")
    private List<HasRadiology> hasRadiologyList;
    @Column(name = "deleted")
    private Boolean deleted;
    @Column(name = "costRadiology", nullable = true)
    private double costRadiology;

    public Radiologies() {
    }

    public byte[] getRadiology() {
        return radiology;
    }

    public void setRadiology(byte[] radiology) {
        this.radiology = radiology;
    }

    public Long getIdRadiologies() {
        return idRadiologies;
    }

    public void setIdRadiologies(Long idRadiologies) {
        this.idRadiologies = idRadiologies;
    }

    public List<HasRadiology> getHasRadiologyList() {
        return hasRadiologyList;
    }

    public void setHasRadiologyList(List<HasRadiology> hasRadiologyList) {
        this.hasRadiologyList = hasRadiologyList;
    }

    public Boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(Boolean deleted) {
        this.deleted = deleted;
    }

    public double getCostRadiology() {
        return costRadiology;
    }

    public void setCostRadiology(double costRadiology) {
        this.costRadiology = costRadiology;
    }

}
