package Hospital.MS.Services;

import Hospital.MS.Model.MyUserDetails;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 *
 * @author Chahir Chalouati
 */
@Service
public class MyUserDetailsServices implements UserDetailsService {

    @Autowired
    UserRepository userRepository;
    @Autowired
    Users user;

    @Override
    public UserDetails loadUserByUsername(String string) throws UsernameNotFoundException {
        user = userRepository.findByEmail(string);
        if (user == null) {
            throw new UsernameNotFoundException("enable to find user with email :" + string);

        }

        return new MyUserDetails(user);

    }

    public Users getUser() {
        return user;
    }

}
