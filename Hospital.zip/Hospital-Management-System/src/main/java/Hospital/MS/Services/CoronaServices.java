///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package Hospital.MS.Services;
//
//import Hospital.MS.Model.Corona;
//import Hospital.MS.Model.Countries;
//import Hospital.MS.Repository.CoronaRepository;
//import Hospital.MS.Repository.CountriesRepository;
//import com.google.gson.JsonArray;
//import com.google.gson.JsonElement;
//import com.google.gson.JsonObject;
//import com.google.gson.JsonParser;
//import com.google.gson.JsonSyntaxException;
//import java.io.IOException;
//import java.net.URI;
//import java.net.http.HttpClient;
//import java.net.http.HttpRequest;
//import java.net.http.HttpResponse;
//
//import java.text.ParseException;
//import javax.annotation.PostConstruct;
//import lombok.Getter;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
///**
// *
// * @author chahir chalouati
// */
//@Service
//public class CoronaServices {
//
////    ----> spero che link fornisce i dati come previsto ...
//    @Autowired
//    Countries countries;
//    @Autowired
//    CoronaRepository coronaRepository;
//    @Autowired
//    CountriesRepository countriesRepository;
//
//    private static final String VIRUS_DATA_URL = "https://opendata.ecdc.europa.eu/covid19/casedistribution/json/";
////    private static final String VIRUS_DATA_URL = "https://api.covid19api.com/all";
////    private static final String VIRUS_DATA_SUMMARY = "https://api.covid19api.com/summary";
//    // private static final String URL_Countries = "https://corona.lmao.ninja/v2/countries";
//
//    @PostConstruct
//    @Scheduled(cron = "* * 1 * * *")
//    public void fetchVirusData() throws ParseException, IOException, InterruptedException {
//
//        HttpClient client = HttpClient.newHttpClient();
//        HttpRequest request = HttpRequest.newBuilder()
//                .uri(URI.create(VIRUS_DATA_URL))
//                .build();
//        String httpResponse = client.send(request, HttpResponse.BodyHandlers.ofString()).body();
//
//        JsonParser parser = new JsonParser();
//        JsonElement jsonTree = parser.parse(httpResponse);
//        if (jsonTree.isJsonObject()) {
//            JsonObject jsonObject = jsonTree.getAsJsonObject();
//
//            JsonElement records = jsonObject.get("records");
//            System.out.println(records.getAsString());
//
////            if (records.isJsonArray()) {
////            
////                JsonArray ray = records.getAsJsonArray();
////                coronaRepository.deleteCorona();
////                ray.iterator().forEachRemaining((el) -> {
////                    System.out.println(el.getAsJsonObject().getAsString());
////                });
//
//            
////                for (JsonElement rec : ray) {
////                 
////                    JsonObject jb = rec.getAsJsonObject();
////                    Corona corona = new Corona();
////                    corona.setDateRep(jb.get("dateRep").getAsString());
////                    corona.setDay(jb.get("day").getAsString());
////                    corona.setMonth(jb.get("month").getAsString());
////                    corona.setYear(jb.get("year").getAsString());
////                    corona.setCases(jb.get("cases").getAsString());
////                    corona.setDeaths(jb.get("deaths").getAsString());
////                    corona.setCountriesAndTerritories(jb.get("countriesAndTerritories").getAsString());
////                    corona.setGeoId(jb.get("geoId").getAsString());
////                    corona.setCountryterritoryCode(jb.get("countryterritoryCode").getAsString());
////                    corona.setPopData2018(jb.get("popData2018").getAsString());
////                    corona.setContinentExp(jb.get("continentExp").getAsString());
////                    System.out.println(corona.toString());
////                    System.out.println("5");
////                    coronaRepository.save(corona);
////
////                }
//            }
//        }
//
//    }
////}
