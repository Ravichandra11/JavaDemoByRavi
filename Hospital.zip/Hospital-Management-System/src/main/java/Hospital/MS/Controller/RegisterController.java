/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Controller;

import Hospital.MS.Model.Addresses;
import Hospital.MS.Model.Message;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.AddressesRepository;
import Hospital.MS.Repository.AuthoritiesRepository;
import Hospital.MS.Repository.UserRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class RegisterController {

    @Autowired
    Message message;
    @Autowired
    Users users;
    @Autowired
    UserRepository userRepository;
    @Autowired
    Addresses addresses;
    @Autowired
    AddressesRepository addressesRepository;
    @Autowired
    AuthoritiesRepository authoritiesRepository;
    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     * get Register Page
     *
     * @return
     */
    @GetMapping("/register")
    public String pageRegister() {
        return "register";
    }

    @PostMapping(value = "/register/save", consumes = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String registerSave(@RequestBody String str) throws IOException {
        // System.out.println(str);
        try {
            //deserialize  objects from post
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(str);
            users = mapper.convertValue(node.get("users"), Users.class);
            System.out.println(users.toString());
            addresses = mapper.convertValue(node.get("addresses"), Addresses.class);
            System.out.println(addresses.toString());
            bCryptPasswordEncoder = new BCryptPasswordEncoder();
            users.setPassword("23051988");
            users.setPassword(bCryptPasswordEncoder.encode(users.getPassword()));
            users.setDeleted(Boolean.FALSE);
            users.setIdAuthoritie(authoritiesRepository.findByAuthoritie("USER"));
            userRepository.save(users);
            addresses.setIdUser(userRepository.findByEmail(users.getEmail()));
            addresses.setDeleted(Boolean.FALSE);
            addressesRepository.save(addresses);
            message.setMessage("registred with success");
            if (userRepository.findByEmail(users.getEmail()) != null) {

                message.setMessage("you have an account");

            } else {

            }
        } catch (JsonProcessingException ex) {
            message.setMessage("make that all your input are correct ");
        } catch (DataIntegrityViolationException e) {
            message.setMessage("This email already exist do you want to login with your account  ");
        } catch (NullPointerException | ConstraintViolationException ee) {
            message.setMessage("Some value must not be null ");
        }
        return message.toString();
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
