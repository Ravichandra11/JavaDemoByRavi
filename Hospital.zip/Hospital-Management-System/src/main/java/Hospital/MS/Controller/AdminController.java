package Hospital.MS.Controller;

import Hospital.MS.Model.Addresses;
import Hospital.MS.Model.Authorities;
import Hospital.MS.Model.Departments;
import Hospital.MS.Model.HasContacts;
import Hospital.MS.Model.HasContracts;
import Hospital.MS.Model.Hasdepartment;
import Hospital.MS.Model.Message;
import Hospital.MS.Model.MyCostumeUSER;
import Hospital.MS.Model.Typeofsurgery;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.AddressesRepository;
import Hospital.MS.Repository.AuthoritiesRepository;
import Hospital.MS.Repository.DepartmentsRepository;
import Hospital.MS.Repository.HasAppointmentRepository;
import Hospital.MS.Repository.HasContactRepository;
import Hospital.MS.Repository.HasContractsRepository;
import Hospital.MS.Repository.HasDepartmentRepository;
import Hospital.MS.Repository.HospitlizesRepository;
import Hospital.MS.Repository.TypeofsurgeryRepository;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class AdminController {

    @Autowired
    JavaMailSender emailSender;
    private String idDept = "";
    MyCostumeUSER myCostumeUSER;
    @Autowired
    HasContacts hasContacts;
    @Autowired
    Addresses addresses;
    @Autowired
    Message message;
    ModelAndView model;
    @Autowired
    MyUserDetailsServices myUserDetailsServices;
    @Autowired
    Users users;
    @Autowired
    UserRepository userRepository;
    @Autowired
    AuthoritiesRepository authoritiesRepository;
    @Autowired
    DepartmentsRepository departmentsRepository;
    @Autowired
    Departments department;
    @Autowired
    Authorities authorities;
    @Autowired
    HasDepartmentRepository hasDepartmentRepository;
    @Autowired
    HasContactRepository hasContactRepository;
    @Autowired
    Hasdepartment hasdepartment;
    @Autowired
    HasContractsRepository hasContractsRepository;

    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Autowired
    AddressesRepository addressesRepository;

    private String pass = "";

    private final List<String> typeOfContract
            = Arrays.asList(new String[]{"Agency staff-contract", "Fixed-term contract", "Full-time contract", "Part-Time contract"});

    /**
     * get admin page
     *
     * @param model
     * @return string value
     */
    @GetMapping("/admin")
    public String pageAdmin(Model model) {
        List<String> typeContracts = new LinkedList<>();
        typeOfContract.forEach((t) -> {
            typeContracts.add(t);

        });

        this.users.setPassword("");
        model.addAttribute("admin", myUserDetailsServices.getUser());
        model.addAttribute("message", message);
        model.addAttribute("users", this.users);
        model.addAttribute("TypeOfContracts", typeContracts);
        model.addAttribute("addresses", addresses);
        model.addAttribute("contacts", hasContacts);
        model.addAttribute("listEmployee", userRepository.findAllEmployee("USER"));
        model.addAttribute("listauthoritie", authoritiesRepository.findAll());
        model.addAttribute("listDepartment", departmentsRepository.findAlld());
        return "admin";
    }

    /**
     * get option page
     *
     * @param model
     * @return page admin
     */
    @GetMapping("/admin/options")
    public String pageOption(Model model) {
        return "Options_Admin";
    }

    /**
     * get all departments
     *
     * @return all departments
     */
    @GetMapping(value = "/admin/getAll/departments", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Departments> getAllDepartments() {
        return departmentsRepository.findAlld();
    }

    /**
     * get all contracts
     *
     * @return list of contracts
     */
    @GetMapping(value = "/admin/get/all/contracts/", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Object> gtAllContracts() {
        List<Object> list = new LinkedList();
        hasContractsRepository.findAll().forEach((object) -> {
            Object[] Contract = {object, object.getIdUser().getFirstname(), object.getIdUser().getLastname()};
            list.add(Contract);
        });
        return list;
    }

    /**
     * get department details
     *
     * @param id
     * @return departments details
     */
    @PostMapping(value = "/admin/details/department", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    Optional<Departments> getDetailsDEpat(@RequestBody String id) {
        return departmentsRepository.findById(Long.valueOf(id));
    }

    /**
     * search for contract
     *
     * @param name
     * @return list of contracts
     */
    @PostMapping(value = "/admin/option/search/contract", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Object> findContracts(@RequestBody String name) {

        List<Object> list = new LinkedList();
        hasContractsRepository.findbyNameEmployeeLike(name + "%").forEach((object) -> {
            Object[] Contract = {object, object.getIdUser().getFirstname(), object.getIdUser().getLastname()};
            list.add(Contract);
        });
        return list;

    }

    /**
     * search for contract
     *
     * @param cost
     * @return string value
     */
    @PostMapping(value = "/admin/option/dept/cost/appointment",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String setcostDeptapp(@RequestBody String cost) {
        Departments dept = departmentsRepository.getOne(Long.valueOf(idDept));
        if (dept != null && !" ".equals(idDept)) {
            dept.setCostappointment(Double.valueOf(cost));
            departmentsRepository.save(dept);
            message.setMessage("Done");

        } else {
            message.setMessage("can't save this department ");
        }

        return message.toString();

    }

    /**
     * search for contract
     *
     * @param cost
     * @return string value
     */
    @PostMapping(value = "/admin/option/dept/analysis", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String setCostDeptAnalysis(@RequestBody String cost) {
        Departments dept = departmentsRepository.getOne(Long.valueOf(idDept));
        if (dept != null && !" ".equals(idDept)) {
            dept.setCostAnalysis(Double.valueOf(cost));
            departmentsRepository.save(dept);
            message.setMessage("Done");

        } else {
            message.setMessage("can't save this department ");
        }

        return message.toString();
    }

    /**
     * show employee details
     *
     * @param email
     * @return list of employees
     */
    @RequestMapping(value = "admin/show/One/patient", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Object> showOne(@RequestBody String email) {

        List<Object> listObject = new LinkedList<>();
        try {
            users = userRepository.findByEmail(email);
            addresses = users.getAddresses();
            hasContacts = users.getHasContacts();
            authorities = users.getIdAuthoritie();
            hasdepartment = users.getHasdepartment();
            authorities.setUsersList(new LinkedList<>());
            pass = this.users.getPassword();
            this.users.setPassword("");
            listObject.add(users);
            listObject.add(addresses);
            listObject.add(authorities);
            listObject.add(users.getHasdepartment().getIdDepartment());
            listObject.add(hasContacts);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return listObject;
    }

    /**
     * save new employee
     *
     * @param json
     * @return string value
     */
    @RequestMapping(value = "admin/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveEmployee(@RequestBody String json) {
        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            Users user = mapper.convertValue(node.get("users"), Users.class);
            hasContacts = mapper.convertValue(node.get("contacts"), HasContacts.class);
            department = mapper.convertValue(node.get("department"), Departments.class);
            authorities = mapper.convertValue(node.get("authorities"), Authorities.class);
            addresses = mapper.convertValue(node.get("addresses"), Addresses.class);

            user.setIdAuthoritie(authorities);
            bCryptPasswordEncoder = new BCryptPasswordEncoder();
            user.setDeleted(Boolean.FALSE);
            String generatedString = RandomStringUtils.randomAlphabetic(20);
            user.setPassword(bCryptPasswordEncoder.encode(generatedString));

            userRepository.save(user);// save employee
            Hasdepartment hasdept = new Hasdepartment();
            hasdept.setDeleted(Boolean.FALSE);
            hasdept.setIdDepartment(department);
            hasdept.setIdUser(user);

            hasDepartmentRepository.save(hasdept);//save department
            hasContacts.setIdUser(user);
            hasContacts.setDeleted(Boolean.FALSE);

            hasContactRepository.save(hasContacts);// save contact

            addresses.setIdUser(user);// save addresses
            addresses.setDeleted(Boolean.FALSE);
            addressesRepository.save(addresses);

            message.setMessage("saved with success");
            sendMessage(user.getEmail(), generatedString, user.getFirstname(), user.getLastname());
        } catch (JsonProcessingException | IllegalArgumentException e) {
            message.setMessage("can't save this employee try again ");
        } catch (IOException ex) {
            Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return message.toString();
    }

    /**
     * update employee
     *
     * @param json
     * @return string value
     * @throws java.io.IOException
     */
    @RequestMapping(value = "admin/edit", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String editEmployee(@RequestBody String json) throws IOException {

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            Users user = mapper.convertValue(node.get("users"), Users.class);
            HasContacts hasContact = mapper.convertValue(node.get("contacts"), HasContacts.class);
            Departments departments = mapper.convertValue(node.get("department"), Departments.class);
            Authorities authoritie = mapper.convertValue(node.get("authorities"), Authorities.class);
            Addresses addresse = mapper.convertValue(node.get("addresses"), Addresses.class);

            user.setIdUser(this.users.getIdUser());
            user.setIdAuthoritie(authoritie);
            user.setPassword(pass);
            user.setDeleted(Boolean.FALSE);
            userRepository.save(user);

            hasdepartment.setDeleted(Boolean.FALSE);
            hasdepartment.setIdDepartment(departments);
            hasdepartment.setIdUser(user);

            hasDepartmentRepository.save(hasdepartment);//save department
            hasContact.setIdContacts(this.hasContacts.getIdContacts());
            hasContact.setIdUser(user);
            hasContact.setDeleted(Boolean.FALSE);

            hasContactRepository.save(hasContact);// save contact

            addresse.setIdAddresses(this.addresses.getIdAddresses());// save addresses
            addresse.setIdUser(user);
            addresse.setDeleted(Boolean.FALSE);
            addressesRepository.save(addresse);

            message.setMessage("edit with success");
        } catch (JsonProcessingException ex) {
            System.out.println(ex.getMessage());
        } catch (DataIntegrityViolationException e) {
            System.out.println(e.getMessage());
        } catch (NullPointerException | ConstraintViolationException ee) {
            System.out.println(ee.getMessage());
        }

        return message.toString();

    }

    /**
     * delete employee
     *
     * @param email
     * @return string value
     */
    @PostMapping(value = "admin/delete", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String deleteEmployee(@RequestBody String email) {
        System.out.println(email);
        try {
            Users u = userRepository.findByEmail(email);
            u.setDeleted(Boolean.TRUE);
            userRepository.save(u);
            message.setMessage("deleted with success");
        } catch (Exception e) {
            message.setMessage("can't delete this employee ");
        }

        message.setMessage("deleted with success");
        return message.toString();
    }

    /**
     * search for employee
     *
     * @param search
     * @return costumerUser object
     * @throws com.fasterxml.jackson.core.JsonProcessingException
     */
    @RequestMapping(value = "admin/search", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<MyCostumeUSER> search(@RequestBody String search) throws JsonProcessingException {

        List<MyCostumeUSER> myCostumUserList = new LinkedList<>();

        if (search.length() > 0) {
            List<Users> listusers = userRepository.findUserByLikeFirstname(search + "%", "USER");
            if (listusers.size() >= 0) {
                listusers.stream().map((user) -> {
                    myCostumeUSER = new MyCostumeUSER(user.getFirstname(),
                            user.getLastname(), user.getEmail(), user.getIdAuthoritie().getAuthoritie());
                    return user;
                }).forEachOrdered((_item) -> {
                    myCostumUserList.add(myCostumeUSER);
                });

            }
        } else {

            List<Users> listusers = userRepository.findAllEmployee("USER");
            if (listusers.size() >= 0) {
                listusers.stream().map((user) -> {
                    myCostumeUSER = new MyCostumeUSER(user.getFirstname(),
                            user.getLastname(), user.getEmail(), user.getIdAuthoritie().getAuthoritie());
                    return user;
                }).forEachOrdered((_item) -> {
                    myCostumUserList.add(myCostumeUSER);
                });

            }

        }

        return myCostumUserList;
    }

    /**
     * save contract
     *
     * @param contract
     * @return string value
     * @throws java.io.IOException
     */
    @RequestMapping(value = "admin/contract", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveContract(@RequestBody String contract) throws IOException {
        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(contract);

            HasContracts hasContracts = mapper.convertValue(node.get("hasContracts"), HasContracts.class);

            hasContracts.setIdUser(this.users);
            hasContracts.setDeleted(Boolean.FALSE);
            hasContracts.setExpired(Boolean.FALSE);

            this.users.getHasContractsList().stream().map((_item) -> {
                hasContracts.setExpired(Boolean.TRUE);
                return _item;
            }).map((_item) -> {
                hasContracts.setDeleted(Boolean.TRUE);
                return _item;
            }).forEachOrdered((_item) -> {
                hasContractsRepository.save(hasContracts);
            });

            hasContractsRepository.save(hasContracts);
            message.setMessage("New Contract was Saved With Success");

        } catch (JsonProcessingException | IllegalArgumentException e) {
            message.setMessage("can't saved this contract ");
        }

        return message.toString();

    }

    /**
     * getting department
     *
     * @return list Of departments
     */
    @GetMapping(value = "admin/department", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Departments> getDepartments() {
        List<Departments> listdept = new LinkedList<>();
        departmentsRepository.findAlld().stream().map((department) -> {
            department.setIdDepartment(0);
            return department;
        }).forEachOrdered((department) -> {
            listdept.add(department);
        });

        return listdept;
    }

    /**
     * create new department
     *
     * @param department
     * @return string value
     * @throws JsonProcessingException
     */
    @PostMapping(value = "/admin/save/new/department",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveDepartment(@RequestBody String department) throws JsonProcessingException, IOException {

        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readTree(department);
        Departments dept = mapper.convertValue(
                node.get("Departments"), Departments.class);
        try {
            dept.setDeleted(Boolean.FALSE);
            departmentsRepository.save(dept);
            message.setMessage("saved with success ");
        } catch (Exception e) {
            message.setMessage("Sorry can't save this department ");
        }

        return message.toString();
    }

    /**
     * delete department
     *
     * @param department
     * @return string value
     * @throws java.io.IOException
     */
    @PostMapping(value = "/admin/delete/department",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String deleteDepartment(@RequestBody String department) throws IOException {

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(department);
            Departments dept
                    = mapper.convertValue(node.get("Departments"), Departments.class);
            dept.setDeleted(Boolean.TRUE);
            departmentsRepository.save(dept);

            message.setMessage("deleted");

        } catch (JsonProcessingException | IllegalArgumentException e) {
            message.setMessage(" sorry  can't delete it ");
        }
        return message.toString();
    }

    /**
     * update department
     *
     * @param department
     * @return string value
     * @throws JsonProcessingException
     */
    @PostMapping(value = "/admin/update/department",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String UpdateDepartment(@RequestBody String department) throws JsonProcessingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readTree(department);
        Departments dept = mapper.convertValue(
                node.get("Departments"), Departments.class);
        try {
            departmentsRepository.save(dept);
            message.setMessage("saved with success ");
        } catch (Exception e) {
            message.setMessage("Sorry can't save this department ");
        }

        return message.toString();
    }

    /**
     * change password for current user
     *
     * @param json
     * @return string value
     * @throws java.io.IOException
     */
    @PostMapping(value = "admin/change/password", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String changePassword(@RequestBody String json) throws IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            users = myUserDetailsServices.getUser();// get current user
            String newPassword = node.get("newPassword").asText();
            String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
            if (newPassword.matches(pattern)) {
                bCryptPasswordEncoder = new BCryptPasswordEncoder();
                users.setPassword(bCryptPasswordEncoder.encode(newPassword));
                userRepository.save(users);
                message.setMessage("Please check your email");
            } else {
                message.setMessage("password must have Minimum eight characters,  at least one uppercase letter, one lowercase letter, one number and one special character");
            }

        } catch (JsonProcessingException e) {
            message.setMessage("can't change password ");
        }
        return message.toString();
    }
    /**
     * get surgeries
     *
     * @param req
     * @param ex
     * @return type of surgery list
     */
    @Autowired
    TypeofsurgeryRepository typeofsurgeryRepository;

    @GetMapping(value = "/admin/get/surgeries", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Typeofsurgery> getListSurgery() {
        return typeofsurgeryRepository.findAll();
    }

    /**
     * add new Surgery
     *
     * @param json
     * @return string value
     * @throws com.fasterxml.jackson.core.JsonProcessingException
     */
    @PostMapping(value = "/admin/new/surgery",
            produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveSurgery(@RequestBody String json)
            throws JsonProcessingException, IOException {
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node = mapper.readTree(json);
        try {
            Typeofsurgery typeofsurgery
                    = mapper.convertValue(node.get("surgery"), Typeofsurgery.class);
            typeofsurgeryRepository.save(typeofsurgery);
            message.setMessage("done");
        } catch (IllegalArgumentException e) {
            message.setMessage("can't save");
        }

        return message.toString();
    }

    /**
     * delete surgery final
     *
     * @param json
     * @return string value
     * @throws java.io.IOException
     */
    @PostMapping(value = "/admin/delete/surgeries", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String deleteSurgery(@RequestBody String json) throws IOException {

        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            Typeofsurgery typeofsurgery
                    = mapper.convertValue(node.get("surgery"), Typeofsurgery.class);
            typeofsurgeryRepository.deleteById(typeofsurgery.getIdSurgery());

            message.setMessage("done");

        } catch (JsonProcessingException | IllegalArgumentException e) {
        }

        message.setMessage("deleted");
        return message.toString();
    }
    @Autowired
    HospitlizesRepository hospitlizesRepository;
    @Autowired
    HasAppointmentRepository hasAppointmentRepository;

    @GetMapping(value = "admin/get/hospital/details", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Object> getDetailsHospital() {
        List<Object> list = new LinkedList<>();

        list.add(userRepository.findAllCountPatient());
        list.add(hospitlizesRepository.count());
        list.add(hasAppointmentRepository.count());
        return list;

    }

    /**
     * send email to new patient
     *
     * @param email
     * @param password
     * @param firstname
     * @param lastname
     */
    private void sendMessage(String email, String password, String firstname, String lastname) {

        // sending password new password to new patient email
        SimpleMailMessage m = new SimpleMailMessage();
        m.setTo(email);
        m.setSubject("Hospital Management System " + " Recover PASSOWRD :");
        m.setText("Welcome in Hospital Management System Mr/Ms :" + firstname + " " + lastname + ""
                + "\n" + "Your email is :" + email
                + "\n" + "Your new Password is : " + password
                + "\n" + "After access to your account is raccomended to change your password "
                + "\n" + "Thank You ");
        // Send Message!
        this.emailSender.send(m);

    }

    /**
     *
     * @param req
     * @param ex
     * @return error page
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
