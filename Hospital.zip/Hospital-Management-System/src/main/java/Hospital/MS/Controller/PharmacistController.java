/*
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
 /*
    Created on : Mar 25, 2020, 3:21:22 PM
    Author     : chahir chalouati
 */
package Hospital.MS.Controller;

import Hospital.MS.Model.HasMedicines;
import Hospital.MS.Model.Medicines;
import Hospital.MS.Model.Message;
import Hospital.MS.Model.MyCostumeUSER;
import Hospital.MS.Model.Payment;

import Hospital.MS.Model.Users;
import Hospital.MS.Repository.HasMedicinesRepository;
import Hospital.MS.Repository.MedicinesRepository;
import Hospital.MS.Repository.PaymentRepository;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class PharmacistController {

    @Autowired
    UserRepository userRepository;
    @Autowired
    Payment payment;
    @Autowired
    PaymentRepository paymentRepository;
    @Autowired
    Message message;
    @Autowired
    MedicinesRepository medicinesRepository;
    @Autowired
    MyUserDetailsServices muds;
    @Autowired
    HasMedicinesRepository hasMedicinesRepository;

    private Long id;
    private List<Medicines> listMedicines;

    @RequestMapping("/pharmacist")
    public String pagePharmacist(Model model) {
        model.addAttribute("pharmacist", muds.getUser());
        return "pharmacist";
    }

    /**
     * send all medicines
     *
     * @return
     */
    @GetMapping(value = "pharmacist/get/all/medicines", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Medicines> getAllMedicines() {
        return medicinesRepository.findAllDISTINCT();
    }

    /**
     * get all has medicines
     *
     * @return
     */
    @GetMapping(value = "pharmacist/get/all/hasmedicines/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<MyCostumeUSER> getAllHasMedicines() {
        List<MyCostumeUSER> listMyUser = new LinkedList();
        hasMedicinesRepository.findAllDistinct().stream().map((Users users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setSecurtiyNumber(users.getPatientdetails().getSecurtiyNumber());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listMyUser.add(myCostumeUSER);
        });

        return listMyUser;
    }

    /**
     * find all medicines for selected Patient
     *
     * @param securtiyNumber
     * @return
     */
    @PostMapping(value = "pharmacist/get/all/medicines/by/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Medicines> getMedicinesPatient(@RequestBody String securtiyNumber) {
        return hasMedicinesRepository.findAllMedicinesByIdUser(securtiyNumber);

    }

    /**
     * search for medicines
     *
     * @param medicines
     * @return
     */
    @PostMapping(value = "pharmacist/find/medicines", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Medicines> findMedicines(@RequestBody String medicines) {
        listMedicines = medicinesRepository.findByNameMedecineLike(medicines.trim() + "%");
        return listMedicines;

    }

    /**
     * find how has medicines and there names will be displayed in the list
     *
     * @param patient
     * @return
     */
    @PostMapping(value = "pharmacist/find/hasmedicines/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<MyCostumeUSER> findhasMedicinesByNameUser(@RequestBody String patient) {

        List<MyCostumeUSER> listMyUser = new LinkedList();
        hasMedicinesRepository.findAllDistinctLIKE(patient + "%").stream().map((Users users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setSecurtiyNumber(users.getPatientdetails().getSecurtiyNumber());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listMyUser.add(myCostumeUSER);
        });

        return listMyUser;

    }

    /**
     * save new medicines in db
     *
     * @param json
     * @return
     */
    @PostMapping(value = "pharmacist/save/medicines", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveMedicines(@RequestBody String json) throws IOException {
        System.out.println(json);
        ObjectMapper mapper = new ObjectMapper();
        JsonNode node;
        try {

            node = mapper.readTree(json);
            String nameMedicines = node.get("nameMedicines").asText();
            int quantity = node.get("quantity").asInt();
            double price = node.get("price").asDouble();
            Medicines medicines = new Medicines();
            if (quantity > 0) {
                medicines.setAvailble(Boolean.TRUE);
            } else {
                medicines.setAvailble(Boolean.FALSE);
            }

            medicines.setDeleted(Boolean.FALSE);
            medicines.setNameMedecine(nameMedicines);
            medicines.setPrice(price);
            medicines.setQuantity(quantity);

            medicinesRepository.save(medicines);

            System.out.println(medicines.toString());
            message.setMessage("done");

        } catch (JsonProcessingException | IllegalArgumentException e) {
            message.setMessage("can't save this medicines");
        }

        return message.toString();
    }

    /**
     * edit medicines
     *
     * @param json
     * @return
     */
    @PostMapping(value = "pharmacist/edit/medicines", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String editMedicines(@RequestBody String json) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        JsonNode node;
        try {

            node = mapper.readTree(json);
            String nameMedicines = node.get("nameMedicines").asText();
            int quantity = node.get("quantity").asInt();
            double price = node.get("price").asDouble();
            Medicines medicines = medicinesRepository.getOne(id);
            if (quantity > 0) {
                medicines.setAvailble(Boolean.TRUE);
            } else {
                medicines.setAvailble(Boolean.FALSE);
            }

            medicines.setDeleted(Boolean.FALSE);
            medicines.setNameMedecine(nameMedicines);
            medicines.setPrice(price);
            medicines.setQuantity(quantity);

            medicinesRepository.save(medicines);

            System.out.println(medicines.toString());
            message.setMessage("done");

        } catch (JsonProcessingException | IllegalArgumentException e) {
            message.setMessage("can't save this medicines");
        }

        return message.toString();
    }

    /**
     * delete medicines not completely delete
     *
     * @return
     */
    @PostMapping(value = "pharmacist/delete", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String deleteId() {
        Medicines medicines = medicinesRepository.getOne(id);
        medicines.setDeleted(Boolean.TRUE);
        medicinesRepository.save(medicines);
        message.setMessage("done");
        return message.toString();

    }

    /**
     * conserve id for delete and edit function
     *
     * @param id
     * @return
     */
    @PostMapping(value = "pharmacist/take/id", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String getId(@RequestBody String id) {
        this.id = Long.valueOf(id);
        message.setMessage("done");
        return message.toString();

    }

    /**
     * payed when patient take his medicines we will save this as payment
     * because he must pay medicines
     *
     * @param json
     * @return
     */
    @PostMapping(value = "pharmacist/payed", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String getpayed(@RequestBody String json) {
        double total = 0.0;

        try {
            //set medicines payed
            for (HasMedicines hasMedicines : hasMedicinesRepository.findBySecurtiyNumber(json)) {
                hasMedicines.setPayed(Boolean.TRUE);
                hasMedicinesRepository.save(hasMedicines);
                //totale
                if (hasMedicines.getIdMedecine().getAvailble()) {
                    total = total + hasMedicines.getIdMedecine().getPrice();
                }

            }
            System.out.println(total);
            payment = new Payment();
            payment.setIdUser(userRepository.findUserBySecurityNumber(json));
            payment.setCostMedicines(total);
            paymentRepository.save(payment);

            message.setMessage("done");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        return message.toString();

    }

    /**
     * change password for current user
     *
     * @param json
     * @return
     */
    @PostMapping(value = "pharmacist/change/password", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String changePassword(@RequestBody String json) throws IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            // get current user
            Users users = muds.getUser();

            // String currentpassword = node.get("currentPassword").asText();
            String newPassword = node.get("newPassword").asText();
            String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
            if (newPassword.matches(pattern)) {
                BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
                users.setPassword(bCryptPasswordEncoder.encode(newPassword));
                userRepository.save(users);
                message.setMessage("Please check your email");
            } else {
                message.setMessage("password must have Minimum eight characters,  at least one uppercase letter, one lowercase letter, one number and one special character");
            }

        } catch (JsonProcessingException e) {
            message.setMessage("can't change password ");
        }
        return message.toString();
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
