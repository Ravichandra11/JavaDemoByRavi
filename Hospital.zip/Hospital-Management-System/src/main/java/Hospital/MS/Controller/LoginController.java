package Hospital.MS.Controller;

import Hospital.MS.Model.Message;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class LoginController {

    @Autowired
    JavaMailSender emailSender;
    @Autowired
    MyUserDetailsServices muds;
    @Autowired
    Message message;
    @Autowired
    UserRepository userRepository;

    BCryptPasswordEncoder bCryptPasswordEncoder;

    /**
     *
     * @param model
     * @return Login Page
     */
    @RequestMapping("/")
    public String pageLogin(Model model) {
        return "login";
    }

    /**
     * display error message on bad validation
     *
     * @param model
     * @return error message in login page
     */
    @RequestMapping("/login_error")
    public String errorLogin(Model model) {
        model.addAttribute("message", "bad Credentials");
        return "login";
    }

    /**
     * send email with new password for user from controller
     *
     * @param email
     * @return String message ( Success or Fail)
     */
    @PostMapping(value = "/login/recover/password", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String recoverPassword(@RequestBody String email) {
        Users user = userRepository.findByEmail(email.trim());
        if (user != null) {
            bCryptPasswordEncoder = new BCryptPasswordEncoder();
            //create new password
            String generatedString = RandomStringUtils.randomAlphabetic(20);
            user.setPassword(bCryptPasswordEncoder.encode(generatedString));
            //save user with new password
            userRepository.save(user);
            // send mail
            sendMessage(user.getEmail(), generatedString, user.getFirstname(), user.getLastname());
            message.setMessage("check Your E-Mail");
        } else {
            message.setMessage("Invalid E-Mail");

        }

        return message.toString();
    }

    /**
     * send email to User
     *
     * @param email
     * @param password
     * @param firstname
     * @param lastname
     */
    private void sendMessage(String email, String password, String firstname, String lastname) {
        try {

            // send new password to  User  email
            SimpleMailMessage m = new SimpleMailMessage();
            m.setTo(email);
            m.setSubject("Hospital Management System " + " Recover PASSOWRD :");
            m.setText("Welcome in Hospital Management System Mr/Ms :" + firstname + " " + lastname + ""
                    + "\n" + "Your email is :" + email
                    + "\n" + "Your new Password is : " + password
                    + "\n" + "After access to your account is raccomended to change your password "
                    + "\n" + "Thank You ");
            // Send Message!
            this.emailSender.send(m);
        } catch (Exception e) {
            System.out.println("Error Message  : " + e.getMessage());
        }

    }

    /**
     * Error handler
     *
     * @param req
     * @param ex
     * @return Error page
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("exception", "Error message ");
        modelAndView.addObject("url", "Error message ");
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
