/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Controller;

import Hospital.MS.Model.HasAppointment;
import Hospital.MS.Model.HasSituations;
import Hospital.MS.Model.Message;
import Hospital.MS.Model.Messages;
import Hospital.MS.Model.MyCostumeUSER;
import Hospital.MS.Model.Patientdetails;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.HasAppointmentRepository;
import Hospital.MS.Repository.HasSituationRepository;
import Hospital.MS.Repository.MessagesRepository;
import Hospital.MS.Repository.PatientdetailsRepository;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author Chahir Chalouati
 */
@Controller
public class UserController {

    @Autowired
    MyUserDetailsServices muds;
    @Autowired
    HasAppointmentRepository hasAppointmentRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    Message message;

    @RequestMapping("/user")
    public String page(Model model, Principal principal) {
        if (userRepository.findByEmail(principal.getName()).getPatientdetails() == null) {
            return "completeProfile";
        } else {
            model.addAttribute("user", muds.getUser());
            return "user";
        }
    }

    @GetMapping(value = "user/get/state/profile")
    public void validProfile() {

    }

    /**
     * complete profile ---> will appear only if he's a new user
     *
     * @param json
     * @return
     */
    @Autowired
    PatientdetailsRepository patientdetailsRepository;

    @PostMapping(value = "/user/complete/profile")
    public String completeProfile(Patientdetails patientdetails) throws IOException {
        patientdetails.setIdUser(muds.getUser());
        patientdetailsRepository.save(patientdetails);
        return "redirect:/user";

    }

    /**
     * find all advices sent from doctors to this patient
     *
     * @param req
     * @param ex
     * @return
     */
    @Autowired
    HasSituationRepository hasSituationRepository;

    @GetMapping(value = "user/get/all/message/doctor", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<HasSituations> GetSituationPatient() {
        List<HasSituations> list = new LinkedList<>();

        hasSituationRepository.findAllByIdUSer(muds.getUser()
                .getIdUser()).stream().map((hasSituations) -> {
                    hasSituations.getIdDoctor().setPassword(" ");
                    return hasSituations;
                }).map((hasSituations) -> {
            hasSituations.getIdDoctor().setPassword(" ");
            return hasSituations;
        }).forEachOrdered((hasSituations) -> {
            list.add(hasSituations);
        });

        return list;
    }

    /**
     * get all doctor ---> load all doctors for patient page
     *
     * @return
     */
    @GetMapping(value = "user/get/all/doctor", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<MyCostumeUSER> getAllDoctor() {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Users> listdoctor = userRepository.findByAuthoritie("DOCTOR");
        listdoctor.stream().map((users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setEmail(users.getEmail());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    /**
     * get doctor by name
     *
     * @param name
     * @return
     */
    @GetMapping(value = "user/get/all/doctor/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<MyCostumeUSER> getDoctorByName(@PathVariable String name) {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        userRepository.findByAuthoritieByName("DOCTOR", name + "%").stream().map((users) -> {
            System.out.println(users.toString());
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setEmail(users.getEmail());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    @Autowired
    MessagesRepository messagesRepository;

    /**
     * load message ---> load all messages received from doctors to this patient
     *
     * @param email
     * @return
     */
    @GetMapping(value = "user/get/message/{email}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    ResponseEntity< List<Messages>> getMessage(@PathVariable String email) {
        List<Messages> listMessage = messagesRepository.findMessageByEmail(email, muds.getUser().getIdUser());

        return new ResponseEntity<>(listMessage, HttpStatus.ACCEPTED);

    }

    /**
     * messages that user see it
     *
     * @param json
     * @return
     */
    @PostMapping(value = "user/read/messages", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String messageSeeit(@RequestBody String json) {

        for (String id : json.split(",")) {

            Messages messages = messagesRepository.getOne(Long.valueOf(id));
            messages.setDateReceive(new Date());
            messages.setSeeIt(Boolean.TRUE);
            messagesRepository.save(messages);
        }
        message.setMessage("ok");
        return message.toString();
    }

    /**
     * save New message for doctor ---> message send to the doctor from patient
     *
     * @param json
     * @return
     */
    @PostMapping(value = "user/send/message/doctor", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String sendMessageDoctor(@RequestBody String json) throws IOException {

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            String email = node.get("email").asText();
            String m = node.get("message").asText();
            System.out.println(m);
            System.out.println(email);
            Messages messages = new Messages();
            messages.setContentMessage(m);
            messages.setIdSender(muds.getUser());
            messages.setIdReceiver(userRepository.findByEmail(email));
            messages.setSeeIt(Boolean.FALSE);
            messages.setDateReceive(new Date());
            messages.setDateSend(new Date());
            messagesRepository.save(messages);

            message.setMessage("done");

        } catch (JsonProcessingException e) {
            message.setMessage("sorry can't send message ");
        }

        return message.toString();

    }

    /**
     * create appointment ---> by user him self
     *
     * @param json
     * @return
     * @throws java.text.ParseException
     */
    @PostMapping(value = "user/create/appointment", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String patientCreateAppointment(@RequestBody String json) throws ParseException, IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            String dateapp = node.get("dateAppointment").asText();
            String timeapp = node.get("timeAppointment").asText();
            String email = node.get("doctorMail").asText();
            // save Appointment
            HasAppointment hasAppointment = new HasAppointment();
            hasAppointment = new HasAppointment();
            hasAppointment.setDateAppointment(new SimpleDateFormat("yyyy-MM-dd").parse(dateapp));
            hasAppointment.setDeleted(Boolean.FALSE);
            hasAppointment.setTimeAppointment(timeapp);
            hasAppointment.setIdDoctor(userRepository.findByEmail(email));
            hasAppointment.setIdPatient(muds.getUser());
            hasAppointment.setCostappointmnet(userRepository.findByEmail(email).getHasdepartment().getIdDepartment().getCostappointment());
            hasAppointmentRepository.save(hasAppointment);

            message.setMessage("New Appointment was saved with success");
            return message.toString();
        } catch (JsonProcessingException e) {
            message.setMessage("Sorry can't save this appointment ");
            return message.toString();
        }

    }

    /**
     * handling error for user page
     *
     * @param req
     * @param ex
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
