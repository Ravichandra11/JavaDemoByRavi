/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Controller;

import Hospital.MS.Model.Countries;
import Hospital.MS.Repository.CountriesRepository;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class CoronaController {

    @Autowired
    CountriesRepository countriesRepository;

    /**
     * corona
     *
     * @param country
     * @return
     */
    @GetMapping(value = "/corona/get/{countrie}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Countries> getCorona(@PathVariable("countrie") String country) {
        return countriesRepository.findAllLike(country + "%");
    }

    /**
     * corona
     *
     * @param country
     * @return
     */
//    @PostMapping(value = "/corona/get/save", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
//    public @ResponseBody
//    String save(@RequestBody String country) {
//        Countries c = new Countries();
//        c.setCountry(country);
//        countriesRepository.save(c);
//        return "ok";
//    }
    /**
     * get page corona
     *
     * @param model
     * @return
     */
    @GetMapping(value = "/corona")
    private String getPage(Model model) {
        return "corona";
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }

}
