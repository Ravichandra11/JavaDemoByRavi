package Hospital.MS.Controller;

import Hospital.MS.HandlerSocket.NotificationDispatcher;
import Hospital.MS.Model.Messages;
import Hospital.MS.Model.Situation_Patient;
import Hospital.MS.Model.chat;
import Hospital.MS.Repository.MessagesRepository;
import Hospital.MS.Repository.UserRepository;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.security.Principal;
import java.util.Date;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessagingException;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;
import org.springframework.stereotype.Controller;

@Controller
public class NotificationsController {

    final GsonBuilder builder = new GsonBuilder();
    final Gson gson = builder.create();
    @Autowired
    MessagesRepository messagesRepository;
    @Autowired
    private NotificationDispatcher dispatcher;
    @Autowired
    Situation_Patient situation_Patient;
    @Autowired
    UserRepository usersRepository;
    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationDispatcher.class);
    @Autowired
    SimpMessagingTemplate template;

    @MessageMapping("/start")
    public void start(StompHeaderAccessor stompHeaderAccessor, Principal principal) {
        dispatcher.setUser(principal.getName());
        dispatcher.dispatch();

    }

    @MessageMapping("/send")
    public void send(StompHeaderAccessor stompHeaderAccessor, Principal principal, chat m) {
        try {
            template.convertAndSendToUser(m.getTo(), "/notification/item", m.getMessage());

            Messages message = new Messages();
            message.setContentMessage(m.getMessage());
            message.setIdSender(usersRepository.findByEmail(principal.getName()));
            message.setIdReceiver(usersRepository.findByEmail(m.getTo()));
            message.setDateSend(new Date());
            message.setSeeIt(Boolean.FALSE);
            message.setDateReceive(new Date());
            messagesRepository.save(message);
            template.convertAndSendToUser(m.getTo(), "/messages/item", m);
        } catch (MessagingException e) {
            System.out.println(e.getMessage());
        }

    }

    @MessageMapping("/stop")
    public void stop(StompHeaderAccessor stompHeaderAccessor, Principal principal) {
        dispatcher.setUser(null);
//        dispatcher.remove(stompHeaderAccessor.getSessionId());
    }
}
