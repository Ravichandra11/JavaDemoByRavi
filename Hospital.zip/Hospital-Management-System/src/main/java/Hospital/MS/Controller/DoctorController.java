/*
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
 /*
    Created on : Mar 25, 2020, 3:21:22 PM
    Author     : chahir chalouati
 */
package Hospital.MS.Controller;

import Hospital.MS.Model.*;
import Hospital.MS.Model.HasAppoitnmentJSON;
import Hospital.MS.Model.HasMedicines;
import Hospital.MS.Model.HasOperation;
import Hospital.MS.Model.HasRadiology;
import Hospital.MS.Model.HasSituations;
import Hospital.MS.Model.Hasanalysis;
import Hospital.MS.Model.Hospitlizes;
import Hospital.MS.Model.Medicines;
import Hospital.MS.Model.Message;
import Hospital.MS.Model.MyCostumeUSER;
import Hospital.MS.Model.ResponseImage;
import Hospital.MS.Model.Users;
import Hospital.MS.Repository.AnalysisRepository;
import Hospital.MS.Repository.HasAnalysisRepository;
import Hospital.MS.Repository.HasAppointmentRepository;
import Hospital.MS.Repository.HasMedicinesRepository;
import Hospital.MS.Repository.HasOperationRepository;
import Hospital.MS.Repository.HasRadiologyRepository;
import Hospital.MS.Repository.HasSituationRepository;
import Hospital.MS.Repository.HospitlizesRepository;
import Hospital.MS.Repository.MedicinesRepository;
import Hospital.MS.Repository.MessagesRepository;
import Hospital.MS.Repository.TypeofsurgeryRepository;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Base64;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class DoctorController {

    /**
     * vars
     */
    private List<HasMedicines> ListhasMedicines = new LinkedList<>();
    private Date date = new Date();
    @Autowired
    CompareDate compareDate;
    @Autowired
    TypeofsurgeryRepository typeofsurgeryRepository;
    @Autowired
    ResponseImage responseImage;
    @Autowired
    HasAppoitnmentJSON hasAppoitnmentJSON;
    @Autowired
    MyUserDetailsServices muds;
    @Autowired
    HasAppointmentRepository hasAppointmentRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    Users users;
    @Autowired
    HasSituationRepository hasSituationRepository;
    @Autowired
    Message message;
    @Autowired
    HasAnalysisRepository hasAnalysisRepository;
    @Autowired
    AnalysisRepository analysisRepository;
    @Autowired
    HospitlizesRepository hospitlizesRepository;
    @Autowired
    MedicinesRepository medicinesRepository;
    @Autowired
    HasMedicinesRepository hasMedicinesRepository;
    @Autowired
    HasRadiologyRepository hasRadiologyRepository;
    @Autowired
    HasOperation hasOperation;
    @Autowired
    HasOperationRepository hasOperationRepository;
    BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

    /**
     * page doctor
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "/doctor", method = RequestMethod.GET)
    public String getDoctorPage(Model model) {
        model.addAttribute("doctor", muds.getUser());
        model.addAttribute("typeofsurgeryList", typeofsurgeryRepository.findAll());
        model.addAttribute("listAppointment", hasAppointmentRepository.findByDoctorAndCurDate(muds.getUser().getIdUser(), date));

        return "doctor";
    }

    /**
     * find in appointment
     *
     * @param name
     * @return
     */
    @PostMapping(value = "doctor/search/patient")
    public @ResponseBody
    List<HasAppoitnmentJSON> searchAppointment(@RequestBody String name) {
        List<HasAppoitnmentJSON> listHasAppointment = new LinkedList();
        hasAppointmentRepository.findbyLikefirstname(muds.getUser().getIdUser(),
                name + "%").stream().map((hasAppointment) -> new HasAppoitnmentJSON(hasAppointment.getDateAppointment(),
                hasAppointment.getIdPatient().getFirstname(), hasAppointment.getIdPatient().getLastname(),
                hasAppointment.getTimeAppointment())).forEachOrdered((hasAppJSON) -> {
            listHasAppointment.add(hasAppJSON);
        });
        return listHasAppointment;

    }

    ///---------------->>>>>>>>>>>>>>>>>>>>>>>>>>>----------------------///////////
    @Autowired
    MessagesRepository messagesRepository;

    /**
     * get all conversation for doctor
     *
     * @return
     */
    @GetMapping(value = "/doctor/get/all/messages", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Users> getAllmessages() {
        return messagesRepository.findDistinctSenderByIdReceiver(muds.getUser().getIdUser());
    }

    /**
     * get all messages from conversation
     *
     * @param email
     * @return
     */
    private String emailReserved = "";

    @GetMapping(value = "/doctor/get/all/messages/{email}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Messages> getAllmessagesbyEmailSender(@PathVariable("email") String email) {
        emailReserved = email;
        return messagesRepository.findMessageByEmail(email, muds.getUser().getIdUser());
    }

    /**
     * send message to receiver
     *
     * @param json
     * @return
     */
    @PostMapping(value = "/doctor/send/message", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Messages> sendMessage(@RequestBody String json) throws IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            String m = node.get("message").asText();
            // System.out.println(m);
            //System.out.println(emailReserved);
            Messages messages = new Messages();
            messages.setContentMessage(m);
            messages.setIdSender(muds.getUser());
            messages.setIdReceiver(userRepository.findByEmail(emailReserved));
            messages.setSeeIt(Boolean.FALSE);
            messages.setDateReceive(new Date());
            messages.setDateSend(new Date());
            messagesRepository.save(messages);

            message.setMessage("done");

        } catch (JsonProcessingException e) {
            message.setMessage("sorry can't send message ");
        }

        return messagesRepository.findMessageByEmail(emailReserved, muds.getUser().getIdUser());

    }

///---------------->>>>>>>>>>>>>>>>>>>>>>>>>>>----------------------///////////
    /**
     * find patient by name
     *
     * @param name
     * @return
     */
    @PostMapping(value = "doctor/getOne")
    public @ResponseBody
    MyCostumeUSER showPatient(@RequestBody String name) {
        this.users = userRepository.findUserBySecurityNumber(name);
        MyCostumeUSER mcuser = new MyCostumeUSER();
        if (users != null) {

            mcuser.setFirstname(users.getFirstname());
            mcuser.setLastname(users.getFirstname());
            mcuser.setWork(users.getPatientdetails().getWork());
            mcuser.setAge(users.getAge());
            mcuser.setSecurtiyNumber(users.getPatientdetails().getSecurtiyNumber());

            return mcuser;
        } else {
            return new MyCostumeUSER();
        }

    }

    /**
     * save situation for patient
     *
     * @param situation
     * @return
     */
    @PostMapping(value = "doctor/save/situation")
    public @ResponseBody
    String saveSituation(@RequestBody String situation) {
        try {
            HasSituations hasSituations = new HasSituations();
            hasSituations.setDateRegsiterSituation(date);
            hasSituations.setIdDoctor(muds.getUser());
            hasSituations.setIdPatient(this.users);
            hasSituations.setDeleted(Boolean.FALSE);
            hasSituations.setSituation(situation);
            hasSituationRepository.save(hasSituations);
            message.setMessage("Saved");
        } catch (Exception e) {
            message.setMessage("can't save this situation try again");

        }

        return message.toString();

    }

    /**
     * make request analysis
     *
     * @return
     */
    @PostMapping(value = "doctor/confirm/analysis")
    public @ResponseBody
    String confirmAnalysis() {
        try {

            Hasanalysis hasanalysis = new Hasanalysis();
            hasanalysis.setDateRequest(date);
            hasanalysis.setIdUser(this.users);
            hasanalysis.setIdDoctor(muds.getUser());
            hasanalysis.setChecked(Boolean.FALSE);
            hasanalysis.setDeleted(Boolean.FALSE);
            hasAnalysisRepository.save(hasanalysis);
            message.setMessage("Saved");
        } catch (Exception e) {
            message.setMessage("can't make request analysis try again");

        }

        return message.toString();

    }

    /**
     * get analysis for specific patient
     *
     * @param securityNumber
     * @return
     */
    @PostMapping(value = "doctor/get/analysis/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Analysis> getpatientAnalysis(@RequestBody String securityNumber) {

        List<Hasanalysis> listHasAnalysis = hasAnalysisRepository.findAllAnalysisByPatient(securityNumber, muds.getUser().getIdUser());
        List<Analysis> listAnalysis = new LinkedList<>();
        listHasAnalysis.stream().map((listHasAnalysi) -> {
            Analysis analysis = new Analysis();
            analysis = listHasAnalysi.getIdAnalyze();
            return analysis;
        }).forEachOrdered((analysis) -> {
            listAnalysis.add(analysis);
        });
        return listAnalysis;
    }

    /**
     * make checked analysis
     *
     * @param id
     * @return
     */
    @PostMapping(value = "doctor/confirm/check/analysis", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String getAnalysis(@RequestBody String id) {

        Hasanalysis hasanalysis = hasAnalysisRepository.UpdateAnalysis(Long.valueOf(id));
        hasanalysis.setDeleted(Boolean.FALSE);
        hasanalysis.setChecked(Boolean.TRUE);
        hasAnalysisRepository.save(hasanalysis);
        message.setMessage("deleted");

        return message.toString();

    }

    /**
     * hospitalize patient
     *
     * @param json
     * @return
     */
    @PostMapping(value = "doctor/hospitalize/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String hospitalizePatient(@RequestBody String json) throws IOException {

        ObjectMapper mapper = new ObjectMapper();
        JsonNode node;
        try {

            node = mapper.readTree(json);
            Hospitlizes hospitlizes = mapper.convertValue(node.get("Hospitlizes"), Hospitlizes.class);

            if (compareDate.compare(hospitlizes.getDateHospitlizes(), date) == 1) {
                //save hospitlyze
                if (compareDate.compare(hospitlizes.getDateRecover(), hospitlizes.getDateHospitlizes()) == 1) {
                    hospitlizes.setIdPatient(this.users);
                    hospitlizes.setIdDoctor(muds.getUser());
                    hospitlizes.setDeleted(Boolean.FALSE);
                    hospitlizesRepository.save(hospitlizes);
                    hospitlizes.setDeleted(Boolean.FALSE);
                    message.setMessage("Done");
                } else {
                    message.setMessage("can't save because estimated date for recover is before date hospitlyse");
                }
            } else {
                message.setMessage("can't save because date hospitlyse is before current date ");

            }

        } catch (JsonProcessingException ex) {
            System.out.println(ex.getMessage());
        }

        return message.toString();

    }

    /**
     * load all medicines
     *
     * @return
     */
    @GetMapping("doctor/get/all/medecines")
    public @ResponseBody
    List<Medicines> getAllMedecines() {
        return medicinesRepository.findAllDISTINCT();

    }

    /**
     * add medicines one by one
     *
     * @param json
     * @return
     */
    @PostMapping(value = "doctor/add/medicines/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String addMedicines(@RequestBody String json) throws IOException {

        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            String idmedicines = node.get("idMedicines").asText();
            String howUseIt = node.get("howUseIt").asText();
            Medicines medicines = medicinesRepository.getOne(Long.valueOf(idmedicines));

            HasMedicines hasMedicines = new HasMedicines();
            hasMedicines.setIdUser(users);
            hasMedicines.setIdMedecine(medicines);
            hasMedicines.setDateAdded(date);
            hasMedicines.setDeleted(Boolean.FALSE);
            hasMedicines.setPayed(Boolean.FALSE);
            hasMedicines.setHowUseIt(howUseIt);
            ListhasMedicines.add(hasMedicines);
            message.setMessage("done");
        } catch (JsonProcessingException | NumberFormatException e) {
            message.setMessage("can't add this medicines try again ");
        }

        return message.toString();
    }

    /**
     * save all medicines for patient
     *
     * @return
     */
    @PostMapping("doctor/save/all/medicines/patient")
    public @ResponseBody
    String saveAllMedicines() {

        try {
            hasMedicinesRepository.saveAll(ListhasMedicines);
            ListhasMedicines.clear();
            message.setMessage("done");
        } catch (Exception e) {
            message.setMessage("can't save ");
        }
        return message.toString();
    }

    /**
     * request radiology for patient
     *
     * @param typeRadiology
     * @return
     */
    @PostMapping("doctor/request/radiology/patient")
    public @ResponseBody
    String requestRadiology(@RequestBody String typeRadiology) {
        try {
            HasRadiology hasRadiology = new HasRadiology();
            hasRadiology.setChecked(Boolean.FALSE);
            hasRadiology.setIdUser(users);
            hasRadiology.setTypeOfRadiology(typeRadiology);
            hasRadiology.setDeleted(Boolean.FALSE);
            hasRadiologyRepository.save(hasRadiology);
            message.setMessage("done");
        } catch (Exception e) {
            message.setMessage("can't save ");
        }
        return message.toString();
    }

    /**
     * get radiology for patient images base64
     *
     * @param securityNumber
     * @return
     */
    @PostMapping("doctor/get/radiology/patient")
    public @ResponseBody
    List<ResponseImage> getallHasRadiology(@RequestBody String securityNumber) {
        //  System.out.println(securityNumber);
        List<ResponseImage> listImages = new LinkedList<>();
        List<HasRadiology> listhasHasRadiologys
                = hasRadiologyRepository.
                        findHasradiologyForDoctor(securityNumber);
        for (HasRadiology listhasHasRadiology : listhasHasRadiologys) {
            if (listhasHasRadiology.getIdRadiologies() != null) {
                byte image[] = listhasHasRadiology.getIdRadiologies().getRadiology();
                String base64File = Base64.getEncoder().encodeToString(image);
                responseImage = new ResponseImage();
                responseImage.setNameImage(listhasHasRadiology.getIdUser().getFirstname() + " " + listhasHasRadiology.getIdUser().getLastname());
                responseImage.setImageBase64(base64File);
                responseImage.setIdImage(String.valueOf(listhasHasRadiology.getIdHasRadiology()));
            }
            listImages.add(responseImage);
            System.out.println(responseImage.getImageBase64());
        }

        // System.out.println(listImages.size());
        return listImages;

    }

    /**
     * check radiology
     *
     * @param id
     * @return
     */
    @PostMapping(value = "doctor/checked/radiology", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String checked(@RequestBody String id) {
        try {
            HasRadiology hasRadiology = hasRadiologyRepository.getOne(Long.valueOf(id));
            hasRadiology.setChecked(Boolean.TRUE);
            hasRadiologyRepository.save(hasRadiology);
            message.setMessage("done");
        } catch (NumberFormatException e) {
            System.out.println(e.getMessage());
        }
        return message.toString();

    }

    /**
     * save operation for patient
     *
     * @param json
     * @return
     */
    @PostMapping(value = "doctor/save/operation", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String saveOperation(@RequestBody String json) throws IOException {
        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            String dateOperation = node.get("dateOperation").asText();
            String timeOperation = node.get("timeoperation").asText();
            String securityNumber = node.get("securityNumber").asText();
            String idSurgery = node.get("idSurgery").asText();
            String reasonForOperation = node.get("reasonForOperation").asText();

            Typeofsurgery typeofsurgery = typeofsurgeryRepository.getOne(Long.valueOf(idSurgery));

            HasOperation hasOperation = new HasOperation();
            hasOperation.setDateOperaton(new SimpleDateFormat("yyyy-MM-dd").parse(dateOperation));

            if (compareDate.compare(hasOperation.getDateOperaton(), date) == 1) {

                hasOperation.setTimeOperation(timeOperation);
                hasOperation.setReasonForOperation(reasonForOperation);
                hasOperation.setIdUser(userRepository.findUserBySecurityNumber(securityNumber));
                hasOperation.setIdDoctor(muds.getUser());
                hasOperation.setDeleted(Boolean.FALSE);
                hasOperation.setPayed(Boolean.FALSE);
                hasOperation.setIdSurgery(typeofsurgery);
                hasOperationRepository.save(hasOperation);

                message.setMessage("done");
            } else {
                message.setMessage("can't save operation because it's before current Date ");

            }

        } catch (JsonProcessingException | ParseException e) {
            System.out.println(e.getMessage());
            message.setMessage("can't save this operation");
        }
        return message.toString();
    }

    /**
     * change password for current user
     *
     * @param json
     * @return
     */
    @PostMapping(value = "doctor/change/password", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String changePassword(@RequestBody String json) throws IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            // get current user
            Users users = muds.getUser();

            // String currentpassword = node.get("currentPassword").asText();
            String newPassword = node.get("newPassword").asText();
            String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
            if (newPassword.matches(pattern)) {
                bCryptPasswordEncoder = new BCryptPasswordEncoder();
                users.setPassword(bCryptPasswordEncoder.encode(newPassword));
                userRepository.save(users);
                message.setMessage("Please check your email");
            } else {
                message.setMessage("password must have Minimum eight characters,  at least one uppercase letter, one lowercase letter, one number and one special character");
            }

        } catch (JsonProcessingException e) {
            message.setMessage("can't change password ");
        }
        return message.toString();
    }

    /**
     * search for medicines
     *
     * @param medicines
     * @return
     */
    @PostMapping(value = "doctor/find/medicines", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Medicines> findMedicines(@RequestBody String medicines) {
        List<Medicines> listMedicines = medicinesRepository.findByNameMedecineLike(medicines.trim() + "%");
        return listMedicines;

    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }
}
