/*
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
 */
/*
   Created on : Mar 25, 2020, 3:21:22 PM
   Author     : chahir chalouati
*/
package Hospital.MS.Controller;

import Hospital.MS.Model.*;
import Hospital.MS.Repository.AddressesRepository;
import Hospital.MS.Repository.AnalysisRepository;
import Hospital.MS.Repository.AuthoritiesRepository;
import Hospital.MS.Repository.HasAnalysisRepository;
import Hospital.MS.Repository.HasAppointmentRepository;
import Hospital.MS.Repository.HasMedicinesRepository;
import Hospital.MS.Repository.HasOperationRepository;
import Hospital.MS.Repository.HasRadiologyRepository;
import Hospital.MS.Repository.HospitlizesRepository;
import Hospital.MS.Repository.PatientdetailsRepository;
import Hospital.MS.Repository.RadiologiesRepository;
import Hospital.MS.Repository.UserRepository;
import Hospital.MS.Services.MyUserDetailsServices;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.itextpdf.html2pdf.HtmlConverter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.http.HttpRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.CharEncoding;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;

/**
 *
 * @author chahir chalouati
 */
@Controller
public class NurseController {

    @Autowired
    ViewResolver viewResolver;
    String htmlMsg;
    @Autowired
    BillPatient billPatient;
    Long id;
    @Autowired
    Message mymessage;
    @Autowired
    Users patient;
    @Autowired
    UserRepository userRepository;
    @Autowired
    Addresses addresses;
    @Autowired
    AddressesRepository addressesRepository;
    @Autowired
    AuthoritiesRepository authoritiesRepository;
    BCryptPasswordEncoder bCryptPasswordEncoder;
    @Autowired
    HasRadiologyRepository hasRadiologyRepository;
    @Autowired
    HasAnalysisRepository hasAnalysisRepository;
    @Autowired
    JavaMailSender emailSender;
    @Autowired
    Patientdetails patientdetails;
    @Autowired
    PatientdetailsRepository patientdetailsRepository;
    @Autowired
    HasAppointmentRepository hasAppointmentRepository;
    @Autowired
    RadiologiesRepository radiologiesRepository;
    @Autowired
    AnalysisRepository analysisRepository;
    @Autowired
    HasMedicinesRepository hasMedicinesRepository;
    @Autowired
    HospitlizesRepository hospitlizesRepository;
    @Autowired
    MyUserDetailsServices muds;
    HasAppointment hasAppointment;
    @Autowired
    HasOperationRepository hasOperationRepository;
    Date date = new Date();

    private final List<String> bloodList = Arrays
            .asList(new String[] { "A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-" });

    @RequestMapping("/nurse")
    public String pageNurse(Model model) {
        model.addAttribute("nurse", muds.getUser());
        model.addAttribute("bloodList", bloodList);
        return "nurse";
    }

    /**
     * get bill pages on request
     *
     * @param model
     * @param req
     * @return
     * @throws Exception
     */
    @RequestMapping("/bill")
    public String pageBill(Model model, HttpServletRequest req) throws Exception {
        model.addAttribute("billPatient", billPatient);
        // getting html response before send it
        View resolvedView = this.viewResolver.resolveViewName("bill", Locale.US);
        MockHttpServletResponse mockResp = new MockHttpServletResponse();
        resolvedView.render(model.asMap(), req, mockResp);
        // convert content to string (html)
        htmlMsg = mockResp.getContentAsString();
        System.out.println(htmlMsg);
        mymessage.setMessage("ready");
        return "bill";
    }

    @GetMapping(value = "nurse/getSituationPatient")
    private String getSituationPatient(Model model) {
        return "situation_patient";
    }

    /**
     * load all request radiology
     *
     * @return
     */
    @GetMapping(value = "nurse/get/all/hasRadiology", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> getRadiologyRequest() {

        List<HasRadiology> listHasRadiologys = hasRadiologyRepository.findNullRadiology();
        List<MyCostumeUSER> listCostumeUSER = new LinkedList();

        listHasRadiologys.stream().map((listHasRadiology) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(listHasRadiology.getIdUser().getFirstname());
            myCostumeUSER.setLastname(listHasRadiology.getIdUser().getLastname());
            myCostumeUSER.setTypeOfRadiology(listHasRadiology.getTypeOfRadiology());
            myCostumeUSER.setSecurtiyNumber(listHasRadiology.getIdUser().getPatientdetails().getSecurtiyNumber());
            myCostumeUSER.setBloodType(listHasRadiology.getIdUser().getPatientdetails().getBloodType());
            myCostumeUSER.setEmail(String.valueOf(listHasRadiology.getIdHasRadiology()));
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;

    }

    /**
     * find all recovered patient today
     *
     * @return
     */
    @GetMapping(value = "nurse/recover/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> getRecovers() {
        MyCostumeUSER user;
        List<MyCostumeUSER> myListUsers = new LinkedList();
        for (Hospitlizes hospitlizes : hospitlizesRepository.findByRecoverToDay()) {
            user = new MyCostumeUSER();
            user.setFirstname(hospitlizes.getIdPatient().getFirstname());
            user.setLastname(hospitlizes.getIdPatient().getLastname());
            user.setEmail(hospitlizes.getIdPatient().getEmail());
            myListUsers.add(user);
        }
        return myListUsers;

    }

    /**
     * load all request analysis
     *
     * @return List Of CostumUsers
     */
    @GetMapping(value = "nurse/get/all/hasAnalysis", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> getAnalysisRequest() {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Hasanalysis> listhaHasanalysises = hasAnalysisRepository.findAllWhereIdAnalysisNUll();
        listhaHasanalysises.stream().map((listhaHasanalysise) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(listhaHasanalysise.getIdUser().getFirstname());
            myCostumeUSER.setLastname(listhaHasanalysise.getIdUser().getLastname());
            myCostumeUSER.setAnalysis(listhaHasanalysise.getIdhasAnalysis());
            myCostumeUSER.setSecurtiyNumber(listhaHasanalysise.getIdUser().getPatientdetails().getSecurtiyNumber());
            myCostumeUSER.setBloodType(listhaHasanalysise.getIdUser().getPatientdetails().getBloodType());
            myCostumeUSER.setEmail(String.valueOf(listhaHasanalysise.getIdhasAnalysis()));
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    /**
     * search for request analysis
     *
     * @param search
     * @return listCostumeUSER
     */
    @PostMapping(value = "nurse/find/req/analysis", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> serachReqAnalysis(@RequestBody String search) {

        List<Hasanalysis> listhaHasanalysises = hasAnalysisRepository
                .findAllWhereIdAnalysisNUllAndLikeFirstname(search + "%");
        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        listhaHasanalysises.stream().map((listhaHasanalysise) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(listhaHasanalysise.getIdUser().getFirstname());
            myCostumeUSER.setLastname(listhaHasanalysise.getIdUser().getLastname());
            myCostumeUSER.setAnalysis(listhaHasanalysise.getIdhasAnalysis());
            myCostumeUSER.setSecurtiyNumber(listhaHasanalysise.getIdUser().getPatientdetails().getSecurtiyNumber());
            myCostumeUSER.setBloodType(listhaHasanalysise.getIdUser().getPatientdetails().getBloodType());
            myCostumeUSER.setEmail(String.valueOf(listhaHasanalysise.getIdhasAnalysis()));
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;

    }

    /**
     * search for req radiology
     *
     * @param search
     * @return
     */
    @PostMapping(value = "nurse/find/req/radiology", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> serachReqRadiology(@RequestBody String search) {

        List<HasRadiology> listHasRadiologys = hasRadiologyRepository.findNullRadiologyByName(search + "%");
        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        listHasRadiologys.stream().map((listHasRadiology) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(listHasRadiology.getIdUser().getFirstname());
            myCostumeUSER.setLastname(listHasRadiology.getIdUser().getLastname());
            myCostumeUSER.setTypeOfRadiology(listHasRadiology.getTypeOfRadiology());
            myCostumeUSER.setSecurtiyNumber(listHasRadiology.getIdUser().getPatientdetails().getSecurtiyNumber());
            myCostumeUSER.setBloodType(listHasRadiology.getIdUser().getPatientdetails().getBloodType());
            myCostumeUSER.setEmail(String.valueOf(listHasRadiology.getIdHasRadiology()));
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    /**
     * get all patient
     *
     * @return
     */
    @GetMapping(value = "nurse/get/all/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> getAllPatient() {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Users> listPatient = userRepository.findByAuthoritie("USER");
        System.out.println(listPatient.size());
        listPatient.stream().map((users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setSecurtiyNumber(users.getPatientdetails().getSecurtiyNumber());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });
        return listCostumeUSER;
    }

    /**
     * get all doctor
     *
     * @return
     */
    @GetMapping(value = "nurse/get/all/doctor", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> getAllDoctor() {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Users> listdoctor = userRepository.findByAuthoritie("DOCTOR");
        listdoctor.stream().map((users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setEmail(users.getEmail());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    /**
     * search patient
     *
     * @param search
     * @return
     */
    @GetMapping(value = "nurse/search/patient/appointment/{search}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> searchPatient(@PathVariable("search") String search) {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Users> listPatient = userRepository.findByFirstnameLike(search + "%", "USER");

        listPatient.stream().map((users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setSecurtiyNumber(users.getPatientdetails().getSecurtiyNumber());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });
        return listCostumeUSER;
    }

    /**
     * search doctor
     *
     * @param search
     * @return
     */
    @GetMapping(value = "nurse/search/doctor/appointments/{search}", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody List<MyCostumeUSER> searchDoctor(@PathVariable("search") String search) {

        List<MyCostumeUSER> listCostumeUSER = new LinkedList();
        List<Users> listdoctor = userRepository.findByFirstnameLike(search + "%", "DOCTOR");
        listdoctor.stream().map((users) -> {
            MyCostumeUSER myCostumeUSER = new MyCostumeUSER();
            myCostumeUSER.setFirstname(users.getFirstname());
            myCostumeUSER.setLastname(users.getLastname());
            myCostumeUSER.setEmail(users.getEmail());
            return myCostumeUSER;
        }).forEachOrdered((myCostumeUSER) -> {
            listCostumeUSER.add(myCostumeUSER);
        });

        return listCostumeUSER;
    }

    /**
     * register patient
     *
     * @param json
     * @return
     */
    @PostMapping(value = "nusre/save/new/patient", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String registerPatient(@RequestBody String json) throws IOException {
        try {
            String generatedString = RandomStringUtils.randomAlphabetic(20);

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);

            Users newPatientNurse = mapper.convertValue(node.get("users"), Users.class);
            Addresses newPatientNurseaddresses = mapper.convertValue(node.get("addresses"), Addresses.class);
            Patientdetails newPatientNursepatientdetails = mapper.convertValue(node.get("patientDetails"),
                    Patientdetails.class);

            if (userRepository.findUserBySecurityNumber(newPatientNursepatientdetails.getSecurtiyNumber()) != null
                    || userRepository.findByEmail(newPatientNurse.getEmail()) != null) {
                mymessage.setMessage(" Can't save this Patient is  Already Exist");
            } else {

                bCryptPasswordEncoder = new BCryptPasswordEncoder();
                // for test Purpose i use my costum password
                // ---> Use generatedString to generate Random password for new patient instead of "23051988"
                newPatientNurse.setPassword(bCryptPasswordEncoder.encode("23051988"));
                newPatientNurse.setDeleted(Boolean.FALSE);
                newPatientNurse.setIdAuthoritie(authoritiesRepository.findByAuthoritie("USER"));
                userRepository.save(newPatientNurse);
                newPatientNurseaddresses.setIdUser(newPatientNurse);
                newPatientNurseaddresses.setDeleted(Boolean.FALSE);
                addressesRepository.save(newPatientNurseaddresses);
                newPatientNursepatientdetails.setIdUser(newPatientNurse);
                patientdetailsRepository.save(newPatientNursepatientdetails);
                // send email for new patient with his generated password
                sendMessage(newPatientNurse.getEmail().trim(), generatedString.trim(),
                        newPatientNurse.getFirstname().trim(), newPatientNurse.getLastname().trim());
                mymessage.setMessage("New Patient was saved with success");

            }

        } catch (IllegalArgumentException | JsonProcessingException e) {
            mymessage.setMessage("can't save this patient ");
        }
        return mymessage.toString();
    }

    /**
     * add radiology
     *
     * @param file
     * @return
     * @throws java.io.IOException
     */
    @PostMapping(value = "nurse/add/new/radiology", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String addRadiology(@RequestParam("file") MultipartFile file) throws IOException {
        HasRadiology hasRadiology = hasRadiologyRepository.getOne(id);
        byte image[] = file.getBytes();

        Radiologies radiologies = new Radiologies();
        radiologies.setRadiology(image);
        radiologies.setDeleted(Boolean.FALSE);

        System.out.println(radiologies.getRadiology().length);
        radiologies.setCostRadiology(muds.getUser().getHasdepartment().getIdDepartment().getCostAnalysis());

        radiologiesRepository.save(radiologies);

        hasRadiology.setIdRadiologies(radiologies);
        hasRadiologyRepository.save(hasRadiology);

        mymessage.setMessage("New Radiology was saved with success");
        return mymessage.toString();
    }

    /**
     * save analysis
     *
     * @param json
     * @return
     */
    @PostMapping(value = "nurse/save/new/analysis", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String saveAnalysis(@RequestBody String json) throws IOException {
        try {

            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            Analysis analysis = mapper.convertValue(node.get("Analysis"), Analysis.class);
            analysis.setDeleted(Boolean.FALSE);
            analysis.setDateAnalaysis(date);
            analysisRepository.save(analysis);
            Hasanalysis hasanalysis = hasAnalysisRepository.getOne(id);
            hasanalysis.setIdAnalyze(analysis);
            hasanalysis.setDateresponse(date);
            hasAnalysisRepository.save(hasanalysis);

            mymessage.setMessage("New Analysis was saved with success");
        } catch (JsonProcessingException | IllegalArgumentException e) {
            mymessage.setMessage("can't save this analysis");
        }

        return mymessage.toString();
    }

    /**
     * save payment
     *
     * @return
     */
    @PostMapping(value = "nurse/save/new/payment", produces = MediaType.APPLICATION_JSON_VALUE)
    public String savePayment() {
        return "";
    }

    /**
     * save payment
     *
     * @param json
     * @return
     */
    @PostMapping(value = "nurse/save/new/appointment", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String saveNewAppointments(@RequestBody String json) throws IOException {

        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            String dateapp = node.get("dateAppointment").asText();
            String timeapp = node.get("timeAppointment").asText();
            String security = node.get("patientNumber").asText();
            String email = node.get("doctorMail").asText();
            // save Appointment
            hasAppointment = new HasAppointment();
            hasAppointment.setDateAppointment(new SimpleDateFormat("yyyy-MM-dd").parse(dateapp));
            hasAppointment.setDeleted(Boolean.FALSE);
            hasAppointment.setTimeAppointment(timeapp);
            hasAppointment.setIdDoctor(userRepository.findByEmail(email));
            hasAppointment.setIdPatient(userRepository.findUserBySecurityNumber(security));
            hasAppointment.setCostappointmnet(
                    userRepository.findByEmail(email).getHasdepartment().getIdDepartment().getCostappointment());
            hasAppointmentRepository.save(hasAppointment);

            mymessage.setMessage("New Appointment was saved with success");
        } catch (JsonProcessingException e) {
            mymessage.setMessage(e.getMessage());
        } catch (ParseException ex) {
            Logger.getLogger(NurseController.class.getName()).log(Level.SEVERE, null, ex);
        }

        return mymessage.toString();
    }

    /**
     * conserve id Object HasAnalusis or HasRadiology
     */
    @PostMapping("nurse/get/id")
    public void getId(@RequestBody String id) {
        this.id = Long.valueOf(id);

    }

    /**
     * send email to new patient
     *
     * @param email
     * @param password
     * @param firstname
     * @param lastname
     */
    private void sendMessage(String email, String password, String firstname, String lastname) {

        // sending password ----> new password to new patient email
        SimpleMailMessage m = new SimpleMailMessage();
        m.setTo(email);
        m.setSubject("Hospital Management System " + "PASSOWRD :");
        m.setText("Welcome in Hospital Management System Mr/Ms :" + firstname + " " + lastname + "" + "\n"
                + "Your email is :" + email + "\n" + "Your Password is : " + password + "\n"
                + " Remember it's recommended to change your password after your first access " + "\n" + "Thank You ");
        // Send Message!
        this.emailSender.send(m);

    }

    /**
     * change password for current user
     *
     * @param json
     * @return
     */
    @PostMapping(value = "nurse/change/password", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String changePassword(@RequestBody String json) throws IOException {
        try {
            ObjectMapper mapper = new ObjectMapper();
            JsonNode node = mapper.readTree(json);
            // get current user
            Users users = muds.getUser();
            String newPassword = node.get("newPassword").asText();
            String pattern = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}";
            if (newPassword.matches(pattern)) {
                bCryptPasswordEncoder = new BCryptPasswordEncoder();
                users.setPassword(bCryptPasswordEncoder.encode(newPassword));
                userRepository.save(users);
                mymessage.setMessage("Please check your email");
            } else {
                mymessage.setMessage(
                        "password must have Minimum eight characters,  at least one uppercase letter, one lowercase letter, one number and one special character");
            }

        } catch (JsonProcessingException e) {
            mymessage.setMessage("can't change password ");
        }
        return mymessage.toString();
    }

    /**
     * generate PDF bill and send it to email of patient
     *
     *
     * @param email
     * @return
     */
    @PostMapping(value = "nurse/prepare/recover/bill")
    public @ResponseBody String getUserBill(@RequestBody String email) {

        billPatient = new BillPatient();
        try {

            // find users
            Users user = userRepository.findByEmail(email);

            billPatient = new BillPatient();
            // prepare object for bill
            billPatient.setFirstname(user.getFirstname());

            billPatient.setLastname(user.getLastname());
            billPatient.setEmail(user.getEmail());

            billPatient.setSecurityNumber(user.getPatientdetails().getSecurtiyNumber());

            billPatient.setBillnumber(RandomStringUtils.randomAlphanumeric(20));
            billPatient.setAge(user.getAge());
            billPatient.setModile(user.getPatientdetails().getMobile());
            billPatient.setAddress(user.getAddresses().getCity() + " " + user.getAddresses().getProvince() + " "
                    + user.getAddresses().getStreet() + " " + user.getAddresses().getBuilding() + " "
                    + user.getAddresses().getHouse());
            billPatient.setCuraDate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));

            billPatient.setTotalDayResidence(
                    hospitlizesRepository.findRecentDateRecover(user.getIdUser()).getDayResidence());

            billPatient.setDateRecover(hospitlizesRepository.findRecentDateRecover(user.getIdUser()).getDateRecover());

            billPatient.setDateHospitlyze(
                    hospitlizesRepository.findRecentDateRecover(user.getIdUser()).getDateHospitlizes());

            billPatient.setTotalCostDayResidence(
                    hospitlizesRepository.findRecentDateRecover(user.getIdUser()).getDayResidence()
                            * hospitlizesRepository.findRecentDateRecover(user.getIdUser()).getIdDoctor()
                                    .getHasdepartment().getIdDepartment().getCostHospitlyze());

            billPatient.setTotalCostAppointment(
                    hasAppointmentRepository.findByIdUser(user.getIdUser()).getCostappointmnet());
            // find medicines by user
            billPatient.setListMedicines(
                    hasMedicinesRepository.findAllMedicinesByIdUser(user.getPatientdetails().getSecurtiyNumber()));
            // find hasanalysis patient
            billPatient.setListHasAnalysis(hasAnalysisRepository.findByAnalysisPaymentPatient(user.getIdUser()));
            // find operation for this patient and there cost
            billPatient.setListoperation(hasOperationRepository.findByIdUser(user.getIdUser()));
            // find radiologies
            billPatient.setListHasradiology(hasRadiologyRepository.findAllPaymentByUser(user.getIdUser()));

            mymessage.setMessage("done");
        } catch (NullPointerException e) {
            mymessage.setMessage("Try Later ");
        }

        return mymessage.toString();

    }

    /**
     * get bill HTML ---> using HTML as text and the convert it to HTML tags --->
     * create bill in HTML
     *
     * @param model
     * @return
     */
    @RequestMapping(value = "nurse/bill")
    public String getBill(Model model) {

        return "redirect:/bill";
    }

    /**
     * nurse confirm bill --> if all information are correct
     *
     * @return
     * @throws MessagingException
     * @throws Exception
     */
    @PostMapping(value = "nurse/confirm/invoice", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String send() throws MessagingException, Exception {

        // prepare mime message
        MimeMessage mimeMessage = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
        // mimeMessage.setContent(htmlMsg, "text/html");

        helper.setText(htmlMsg, true); // add html attachment second way
        helper.setTo("chehhhir@gmail.com");
        helper.setSubject("This is the test message for testing Hospital MS By Chahir Chalouati");
        helper.setFrom(MyConstants.getMY_EMAIL());
        File f = new File("pdf/bill.pdf");
        HtmlConverter.convertToPdf(htmlMsg, new FileOutputStream(f));

        helper.addAttachment("bill.pdf", f);// create pdf bill

        emailSender.send(mimeMessage);// send email
        f.delete(); // delete file pdf
        billPatient.getListHasAnalysis().stream().map((listHasAnalysi) -> {
            listHasAnalysi.setChecked(Boolean.TRUE);
            return listHasAnalysi;
        }).map((listHasAnalysi) -> {
            listHasAnalysi.setDeleted(Boolean.TRUE);
            return listHasAnalysi;
        }).forEachOrdered((listHasAnalysi) -> {
            hasAnalysisRepository.save(listHasAnalysi);
        });

        billPatient.getListHasradiology().stream().map((listHasRadiology) -> {
            listHasRadiology.setChecked(Boolean.TRUE);
            return listHasRadiology;
        }).map((listHasRadiology) -> {
            listHasRadiology.setDeleted(Boolean.TRUE);
            return listHasRadiology;
        }).forEachOrdered((listHasRadiology) -> {
            hasRadiologyRepository.save(listHasRadiology);
        });
        billPatient.getListoperation().stream().map((hasOperation) -> {
            hasOperation.setDeleted(Boolean.TRUE);
            return hasOperation;
        }).map((hasOperation) -> {
            hasOperation.setPayed(Boolean.TRUE);
            return hasOperation;
        }).forEachOrdered((hasOperation) -> {
            hasOperationRepository.save(hasOperation);
        });

        hospitlizesRepository.findByRecoverToDayBYPATIENT(billPatient.getEmail()).stream().map((hospitlizes) -> {
            hospitlizes.setDeleted(Boolean.TRUE);
            return hospitlizes;
        }).forEachOrdered((hospitlizes) -> {
            hospitlizesRepository.save(hospitlizes);
        });

        mymessage.setMessage("Done");
        return mymessage.toString();

    }

    /**
     * nurse reject the bill ---> if error occurred while compiling
     *
     * @return
     */
    @PostMapping(value = "nurse/cancel/invoice", produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody String cancelBill() {

        billPatient = new BillPatient();
        htmlMsg = "";
        mymessage.setMessage("Canceled");
        return mymessage.toString();

    }

    /**
     * getHospitlizes
     *
     * @return
     */
    @GetMapping(value = "/nurse/patient/hospitlyzed", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Hospitlizes>> getHospitlizes() {
        return new ResponseEntity<>(hospitlizesRepository.findAllHospitlized(), HttpStatus.OK);
    }

    /**
     * getOneHospitlizes
     *
     * @return
     */
    @GetMapping(value = "/nurse/patient/hospitlyzed/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Optional<Hospitlizes>> getOneHospitlizes(@PathVariable Long id) {
        return new ResponseEntity<>(hospitlizesRepository.findByIdHospitlize(id), HttpStatus.OK);
    }

    /**
     * getOneByEmailHospitlizes
     *
     * @param mail
     * @return
     */
    @GetMapping(value = "/nurse/patient/hospitlyzed/mail/{mail}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Hospitlizes>> getOneByMailHospitlizes(@PathVariable String mail) {
        System.out.println(mail);
        return new ResponseEntity<>(hospitlizesRepository.findAllbyEmail(mail + "%"), HttpStatus.OK);
    }

    @ExceptionHandler(Exception.class)
    public ModelAndView handleError(HttpServletRequest req, Exception ex) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("error");
        return modelAndView;
    }
}
