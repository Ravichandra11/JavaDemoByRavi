package Hospital.MS.HandlerSocket;

import Hospital.MS.Model.Situation_Patient;
import Hospital.MS.Repository.UserRepository;
import java.net.http.WebSocket;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.messaging.SessionDisconnectEvent;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.messaging.SessionConnectEvent;

@Service
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class NotificationDispatcher {

    @Autowired
    Situation_Patient situation_Patient;
    @Autowired
    UserRepository usersRepository;
    private static final Logger LOGGER = LoggerFactory.getLogger(NotificationDispatcher.class);
    @Autowired
    SimpMessagingTemplate template;
    private String user;

//    public void dispatchs() {
//        if (user != null) {
//            template.convertAndSendToUser(user, "/notification/item", new Message("hello form server")
//            );
//        }
//    }
    @Scheduled(fixedDelay = 1000)
    public void dispatch() {
        if (user != null) {

            Random rand = new Random();
            int minimumb = 175;
            int maximumb = 180;
            double minimumt = 37.5;
            double maximumt = 38.5;
            double minires = 40.5;
            double maxires = 60.5;
            int randomNumb = minimumb + rand.nextInt((maximumb - minimumb) + 1);
            double random = ThreadLocalRandom.current().nextDouble(minimumt, maximumt);
            double randomres = ThreadLocalRandom.current().nextDouble(minires, maxires);
            NumberFormat formatter = new DecimalFormat("#0.00");
            situation_Patient.setDepartment("department");
            situation_Patient.setHeartBeat(randomNumb);
            situation_Patient.setNameDoctor("chahir chalouati");
            situation_Patient.setNamePatient("Patient name");
            situation_Patient.setHospitlyzed_At(new Date().toLocaleString());
            situation_Patient.setPhone("+999555555555");
            situation_Patient.setMobile("+999555555555");
            situation_Patient.setRes_ratio(Double.valueOf(formatter.format(randomres)));
            situation_Patient.setTemperature(Double.valueOf(formatter.format(random)));
            template.convertAndSendToUser(user, "/notification/item", situation_Patient);

        }
    }

    @EventListener
    public void sessionDisconnectionHandler(SessionDisconnectEvent event) {
        String sessionId = event.getSessionId();
        user = null;
        LOGGER.info("Disconnecting " + sessionId + "!");

    }

    @EventListener
    public void sessionConnectionHandler(SessionConnectEvent event) {

        String sessionId = event.getUser().getName();
        LOGGER.info("connected " + sessionId + "!");

    }
}
