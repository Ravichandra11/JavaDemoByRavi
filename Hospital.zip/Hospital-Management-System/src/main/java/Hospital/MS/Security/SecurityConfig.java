package Hospital.MS.Security;

import Hospital.MS.Services.MyUserDetailsServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 *
 * @author Chahir Chalouati
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private MySimpleUrlAuthenticationSuccessHandler successHandler;
    @Autowired
    private AuthFailureHandler authFailureHandler;
    @Autowired
    MyUserDetailsServices userDetailsServices;

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http.authorizeRequests()
                .antMatchers("/error", "/css/**", "/js/**", "/", "/icon/**",
                        "/webjars/**", "/register/**", "/test/**",
                        "/login/recover/password").permitAll()
                .antMatchers("/corona/**").permitAll()
                .antMatchers("/change/**").
                hasAnyAuthority("USER", "ADMIN", "NURSE", "PHARMACIST", "DOCTOR", "RECEPTIONIST")
                .antMatchers("/bill/**").hasAnyAuthority("USER", "NURSE")
                .antMatchers("/user/**").hasAnyAuthority("USER", "ADMIN")
                .antMatchers("/admin/**").hasAuthority("ADMIN")
                .antMatchers("/nurse/**").hasAuthority("NURSE")
                .antMatchers("/situation/**", "/swns/**").hasAuthority("NURSE")
                .antMatchers("/pharmacist/**").hasAuthority("PHARMACIST")
                .antMatchers("/doctor/**").hasAuthority("DOCTOR")
                .antMatchers("/receptionist/**").hasAuthority("RECEPTIONIST")
                .anyRequest().authenticated()
                .and()
                .formLogin()
                .loginPage("/")
                .loginProcessingUrl("/login")
                .successHandler(successHandler)
                .failureHandler(authFailureHandler)
                .failureUrl("/login_error")
                .permitAll()
                .and()
                .logout()
                .logoutUrl("/logout")
                .logoutSuccessUrl("/")
                .permitAll()
                .and()
                .csrf()
                .disable();
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsServices);
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

}
