/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Security;

import java.io.IOException;
import java.util.Collection;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

/**
 *
 * @author Chahir Chalouati
 */
@Component
public class MySimpleUrlAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess(HttpServletRequest arg0, HttpServletResponse arg1,
            Authentication authentication) throws IOException, ServletException {
        boolean hasNurseRole = false;
        boolean hasUserRole = false;
        boolean hasAdminRole = false;
        boolean hasDoctorRole = false;
        boolean hasPharmacistRole = false;
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        for (GrantedAuthority grantedAuthority : authorities) {

            if (grantedAuthority.getAuthority().equals("USER")) {
                hasUserRole = true;
                break;
            } else if (grantedAuthority.getAuthority().equals("ADMIN")) {
                hasAdminRole = true;
                break;
            } else if (grantedAuthority.getAuthority().equals("DOCTOR")) {
                hasDoctorRole = true;
                break;
            } else if (grantedAuthority.getAuthority().equals("NURSE")) {
                hasNurseRole = true;
                break;
            } else if (grantedAuthority.getAuthority().equals("PHARMACIST")) {
                hasPharmacistRole = true;
                break;
            }
        }

        if (hasUserRole) {
            redirectStrategy.sendRedirect(arg0, arg1, "/user");

        } else if (hasAdminRole) {
            redirectStrategy.sendRedirect(arg0, arg1, "/admin");
        } else if (hasDoctorRole) {
            redirectStrategy.sendRedirect(arg0, arg1, "/doctor");
        } else if (hasNurseRole) {
            redirectStrategy.sendRedirect(arg0, arg1, "/nurse");
        } else if (hasPharmacistRole) {
            redirectStrategy.sendRedirect(arg0, arg1, "/pharmacist");
        } else {
            throw new IllegalStateException();
        }
    }
}
