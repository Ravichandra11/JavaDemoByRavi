/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Repository;

import Hospital.MS.Model.Users;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Chahir Chalouati
 */
public interface UserRepository extends JpaRepository<Users, Long> {

    Users findByEmail(String email);

    List<Users> findAllEmployee(@Param("authoritie") String authoritie);

    Users findUserBySecurityNumber(@Param("securtiyNumber") String securityNumber);

    List<Users> findUserByLikeFirstname(@Param("firstname") String firstname, @Param("authoritie") String authoritie);

    List<Users> findByFirstnameLike(@Param("firstname") String firstname, @Param("authoritie") String authoritie);

    List<Users> findByAuthoritie(@Param("authoritie") String authoritie);

    List<Users> findByAuthoritieByName(@Param("authoritie") String authoritie, @Param("name") String name);

    int findAllCountPatient();

}
