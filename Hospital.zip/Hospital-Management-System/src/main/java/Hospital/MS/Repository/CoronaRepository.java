/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Repository;

import Hospital.MS.Model.Corona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author chahir chalouati
 */
public interface CoronaRepository extends JpaRepository<Corona, Long> {

    @Query(value = "TRUNCATE TABLE corona ", nativeQuery = true)
    void deleteCorona();

}
