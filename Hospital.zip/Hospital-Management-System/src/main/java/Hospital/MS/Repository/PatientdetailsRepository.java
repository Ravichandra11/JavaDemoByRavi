/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Repository;

import Hospital.MS.Model.Patientdetails;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 *
 * @author chahir chalouati
 */
public interface PatientdetailsRepository extends JpaRepository<Patientdetails, Long> {
    
}
