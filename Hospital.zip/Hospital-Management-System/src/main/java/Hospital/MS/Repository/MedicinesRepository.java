/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Repository;

import Hospital.MS.Model.Medicines;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Chahir Chalouati
 */
public interface MedicinesRepository extends JpaRepository<Medicines, Long> {

    List<Medicines> findByNameMedecineLike(@Param("nameMedecine") String name);

    List<Medicines> findAlldeleted();

    List<Medicines> findAllDISTINCT();
}
