/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hospital.MS.Repository;

import Hospital.MS.Model.Hasanalysis;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author chahir chalouati
 */
public interface HasAnalysisRepository extends JpaRepository<Hasanalysis, Long> {

    List<Hasanalysis> findAllAnalysisByPatient(@Param("securtiyNumber") String securityNumber, @Param("idDoctor") Long idDoctor);

    List<Hasanalysis> findAllWhereIdAnalysisNUll();

    List<Hasanalysis> findAllWhereIdAnalysisNUllAndLikeFirstname(@Param("name") String serach);

    List<Hasanalysis> findByAnalysisPaymentPatient(@Param("id") Long id);

    Hasanalysis UpdateAnalysis(@Param("id") Long id);
}
